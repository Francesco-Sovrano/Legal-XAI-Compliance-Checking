# Study interface

From the package root:

```sh
python user_study/ui/app.py --mode demo --db user_study/ui/data/demo.sqlite3
```

Open `http://127.0.0.1:8080`. The demo writes to its own database. Recorded responses are analysed from `user_study/data/public-review.sqlite3`. The study interface, configuration, static assets, collection service and benchmark are contained in this directory. The complete computation and data specification is `methods_scoring/assess_xai_compliance_documentation.md` from the package root.
