"""Framework-independent experiment logic for the Legal XAI validation study.

The core deliberately separates technical evaluation from legal judgment. Hidden
method identities, property scores, framework ranks, and gate outcomes never need
to enter participant-facing payloads.
"""

from __future__ import annotations

from framework_scoring import score_method
import math

from dataclasses import dataclass
import copy
import hashlib
import json
import random
import re
from pathlib import Path
from typing import Any, Iterable


ASSURANCE_TITLES = {
    "no_false_positives": "Necessity / no false positives",
    "no_false_negatives": "Sufficiency / no false negatives",
    "completeness": "Completeness / coverage",
    "stability": "Stability / continuity",
    "adversarial_robustness": "Adversarial robustness",
    "consistency": "Consistency (across instances or time)",
    "hyperparameters_perturbation_robustness": "XAI model or hyperparameters perturbation robustness",
    "sparsity": "Sparsity / few features / rule or predicate size",
    "level_of_detail": "Dimensionality / granularity / level of detail",
    "confidentiality": "Confidentiality",
    "traceability": "Traceability / accountability",
    "runtime_performance_and_implementation_constraints": "Runtime performance / scalability + implementation constraints (cost, memory)",
}


class ConfigError(ValueError):
    """Raised when a study configuration is internally inconsistent."""


@dataclass(frozen=True)
class GateResult:
    passed: bool
    checks: tuple[dict[str, Any], ...]

    @property
    def failures(self) -> tuple[dict[str, Any], ...]:
        return tuple(item for item in self.checks if not item["passed"])


@dataclass(frozen=True)
class FrameworkViews:
    """Researcher-only alignment views for a condition."""

    procedural_fit: bool
    unweighted: float
    weighted: float
    gate_pass: bool


def _policy_threshold(value: int | float | dict[str, Any]) -> int | float:
    if isinstance(value, dict):
        value = value.get("threshold")
    if not isinstance(value, (int, float)):
        raise ConfigError("Every mandatory gate requires a numeric threshold.")
    return value


def load_config(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        config = json.load(handle)
    modules = config.get("modules", {})
    resolved: dict[str, dict[str, Any]] = {}

    def resolve(module_id: str, stack: tuple[str, ...] = ()) -> dict[str, Any]:
        if module_id in resolved:
            return copy.deepcopy(resolved[module_id])
        if module_id in stack:
            raise ConfigError("Cyclic module inheritance: " + " -> ".join(stack + (module_id,)))
        if module_id not in modules:
            raise ConfigError(f"Unknown inherited module {module_id!r}.")
        current = copy.deepcopy(modules[module_id])
        parent_id = current.pop("extends", None)
        if parent_id:
            parent = resolve(parent_id, stack + (module_id,))
            parent.update(current)
            current = parent
        resolved[module_id] = current
        return copy.deepcopy(current)

    config["modules"] = {module_id: resolve(module_id) for module_id in modules}
    return config


def canonical_json(config: dict[str, Any]) -> str:
    return json.dumps(config, ensure_ascii=True, sort_keys=True, separators=(",", ":"))


def config_hash(config: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_json(config).encode("utf-8")).hexdigest()


def verify_frozen_manifest(
    config: dict[str, Any], manifest_path: str | Path
) -> dict[str, Any]:
    """Require the live configuration to match the archived freeze manifest."""

    path = Path(manifest_path)
    try:
        with path.open("r", encoding="utf-8") as handle:
            manifest = json.load(handle)
    except (OSError, json.JSONDecodeError) as exc:
        raise ConfigError(f"Could not read frozen study manifest {path}: {exc}") from exc
    expected = {
        "study_id": config.get("study_id"),
        "version": config.get("version"),
        "config_sha256": config_hash(config),
    }
    mismatches = [
        key for key, value in expected.items() if manifest.get(key) != value
    ]
    if mismatches:
        raise ConfigError(
            "Frozen study manifest does not match the live configuration: "
            + ", ".join(mismatches)
        )
    if not manifest.get("frozen_at_utc"):
        raise ConfigError("Frozen study manifest has no freeze timestamp.")
    return manifest


def evaluate_legal_gates(
    condition: dict[str, Any], gate_policy: dict[str, int | float | dict[str, Any]]
) -> GateResult:
    scores = condition.get("property_scores", {})
    checks: list[dict[str, Any]] = []
    for property_name, policy in gate_policy.items():
        threshold = _policy_threshold(policy)
        if property_name not in scores:
            raise ConfigError(
                f"Condition {condition.get('id')} has no score for mandatory property "
                f"{property_name!r}."
            )
        observed = scores[property_name]
        checks.append(
            {
                "property": property_name,
                "score": observed,
                "threshold": threshold,
                "passed": observed >= threshold,
            }
        )
    return GateResult(all(item["passed"] for item in checks), tuple(checks))


def evaluate_procedural_fit(condition: dict[str, Any]) -> bool:
    """Implement the paper's D3 filter before property aggregation."""

    fit = condition.get("procedural_fit", {})
    if isinstance(fit, bool):
        return fit
    required = ("question", "scope", "stage", "feasible")
    return bool(fit) and all(bool(fit.get(key)) for key in required)


def framework_views(module: dict[str, Any], condition: dict[str, Any]) -> FrameworkViews:
    """Compute unweighted, legally weighted, and gated framework views.

    Scores are kept hidden from participants.  The fine-grained view avoids
    cluster averaging; the weighted view uses the module's preregistered
    property-level legal weights; the gate is evaluated separately so a failed
    mandatory baseline cannot be compensated by a high weighted mean.
    """

    scores = condition.get("property_scores", {})
    requirements = module.get("requirement_weights") or {
        key: 1.0 for key in scores
    }
    if not requirements:
        raise ConfigError(f"Module {module.get('label')} has no requirement weights.")
    values: list[float] = []
    weighted_total = 0.0
    weight_sum = 0.0
    for property_name, raw_weight in requirements.items():
        if property_name not in scores:
            raise ConfigError(
                f"Condition {condition.get('id')} has no score for required property "
                f"{property_name!r}."
            )
        score = float(scores[property_name])
        if not 0 <= score <= 5:
            raise ConfigError(
                f"Condition {condition.get('id')} has an out-of-range score for "
                f"{property_name!r}."
            )
        if isinstance(raw_weight, dict):
            weight = float(raw_weight.get("weight", 0))
        else:
            weight = float(raw_weight)
        if not math.isfinite(weight) or weight < 0:
            raise ConfigError(f"Property weight {property_name!r} cannot be negative.")
        normalized = score / 5.0
        values.append(normalized)
        weighted_total += weight * normalized
        weight_sum += weight
    if not weight_sum:
        raise ConfigError(f"Module {module.get('label')} has zero total legal weight.")
    gate = evaluate_legal_gates(condition, module.get("gate_policy", {}))
    return FrameworkViews(
        procedural_fit=evaluate_procedural_fit(condition),
        unweighted=round(sum(values) / len(values), 6),
        weighted=round(weighted_total / weight_sum, 6),
        gate_pass=gate.passed,
    )


def predicted_order(module: dict[str, Any]) -> list[str]:
    """Return the condition order implied by procedural fit, gates, and score."""

    return [
        item["id"]
        for item in sorted(
            module["conditions"],
            key=lambda item: (
                not framework_views(module, item).procedural_fit,
                not framework_views(module, item).gate_pass,
                -framework_views(module, item).weighted,
                item["id"],
            ),
        )
    ]


def _contains_placeholder(value: Any) -> bool:
    if isinstance(value, str):
        return "DEMO PLACEHOLDER" in value.upper()
    if isinstance(value, dict):
        return any(_contains_placeholder(item) for item in value.values())
    if isinstance(value, list):
        return any(_contains_placeholder(item) for item in value)
    return False


def validate_config(config: dict[str, Any], live: bool = False) -> list[str]:
    errors: list[str] = []
    warnings: list[str] = []

    required_top = {
        "study_id",
        "title",
        "version",
        "modules",
        "design",
        "ethics",
        "orientation",
        "outcomes",
        "technical_signoff",
        "legal_signoff",
        "preregistration",
        "pilot",
        "panel",
        "acceptance_test",
        "ready_for_collection",
    }
    missing_top = sorted(required_top - set(config))
    if missing_top:
        errors.append(f"Missing top-level fields: {', '.join(missing_top)}")

    modules = config.get("modules", {})
    if not modules:
        errors.append("At least one module is required.")

    design = config.get("design", {})
    primary_modules = design.get("primary_study_modules", [])
    secondary_modules = design.get("secondary_study_modules", [])
    if not primary_modules:
        errors.append("Design must name at least one primary study module.")
    referenced_modules = list(primary_modules) + list(secondary_modules)
    if len(referenced_modules) != len(set(referenced_modules)):
        errors.append("A module cannot be both primary and secondary.")
    unknown_modules = sorted(set(referenced_modules) - set(modules))
    if unknown_modules:
        errors.append("Design references unknown modules: " + ", ".join(unknown_modules))
    if design.get("study_design") != "fixed-roster within-subject expert case series":
        errors.append("Design must identify the fixed-roster within-subject expert case series.")
    if design.get("one_module_per_participant") is not False:
        errors.append("Every panel expert must complete both primary modules.")
    if design.get("participant_module_choice") is not False:
        errors.append("Participants cannot choose a legal context in the panel study.")
    if design.get("counterbalancing_block") != 4:
        errors.append("The four-expert Williams counterbalance requires a block of 4.")

    panel = config.get("panel", {})
    roster = panel.get("roster", [])
    target_experts = panel.get("target_experts")
    minimum_experts = panel.get("minimum_experts")
    maximum_experts = panel.get("maximum_experts", target_experts)
    qualified_minimum = panel.get("minimum_context_qualified_experts", 0)
    familiarity_threshold = panel.get("context_familiarity_threshold", 4)
    if not isinstance(target_experts, int) or target_experts < 4 or target_experts % 4:
        errors.append("Panel target must be a positive multiple of four for complete Williams blocks.")
    if not isinstance(maximum_experts, int) or maximum_experts < 4 or maximum_experts % 4:
        errors.append("Panel maximum must be a positive multiple of four for complete Williams blocks.")
    if not isinstance(minimum_experts, int) or not isinstance(target_experts, int) or not (1 <= minimum_experts <= target_experts):
        errors.append("Panel minimum must be between one and the target number of experts.")
    if isinstance(target_experts, int) and isinstance(maximum_experts, int) and target_experts > maximum_experts:
        errors.append("Panel target cannot exceed the maximum number of invitation slots.")
    if isinstance(maximum_experts, int) and len(roster) != maximum_experts:
        errors.append("Panel roster must define exactly maximum_experts invitation slots.")
    if not isinstance(qualified_minimum, int) or qualified_minimum < 0 or (isinstance(maximum_experts, int) and qualified_minimum > maximum_experts):
        errors.append("Context-qualified minimum must be a non-negative integer no greater than panel maximum.")
    if familiarity_threshold not in (1, 2, 3, 4, 5):
        errors.append("Context familiarity threshold must be an integer from 1 to 5.")
    slot_ids = [item.get("slot_id") for item in roster]
    access_codes = [str(item.get("access_code", "")).strip().upper() for item in roster]
    if len(set(slot_ids)) != len(slot_ids) or any(not item for item in slot_ids):
        errors.append("Panel slot IDs must be present and unique.")
    if len(set(access_codes)) != len(access_codes) or any(not item for item in access_codes):
        errors.append("Panel invitation codes must be present and unique.")
    sequence_indices = [item.get("sequence_index") for item in roster]
    if any(index not in (0, 1, 2, 3) for index in sequence_indices):
        errors.append("Panel slots must use Williams sequence indices 0, 1, 2, or 3.")
    elif roster and len(roster) % 4 == 0:
        expected_each = len(roster) // 4
        if any(sequence_indices.count(index) != expected_each for index in range(4)):
            errors.append("Panel roster must contain complete, balanced four-sequence Williams blocks.")
    for item in roster:
        if item.get("module_order") not in (
            list(primary_modules),
            list(reversed(primary_modules)),
        ):
            errors.append(
                f"Panel slot {item.get('slot_id')} must contain both primary modules once."
            )
    if roster and len(primary_modules) == 2:
        first_modules = [item.get("module_order", [None])[0] for item in roster]
        expected_first = len(roster) // 2
        if any(first_modules.count(module_id) != expected_first for module_id in primary_modules):
            errors.append("Roster must balance legal-context order across the two primary modules.")

    pilot = config.get("pilot", {})
    for field in ("cognitive_complete", "soft_launch_complete"):
        if not isinstance(pilot.get(field), bool):
            errors.append(f"Pilot field {field} must be a boolean.")

    orientation = config.get("orientation", {})
    orientation_questions = orientation.get("questions", [])
    if len(orientation_questions) < 2:
        errors.append("Orientation must contain at least two comprehension questions.")
    if len({item.get("id") for item in orientation_questions}) != len(
        orientation_questions
    ):
        errors.append("Orientation question IDs must be unique.")
    for item in orientation_questions:
        options = item.get("options", [])
        option_values = {option.get("value") for option in options}
        if not item.get("prompt") or len(option_values) < 2:
            errors.append("Every orientation item needs a prompt and at least two options.")
        if item.get("correct") not in option_values:
            errors.append(f"Orientation item {item.get('id')} has no valid correct answer.")

    primary_outcome = config.get("outcomes", {}).get("primary", {})
    if primary_outcome.get("field") != "enables_legal_objective":
        errors.append("The primary outcome must be the pre-comparison legal-objective rating.")

    for module_id, module in modules.items():
        conditions = module.get("conditions", [])
        cases = module.get("cases", [])
        schema = module.get("assurance_schema", [])
        gate_policy = module.get("gate_policy", {})

        if not isinstance(module.get("recruitment_enabled"), bool):
            errors.append(f"Module {module_id} must state recruitment_enabled as a boolean.")
        if module_id in primary_modules and not module.get("recruitment_enabled"):
            errors.append(f"Primary module {module_id} must be recruitment-enabled.")

        if module.get("study_type") not in {
            "method_profile",
            "authority_profile",
            "controlled_profile",
            "controlled_factorial",
        }:
            errors.append(
                f"Module {module_id} has an unknown study type."
            )
        provision = module.get("provision", {})
        required_provision = {
            "legal_instrument",
            "pinpoint",
            "beneficiary",
            "stage",
            "scope",
            "question_archetype",
            "authority_url",
        }
        if required_provision - set(provision):
            errors.append(f"Module {module_id} has an incomplete provision record.")
        legal_brief = module.get("legal_brief", {})
        if not legal_brief.get("decision_standard") or not legal_brief.get("assumed_facts"):
            errors.append(f"Module {module_id} has no complete participant legal brief.")
        if not module.get("requirement_weights"):
            errors.append(f"Module {module_id} has no property-level legal weights.")
        if module.get("comparison_enabled", True):
            comparison_scope = module.get("comparison_scope", "common_question")
            if comparison_scope != "cross_question_exploratory" and not module.get("confirmatory_contrasts"):
                errors.append(f"Module {module_id} has no preregistered contrast specification.")
        elif not module.get("matched_predictions"):
            errors.append(f"Module {module_id} has no question-matched prediction specification.")

        if len(conditions) != 4:
            errors.append(f"Module {module_id} must have exactly four conditions.")
        if module_id in primary_modules:
            if len(cases) != 1:
                errors.append(
                    f"Primary module {module_id} must use exactly one fixed legal case."
                )
            elif module.get("comparison_case") != cases[0]:
                errors.append(
                    f"Primary module {module_id} must reuse its single case for comparison."
                )
        elif len(cases) != 4:
            errors.append(f"Module {module_id} must have exactly four matched cases.")
        if len({item.get('id') for item in conditions}) != len(conditions):
            errors.append(f"Module {module_id} has duplicate condition IDs.")
        if len({item.get('id') for item in cases}) != len(cases):
            errors.append(f"Module {module_id} has duplicate case IDs.")
        if not schema:
            errors.append(f"Module {module_id} has no technical-assurance schema.")
        if not module.get("comparison_case"):
            errors.append(f"Module {module_id} has no common comparison case.")
        if module.get("show_checklist") and not module.get("checklist"):
            errors.append(f"Module {module_id} shows a checklist but defines no items.")

        condition_ids = {item.get("id") for item in conditions}
        provenance = module.get("evidence_provenance", {})
        if provenance.get("status") not in {
            "demo-placeholder",
            "frozen-empirical",
            "controlled-by-construction",
        }:
            errors.append(f"Module {module_id} has no valid evidence-provenance status.")
        if not provenance.get("protocol_id"):
            errors.append(f"Module {module_id} has no evidence protocol identifier.")
        if set(provenance.get("condition_records", {})) != condition_ids:
            errors.append(
                f"Module {module_id} must link every condition to exactly one evidence record."
            )
        comparison_enabled = bool(module.get("comparison_enabled", True))
        primary_contrasts = 0
        contrast_pairs: set[tuple[str, str]] = set()
        for contrast in module.get("confirmatory_contrasts", []):
            if contrast.get("better") not in condition_ids or contrast.get("worse") not in condition_ids:
                errors.append(f"Module {module_id} has a contrast with an unknown condition.")
            primary_contrasts += int(bool(contrast.get("primary")))
            pair = (contrast.get("better"), contrast.get("worse"))
            if pair in contrast_pairs:
                errors.append(f"Module {module_id} has a duplicate contrast {pair}.")
            contrast_pairs.add(pair)
        if module_id in primary_modules and comparison_enabled:
            comparison_scope = module.get("comparison_scope", "common_question")
            if comparison_scope in {"cross_question_exploratory", "question_matched_with_exploratory_overall_rank"}:
                matched = module.get("matched_predictions", [])
                matched_pairs = {(item.get("better"), item.get("worse")) for item in matched}
                if contrast_pairs != matched_pairs or primary_contrasts != len(matched_pairs):
                    errors.append(f"Primary comparison module {module_id} must restrict confirmatory contrasts to its question-matched predictions.")
                for item in matched:
                    if item.get("better") not in condition_ids or item.get("worse") not in condition_ids:
                        errors.append(f"Module {module_id} has a matched prediction with an unknown condition.")
                        continue
                    left = next((c for c in conditions if c.get("id") == item.get("better")), None)
                    right = next((c for c in conditions if c.get("id") == item.get("worse")), None)
                    if left and right and left.get("target_question_archetype") != right.get("target_question_archetype"):
                        errors.append(f"Module {module_id} matched predictions must compare methods answering the same question archetype.")
            else:
                declared_order = [
                    item["id"]
                    for item in sorted(conditions, key=lambda item: item["framework_rank"])
                ]
                expected_pairs = {
                    (declared_order[left], declared_order[right])
                    for left in range(len(declared_order))
                    for right in range(left + 1, len(declared_order))
                }
                if module.get("rank_basis") == "literature_formula":
                    literature = {item["id"]: float(item["literature_score"]) for item in conditions}
                    band = 0.02
                    expected_pairs = {pair for pair in expected_pairs if abs(literature[pair[0]] - literature[pair[1]]) >= band}
                if contrast_pairs != expected_pairs or primary_contrasts != len(expected_pairs):
                    errors.append(f"Primary comparison module {module_id} must preregister exactly its directed contrasts.")
                if module.get("ordered_hypothesis") != declared_order:
                    errors.append(f"Primary comparison module {module_id} must freeze its complete predicted order.")
        elif module_id in primary_modules:
            matched = module.get("matched_predictions", [])
            if not matched:
                errors.append(f"Primary non-ranking module {module_id} must define matched_predictions.")
            for item in matched:
                if item.get("better") not in condition_ids or item.get("worse") not in condition_ids:
                    errors.append(f"Module {module_id} has a matched prediction with an unknown condition.")
                left = next((c for c in conditions if c.get("id") == item.get("better")), None)
                right = next((c for c in conditions if c.get("id") == item.get("worse")), None)
                if left and right and left.get("target_question_archetype") != right.get("target_question_archetype"):
                    errors.append(f"Module {module_id} matched predictions must compare methods answering the same question archetype.")
        elif comparison_enabled and primary_contrasts != 1:
            errors.append(f"Module {module_id} must declare exactly one primary contrast.")

        poststudy_checks = module.get("poststudy_checks", [])
        if len({item.get('id') for item in poststudy_checks}) != len(poststudy_checks):
            errors.append(f"Module {module_id} has duplicate post-study check IDs.")
        for item in poststudy_checks:
            allowed = {option.get("value") for option in item.get("options", [])}
            if item.get("correct") not in allowed:
                errors.append(
                    f"Module {module_id}, post-study check {item.get('id')} has no valid answer key."
                )

        declared_ranks: list[int] = []
        for condition in conditions:
            condition_id = condition.get("id", "<missing>")
            actual_keys = list(condition.get("assurance", {}).keys())
            if actual_keys != schema:
                errors.append(
                    f"Module {module_id}, condition {condition_id}: assurance slots "
                    "must exactly match the module schema and order."
                )
            if module_id in primary_modules:
                guide = module.get("evidence_guide", {})
                if list(guide) != schema:
                    errors.append(
                        f"Primary module {module_id}: evidence guide must match the assurance schema."
                    )
                for key in schema:
                    entry = guide.get(key, {})
                    if not entry.get("tested") or not entry.get("protocol"):
                        errors.append(
                            f"Primary module {module_id}: evidence guide {key} needs "
                            "plain-language test and protocol text."
                        )
            try:
                gate = evaluate_legal_gates(condition, gate_policy)
                if not gate.passed:
                    warnings.append(
                        f"{module_id}/{condition_id} fails mandatory baseline: "
                        + ", ".join(item["property"] for item in gate.failures)
                    )
            except ConfigError as exc:
                errors.append(str(exc))
            try:
                if comparison_enabled:
                    declared_ranks.append(int(condition["framework_rank"]))
                framework_views(module, condition)
            except (KeyError, TypeError, ValueError, ConfigError):
                errors.append(
                    f"Module {module_id}, condition {condition_id}: invalid fit, score, weight, gate, or comparison rank."
                )
            if module.get("study_type") == "controlled_factorial" and not condition.get(
                "factor_levels"
            ):
                errors.append(
                    f"Module {module_id}, condition {condition_id}: controlled factorial condition has no factor levels."
                )

        if comparison_enabled and sorted(declared_ranks) != list(range(1, len(conditions) + 1)):
            errors.append(f"Module {module_id} must declare consecutive comparison ranks once each.")
        if comparison_enabled and len(conditions) == 4:
            declared = [
                item["id"]
                for item in sorted(conditions, key=lambda item: item["framework_rank"])
            ]
            if module.get("rank_basis") in {"matched_question_predictions", "exploratory_cross_question"}:
                # Display order must follow the category formula used by analysis,
                # not the separate fine-grained weighted diagnostic. This order
                # remains exploratory; confirmatory contrasts stay question-matched.
                expected = [c["id"] for c in sorted(conditions, key=lambda c: -c["literature_score"])]
                if declared != expected:
                    errors.append(f"Module {module_id}: ranks disagree with category fit priors.")
                for c in conditions:
                    calculated = score_method(c["property_scores"], module["requirement_weights"], procedural_fit=evaluate_procedural_fit(c)).overall
                    if abs(calculated - c["literature_score"]) > 1e-6:
                        errors.append(f"Condition {c['id']}: stale category fit prior; regenerate config.")
            elif module.get("rank_basis") in {"authority_benchmark", "literature_formula"}:
                expected = list(module.get("ordered_hypothesis", []))
                if declared != expected:
                    errors.append(
                        f"Module {module_id}: declared ranks must match the frozen ordered_hypothesis. "
                        f"Expected {expected}, got {declared}."
                    )
            else:
                try:
                    expected = predicted_order(module)
                    if declared != expected:
                        errors.append(
                            f"Module {module_id}: declared rank violates procedural-fit, gate, "
                            f"then weighted-score order. Expected {expected}, got {declared}."
                        )
                except (ConfigError, KeyError, TypeError, ValueError) as exc:
                    errors.append(f"Module {module_id}: could not evaluate ordering: {exc}")

    if live:
        if not config.get("ready_for_collection"):
            errors.append("Live mode requires ready_for_collection=true.")
        for signoff_name in ("technical_signoff", "legal_signoff"):
            if not config.get(signoff_name, {}).get("complete"):
                errors.append(f"Live mode requires {signoff_name}.complete=true.")
        live_scope = {
            key: value for key, value in config.items() if key != "modules"
        }
        live_scope["modules"] = {
            module_id: modules[module_id] for module_id in primary_modules
        }
        if _contains_placeholder(live_scope):
            errors.append("Live mode rejects DEMO PLACEHOLDER content.")
        readiness_checks = {
            "ethics approval": config.get("ethics", {}).get("approved"),
            "preregistration freeze": config.get("preregistration", {}).get("frozen"),
            "cognitive-pilot completion": config.get("pilot", {}).get("cognitive_complete"),
            "soft-launch completion": config.get("pilot", {}).get("soft_launch_complete"),
            "browser acceptance": config.get("acceptance_test", {}).get("complete"),
            "supported frontend dependency": config.get("acceptance_test", {}).get(
                "frontend_dependency_supported"
            ),
        }
        for label, complete in readiness_checks.items():
            if not complete:
                errors.append(f"Live mode requires {label}.")
        if any("DEMO" in code for code in access_codes):
            errors.append("Live mode rejects demo invitation codes; generate private live codes.")
        if any(len(code) < 16 for code in access_codes):
            errors.append("Live invitation codes must contain at least 16 characters.")
        enabled = {
            module_id
            for module_id, module in modules.items()
            if module.get("recruitment_enabled")
        }
        if enabled != set(primary_modules):
            errors.append(
                "Live mode must recruitment-enable exactly the preregistered primary modules."
            )
        for module_id in primary_modules:
            module = modules[module_id]
            status = module.get("evidence_provenance", {}).get("status")
            allowed = (
                {"frozen-empirical"}
                if module.get("study_type") == "method_profile"
                else {"frozen-empirical", "controlled-by-construction"}
            )
            if status not in allowed:
                errors.append(
                    f"Live mode rejects {module_id}: evidence provenance is not frozen."
                )

    if errors:
        raise ConfigError("\n".join(errors))
    return warnings


def williams_sequences(size: int = 4) -> list[list[int]]:
    """Balanced first-order Williams sequences for an even number of conditions."""

    if size < 2 or size % 2:
        raise ValueError("This study uses an even number of conditions.")
    base = [0]
    low, high = 1, size - 1
    while len(base) < size:
        base.append(low)
        low += 1
        if len(base) < size:
            base.append(high)
            high -= 1
    return [[(value + offset) % size for value in base] for offset in range(size)]


def _seeded_random(seed: str) -> random.Random:
    digest = hashlib.sha256(seed.encode("utf-8")).digest()
    return random.Random(int.from_bytes(digest[:8], "big"))


def blind_label_map(session_id: str, condition_ids: Iterable[str]) -> dict[str, str]:
    ids = list(condition_ids)
    labels = [chr(ord("A") + index) for index in range(len(ids))]
    _seeded_random(f"labels:{session_id}").shuffle(labels)
    return dict(zip(ids, labels))


def assignment_for(
    module: dict[str, Any],
    assignment_index: int,
    session_id: str,
    *,
    case_sequence_index: int | None = None,
) -> list[dict[str, Any]]:
    conditions = module["conditions"]
    cases = module["cases"]
    sequences = williams_sequences(len(conditions))
    condition_sequence = sequences[assignment_index % len(conditions)]
    if case_sequence_index is None:
        case_sequence_index = (assignment_index // len(conditions)) % len(cases)
    case_sequence = (
        [0] * len(conditions)
        if len(cases) == 1
        else sequences[case_sequence_index % len(cases)]
    )
    label_map = blind_label_map(session_id, [item["id"] for item in conditions])
    return [
        {
            "trial_index": trial_index,
            "case_id": cases[case_sequence[trial_index]]["id"],
            "condition_id": conditions[condition_index]["id"],
            "blind_label": label_map[conditions[condition_index]["id"]],
        }
        for trial_index, condition_index in enumerate(condition_sequence)
    ]


_TOKEN = re.compile(r"\{\{\s*([A-Za-z0-9_]+)\s*\}\}")


def render_template(value: Any, case: dict[str, Any]) -> Any:
    if isinstance(value, str):
        return _TOKEN.sub(lambda match: str(case.get(match.group(1), match.group(0))), value)
    if isinstance(value, list):
        return [render_template(item, case) for item in value]
    if isinstance(value, dict):
        return {key: render_template(item, case) for key, item in value.items()}
    return value


def get_condition(module: dict[str, Any], condition_id: str) -> dict[str, Any]:
    return next(item for item in module["conditions"] if item["id"] == condition_id)


def get_case(module: dict[str, Any], case_id: str) -> dict[str, Any]:
    return next(item for item in module["cases"] if item["id"] == case_id)


def participant_trial(
    module: dict[str, Any], assignment: dict[str, Any]
) -> dict[str, Any]:
    """Build a participant-safe trial payload with no hidden framework metadata."""

    condition = get_condition(module, assignment["condition_id"])
    case = get_case(module, assignment["case_id"])
    explanation = render_template(condition["explanation"], case)
    evidence = participant_evidence_items(module, condition, case)
    return {
        "trial_index": assignment["trial_index"],
        "blind_label": assignment["blind_label"],
        "case": {
            "case_ref": case["case_ref"],
            "decision": case["decision"],
            "model_output": case["model_output"],
            "case_narrative": case.get("case_narrative", ""),
            "profile": case["profile"],
        },
        "legal_question": module.get("legal_question", ""),
        "legal_objective": module.get("legal_objective", ""),
        "explanation": explanation,
        "assurance": evidence,
    }


def participant_evidence_items(
    module: dict[str, Any], condition: dict[str, Any], case: dict[str, Any]
) -> list[dict[str, Any]]:
    """Render a common, method-blind technical evidence dossier."""

    assurance = render_template(condition["assurance"], case)
    metrics = render_template(condition.get("evidence_metrics", {}), case)
    guide = module.get("evidence_guide", {})
    return [
        {
            "key": key,
            "title": ASSURANCE_TITLES.get(key, key.replace("_", " ").title()),
            "category": guide.get(key, {}).get("category", "Other"),
            "property": guide.get(key, {}).get("property", ""),
            "heading": guide.get(key, {}).get("heading", guide.get(key, {}).get("tested", guide.get(key, {}).get("property", ""))),
            "technical_term": guide.get(key, {}).get("technical_term", guide.get(key, {}).get("property", "")),
            "short_label": guide.get(key, {}).get("short_label", guide.get(key, {}).get("property", "")),
            "definition": guide.get(key, {}).get("definition", ""),
            "example": guide.get(key, {}).get("example", ""),
            "tested": guide.get(key, {}).get("tested", ""),
            "protocol": guide.get(key, {}).get("protocol", ""),
            "fact": assurance[key],
            "metric": metrics.get(key, {}),
        }
        for key in module["assurance_schema"]
    ]


def participant_module(module: dict[str, Any]) -> dict[str, Any]:
    return {
        "label": module["label"],
        "short_label": module["short_label"],
        "domain": module["domain"],
        "provision_label": module["provision_label"],
        "legal_question": module["legal_question"],
        "legal_objective": module["legal_objective"],
        "evidence_scale": module.get("evidence_scale", {}),
        "case_visual_kind": module.get("case_visual_kind", ""),
        "explanation_recipient": module.get("explanation_recipient", "Recipient"),
        "expert_memo_title": module.get("expert_memo_title", "Technical quality report on this explanation"),
        "expert_memo_visibility": module.get("expert_memo_visibility", "For the legal assessor only"),
        "expert_memo_button": module.get("expert_memo_button", "Open technical expert memo"),
        "show_checklist": bool(module.get("show_checklist")),
        "legal_brief": module.get("legal_brief", {}),
        "provision": module.get("provision", {}),
        "poststudy_checks": [
            {key: value for key, value in item.items() if key != "correct"}
            for item in module.get("poststudy_checks", [])
        ],
    }


def participant_comparison_cards(
    module: dict[str, Any], assignments: list[dict[str, Any]]
) -> dict[str, Any]:
    """Render all neutrally labelled conditions on one common case for final comparison."""

    case = module["comparison_case"]
    cards: list[dict[str, Any]] = []
    allowed = set(module.get("comparison_condition_ids") or [a["condition_id"] for a in assignments])
    for assignment in sorted(assignments, key=lambda item: item["blind_label"]):
        if assignment["condition_id"] not in allowed:
            continue
        condition = get_condition(module, assignment["condition_id"])
        cards.append(
            {
                "blind_label": assignment["blind_label"],
                "legal_question": module.get("legal_question", ""),
                "legal_objective": module.get("legal_objective", ""),
                "explanation": render_template(condition["explanation"], case),
                "assurance": participant_evidence_items(module, condition, case),
            }
        )
    return {
        "case": {
            "case_ref": case["case_ref"],
            "decision": case["decision"],
            "model_output": case["model_output"],
            "case_narrative": case.get("case_narrative", ""),
            "profile": case["profile"],
        },
        "cards": cards,
    }


def randomized_checklist(
    module: dict[str, Any], session_id: str
) -> list[dict[str, Any]]:
    items = [dict(item) for item in module.get("checklist", [])]
    _seeded_random(f"checklist:{session_id}").shuffle(items)
    return items


def hidden_debug_record(module: dict[str, Any], condition: dict[str, Any]) -> dict[str, Any]:
    gate = evaluate_legal_gates(condition, module.get("gate_policy", {}))
    views = framework_views(module, condition)
    return {
        "id": condition["id"],
        "method_identity": condition["method_identity"],
        "framework_rank": condition.get("framework_rank"),
        "display_order": condition.get("display_order"),
        "target_question_archetype": condition.get("target_question_archetype"),
        "target_question_text": condition.get("target_question_text"),
        "procedural_fit": views.procedural_fit,
        "unweighted_alignment": views.unweighted,
        "weighted_alignment": views.weighted,
        "literature_score": condition.get("literature_score"),
        "literature_method": condition.get("literature_method"),
        "score_provenance": condition.get("score_provenance", {}),
        "score_sources": condition.get("score_sources", {}),
        "property_score_comments": condition.get("property_score_comments", {}),
        "literature_universe_rank": condition.get("literature_universe_rank"),
        "selection_tier": condition.get("selection_tier"),
        "empirical_metrics": condition.get("empirical_metrics", {}),
        "rank_basis": module.get("rank_basis", "gated_weighted"),
        "gate_pass": gate.passed,
        "gate_checks": list(gate.checks),
        "property_scores": condition["property_scores"],
        "assurance": condition["assurance"],
    }
