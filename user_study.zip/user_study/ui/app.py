#!/usr/bin/env python3
"""WSGI server for the Legal XAI expert-validation study.

Demo mode uses only Python's standard library and SQLite. For fieldwork behind an
institutional HTTPS reverse proxy, install Waitress and run with ``--server
waitress`` after the live launch gates and frozen manifest pass validation.
"""
from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import hmac
import io
import json
import mimetypes
import os
from pathlib import Path
import secrets
import sys
import urllib.parse
import zipfile
from typing import Any, Callable, Iterable
from wsgiref.simple_server import make_server

from study_core import ConfigError, load_config, validate_config, verify_frozen_manifest
from study_service import (
    StudyStateError,
    admin_summary,
    continue_after_break,
    ensure_database,
    export_tables,
    get_checklist,
    get_comparison,
    get_current_trial,
    get_orientation,
    get_state,
    participant_results_rows,
    save_checklist,
    save_orientation,
    save_poststudy,
    save_ranking,
    save_trial,
    resume_session,
    start_session,
    withdraw_session,
)

ROOT = Path(__file__).resolve().parent
STATIC_ROOT = ROOT / "static"


class HttpError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = int(status)
        self.message = str(message)


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _signed_cookie(value: str, secret: str) -> str:
    body = _b64(value.encode("utf-8"))
    sig = _b64(hmac.new(secret.encode("utf-8"), body.encode("ascii"), hashlib.sha256).digest())
    return f"{body}.{sig}"


def _read_signed_cookie(raw: str | None, secret: str) -> str | None:
    if not raw or "." not in raw:
        return None
    body, sig = raw.rsplit(".", 1)
    expected = _b64(hmac.new(secret.encode("utf-8"), body.encode("ascii"), hashlib.sha256).digest())
    if not secrets.compare_digest(sig, expected):
        return None
    try:
        padded = body + "=" * (-len(body) % 4)
        return base64.urlsafe_b64decode(padded.encode("ascii")).decode("utf-8")
    except Exception:
        return None


def _cookies(environ: dict[str, Any]) -> dict[str, str]:
    result: dict[str, str] = {}
    for pair in environ.get("HTTP_COOKIE", "").split(";"):
        if "=" not in pair:
            continue
        key, value = pair.strip().split("=", 1)
        result[key] = urllib.parse.unquote(value)
    return result


def _json_bytes(payload: Any) -> bytes:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _body_json(environ: dict[str, Any]) -> dict[str, Any]:
    try:
        length = int(environ.get("CONTENT_LENGTH") or 0)
    except ValueError:
        raise HttpError(400, "Invalid Content-Length.")
    if length <= 0:
        raise HttpError(400, "Expected a JSON object.")
    if length > 131072:
        raise HttpError(400, "JSON request body exceeds the 128 KiB limit.")
    raw = environ["wsgi.input"].read(length)
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise HttpError(400, "Malformed JSON request body.") from exc
    if not isinstance(value, dict):
        raise HttpError(400, "Expected a JSON object.")
    return value


def _header(environ: dict[str, Any], name: str) -> str:
    return str(environ.get("HTTP_" + name.upper().replace("-", "_"), ""))


def create_app(
    config_path: str | Path,
    db_path: str | Path,
    *,
    mode: str = "demo",
    secret: str | None = None,
    admin_token: str | None = None,
    secure_cookie: bool = False,
    manifest_path: str | Path | None = None,
) -> Callable:
    config = load_config(config_path)
    validate_config(config, live=mode == "live")
    if mode == "live":
        if manifest_path is None:
            raise ConfigError("Live mode requires a frozen study manifest.")
        verify_frozen_manifest(config, manifest_path)
    ensure_database(db_path, config)

    secret = secret or secrets.token_urlsafe(48)
    admin_token = admin_token or "demo-admin"
    db_path = Path(db_path)

    # The vendored Vue "global" build compiles the in-page template at runtime,
    # which requires dynamic Function() evaluation. Permit that only in demo
    # review mode. Live deployment remains strict/fail-closed and should use a
    # precompiled Vue build before recruitment is enabled.
    script_src = "'self' 'unsafe-eval'" if mode == "demo" else "'self'"
    security_headers = [
        ("Cache-Control", "no-store, max-age=0"),
        ("Pragma", "no-cache"),
        ("X-Content-Type-Options", "nosniff"),
        ("X-Frame-Options", "DENY"),
        ("Referrer-Policy", "no-referrer"),
        ("Content-Security-Policy", f"default-src 'self'; script-src {script_src}; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"),
    ]

    def respond(start_response: Callable, body: bytes, status: str = "200 OK", headers: Iterable[tuple[str, str]] = ()):
        final_headers = list(security_headers) + list(headers)
        final_headers.append(("Content-Length", str(len(body))))
        start_response(status, final_headers)
        return [body]

    def json_response(start_response: Callable, payload: Any, status_code: int = 200, headers: Iterable[tuple[str, str]] = ()):
        status_text = {
            200: "200 OK", 201: "201 Created", 400: "400 Bad Request", 403: "403 Forbidden",
            404: "404 Not Found", 405: "405 Method Not Allowed", 409: "409 Conflict", 500: "500 Internal Server Error",
        }.get(status_code, f"{status_code} Error")
        return respond(start_response, _json_bytes(payload), status_text, [("Content-Type", "application/json; charset=utf-8"), *headers])

    def session_id(environ: dict[str, Any]) -> str:
        value = _read_signed_cookie(_cookies(environ).get("legal_xai_session"), secret)
        if not value:
            raise HttpError(404, "No active study session.")
        return value

    def require_csrf(environ: dict[str, Any], identifier: str) -> None:
        state = get_state(db_path, config, identifier)
        supplied = _header(environ, "X-CSRF-Token")
        if not supplied or not secrets.compare_digest(supplied, state["csrf_token"]):
            raise HttpError(403, "Invalid request token.")

    def require_admin(environ: dict[str, Any]) -> None:
        supplied = _header(environ, "X-Admin-Token")
        authorization = _header(environ, "Authorization")
        if authorization.lower().startswith("bearer "):
            supplied = authorization[7:].strip()
        if not supplied or not secrets.compare_digest(supplied, admin_token):
            raise HttpError(403, "Researcher access token required.")

    def api(function: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        try:
            return function(*args, **kwargs)
        except StudyStateError as exc:
            raise HttpError(409, str(exc)) from exc

    def static_file(start_response: Callable, relative: str):
        target = (STATIC_ROOT / relative).resolve()
        if not str(target).startswith(str(STATIC_ROOT.resolve()) + os.sep) and target != STATIC_ROOT.resolve():
            raise HttpError(404, "Not found.")
        if not target.is_file():
            raise HttpError(404, "Not found.")
        content_type = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        return respond(start_response, target.read_bytes(), "200 OK", [("Content-Type", content_type)])

    def application(environ: dict[str, Any], start_response: Callable):
        method = environ.get("REQUEST_METHOD", "GET").upper()
        path = environ.get("PATH_INFO", "/")
        try:
            if method == "GET" and path == "/":
                return static_file(start_response, "index.html")
            if method == "GET" and path == "/admin/debug":
                return static_file(start_response, "admin.html")
            if method == "GET" and path.startswith("/assets/"):
                return static_file(start_response, path[len("/"):])
            if method == "GET" and path == "/health":
                return json_response(start_response, {"status": "ok", "study": config["study_id"], "mode": mode})
            if method == "GET" and path == "/config/study.json" and mode == "demo":
                # Documentation/mockup support only. Live mode never exposes hidden study configuration.
                return json_response(start_response, config)
            if method == "GET" and path == "/api/public-config":
                contexts = [
                    {"id": module_id, "label": module["label"], "domain": module["domain"], "provision_label": module["provision_label"]}
                    for module_id, module in config["modules"].items()
                    if module_id in config.get("design", {}).get("primary_study_modules", [])
                ]
                payload = {
                    "title": config["title"], "version": config["version"], "mode": mode,
                    "participant_copy": config["participant_copy"], "participant_module_choice": False,
                    "within_subject": True, "contexts": contexts,
                    "target_experts": config.get("panel", {}).get("target_experts"),
                    "minimum_experts": config.get("panel", {}).get("minimum_experts"),
                    "consent_version": config.get("ethics", {}).get("consent_version"),
                    "minimum_age": config.get("ethics", {}).get("minimum_age", 18),
                    "withdrawal_policy": config.get("ethics", {}).get("withdrawal_policy", ""),
                }
                return json_response(start_response, payload)
            if method == "POST" and path == "/api/session":
                values = _body_json(environ)
                result = api(start_session, db_path, config, values.get("panel_code", ""), values.get("experience_band", ""), values.get("years_legal_experience"), values.get("gdpr_familiarity"), values.get("mdr_familiarity"), values.get("consent"))
                cookie = _signed_cookie(result["session_id"], secret)
                attrs = [f"legal_xai_session={urllib.parse.quote(cookie)}", "HttpOnly", "SameSite=Strict", "Path=/"]
                if secure_cookie:
                    attrs.append("Secure")
                return json_response(start_response, result, headers=[("Set-Cookie", "; ".join(attrs))])
            if method == "POST" and path == "/api/session/resume":
                values = _body_json(environ)
                result = api(resume_session, db_path, config, values.get("panel_code", ""))
                cookie = _signed_cookie(result["session_id"], secret)
                attrs = [f"legal_xai_session={urllib.parse.quote(cookie)}", "HttpOnly", "SameSite=Strict", "Path=/"]
                if secure_cookie:
                    attrs.append("Secure")
                return json_response(start_response, result, headers=[("Set-Cookie", "; ".join(attrs))])
            if method == "GET" and path == "/api/my-results.csv":
                ident = session_id(environ)
                rows = api(participant_results_rows, db_path, config, ident)
                csv_buffer = io.StringIO()
                fieldnames = ["context", "explanation", "section", "item", "response", "note", "recorded_at"]
                writer = csv.DictWriter(csv_buffer, fieldnames=fieldnames, lineterminator="\n")
                writer.writeheader()
                writer.writerows(rows)
                return respond(
                    start_response, csv_buffer.getvalue().encode("utf-8-sig"), "200 OK",
                    [("Content-Type", "text/csv; charset=utf-8"),
                     ("Content-Disposition", "attachment; filename=legal-xai-my-results.csv"),
                     ("Cache-Control", "private, no-store")],
                )
            if method == "GET" and path == "/api/state":
                return json_response(start_response, api(get_state, db_path, config, session_id(environ)))
            if method == "GET" and path == "/api/orientation":
                return json_response(start_response, api(get_orientation, db_path, config, session_id(environ)))
            if method == "POST" and path == "/api/orientation":
                ident = session_id(environ); require_csrf(environ, ident)
                return json_response(start_response, api(save_orientation, db_path, config, ident, _body_json(environ)))
            if method == "POST" and path == "/api/intermission/continue":
                ident = session_id(environ); require_csrf(environ, ident)
                return json_response(start_response, api(continue_after_break, db_path, config, ident))
            if method == "GET" and path == "/api/trial/current":
                return json_response(start_response, api(get_current_trial, db_path, config, session_id(environ)))
            if method == "POST" and path == "/api/trial":
                ident = session_id(environ); require_csrf(environ, ident)
                return json_response(start_response, api(save_trial, db_path, config, ident, _body_json(environ)))
            if method == "GET" and path == "/api/comparison":
                return json_response(start_response, api(get_comparison, db_path, config, session_id(environ)))
            if method == "POST" and path == "/api/ranking":
                ident = session_id(environ); require_csrf(environ, ident)
                return json_response(start_response, api(save_ranking, db_path, config, ident, _body_json(environ)))
            if method == "GET" and path == "/api/checklist":
                return json_response(start_response, api(get_checklist, db_path, config, session_id(environ)))
            if method == "POST" and path == "/api/checklist":
                ident = session_id(environ); require_csrf(environ, ident)
                return json_response(start_response, api(save_checklist, db_path, config, ident, _body_json(environ)))
            if method == "POST" and path == "/api/poststudy":
                ident = session_id(environ); require_csrf(environ, ident)
                return json_response(start_response, api(save_poststudy, db_path, config, ident, _body_json(environ)))
            if method == "POST" and path == "/api/withdraw":
                ident = session_id(environ); require_csrf(environ, ident)
                result = api(withdraw_session, db_path, ident)
                attrs = ["legal_xai_session=", "Max-Age=0", "HttpOnly", "SameSite=Strict", "Path=/"]
                if secure_cookie:
                    attrs.append("Secure")
                return json_response(start_response, result, headers=[("Set-Cookie", "; ".join(attrs))])
            if method == "GET" and path == "/api/admin/debug":
                require_admin(environ)
                return json_response(start_response, api(admin_summary, db_path, config))
            if method == "GET" and path == "/api/admin/export.zip":
                require_admin(environ)
                tables = export_tables(db_path)
                output = io.BytesIO()
                with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
                    for table_name, rows in tables.items():
                        csv_buffer = io.StringIO()
                        fieldnames = list(rows[0].keys()) if rows else []
                        writer = csv.DictWriter(csv_buffer, fieldnames=fieldnames)
                        if fieldnames:
                            writer.writeheader(); writer.writerows(rows)
                        archive.writestr(f"{table_name}.csv", csv_buffer.getvalue())
                data = output.getvalue()
                return respond(start_response, data, "200 OK", [("Content-Type", "application/zip"), ("Content-Disposition", f"attachment; filename={config['study_id']}-export.zip")])
            if path.startswith("/api/"):
                raise HttpError(404, "API route not found.")
            raise HttpError(404, "Not found.")
        except HttpError as exc:
            return json_response(start_response, {"error": exc.message}, exc.status)
        except (ConfigError, StudyStateError) as exc:
            return json_response(start_response, {"error": str(exc)}, 409)
        except Exception as exc:  # keep participant-facing failures non-diagnostic
            print(f"Unhandled server error: {exc}", file=sys.stderr)
            return json_response(start_response, {"error": "Internal server error."}, 500)

    return application


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--server", choices=("wsgiref", "waitress"), default="wsgiref")
    parser.add_argument("--mode", choices=("demo", "live"), default=os.environ.get("STUDY_MODE", "demo"))
    parser.add_argument("--config", default=str(ROOT / "config" / "study.json"))
    parser.add_argument("--manifest", default=str(ROOT / "study-manifest.json"))
    parser.add_argument("--db", default=str(ROOT / "data" / "study.sqlite3"))
    parser.add_argument("--secure-cookie", action="store_true", default=os.environ.get("STUDY_SECURE_COOKIE", "0") == "1")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    secret = os.environ.get("STUDY_SECRET")
    admin_token = os.environ.get("STUDY_ADMIN_TOKEN")
    if args.mode == "live" and (not secret or not admin_token):
        raise SystemExit("Live mode requires STUDY_SECRET and STUDY_ADMIN_TOKEN.")
    if args.mode == "live" and not args.secure_cookie:
        raise SystemExit("Live mode requires --secure-cookie and HTTPS termination.")
    if args.mode == "live" and args.server == "wsgiref":
        raise SystemExit("Live mode rejects the development-only wsgiref server.")
    app = create_app(args.config, args.db, mode=args.mode, secret=secret, admin_token=admin_token, secure_cookie=args.secure_cookie, manifest_path=args.manifest)
    if args.server == "waitress":
        try:
            from waitress import serve
        except ImportError as exc:
            raise SystemExit("Waitress is not installed. Run: pip install waitress") from exc
        serve(app, host=args.host, port=args.port)
    else:
        with make_server(args.host, args.port, app) as httpd:
            print(f"Legal XAI study running at http://{args.host}:{args.port}")
            httpd.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
