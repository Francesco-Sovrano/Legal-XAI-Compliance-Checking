#!/usr/bin/env python3
"""Verify the MDR controlled stimulus and its researcher-only benchmark metadata."""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
config = json.load(open(ROOT / "config/study.json", encoding="utf-8"))
bench = json.load(open(ROOT / "benchmark/results/case_study.json", encoding="utf-8"))
module = config["modules"]["clinical_empirical"]
errors: list[str] = []

prov = module.get("evidence_provenance", {})
if module.get("study_type") != "controlled_profile":
    errors.append("Clinical module must be a controlled_profile after the diabetes rewrite.")
if prov.get("status") != "controlled-by-construction":
    errors.append("Clinical evidence provenance must be controlled-by-construction.")
if prov.get("protocol_id") != "DIABETES-MDR-CONTROLLED-STIMULUS-1.2":
    errors.append("Unexpected controlled-stimulus protocol id.")
records = prov.get("condition_records", {})
for condition in module.get("conditions", []):
    if condition.get("id") not in records:
        errors.append(f"Missing controlled-stimulus provenance record for {condition.get('id')}.")

# The WDBC benchmark is available only for researcher-side
# methodological traceability. Preserve literature score bindings without
# surfacing WDBC measurements as evidence about the diabetes scenario.
method_map = {
    "clinical-pdp": "PDP",
    "clinical-tree": "Tree surrogate",
}
results = {row["method"]: row for row in bench.get("results", [])}
for condition in module.get("conditions", []):
    cid = condition.get("id")
    from framework_scoring import METHOD_PROPERTY_PRIORS, MDR_REQUIREMENTS, score_method
    profiles = {"clinical-shap": "Global SHAP summaries", "clinical-ruleshap": "RuleSHAP", "clinical-pdp": "PDP", "clinical-tree": "Decision Trees"}
    profile = profiles.get(cid)
    if profile is None:
        errors.append(f"Unknown MDR participant condition: {cid}.")
        continue
    # Recompute current priors independently of the retained, rounded WDBC
    # benchmark. Benchmark measurements and researcher priors are not participant stimuli.
    expected = score_method(METHOD_PROPERTY_PRIORS[profile], MDR_REQUIREMENTS).overall
    if not math.isclose(float(condition["literature_score"]), expected, abs_tol=1e-6):
        errors.append(f"{cid} fit prior drifted from {profile}.")
    if condition["property_scores"] != METHOD_PROPERTY_PRIORS[profile]:
        errors.append(f"{cid} property profile drifted from {profile}.")
    if cid == "clinical-shap" and condition["method_identity"] != profile:
        errors.append("Clinical population output must identify the global SHAP profile.")

case = module.get("cases", [{}])[0]
case_blob = json.dumps(case, ensure_ascii=False).lower()
for required in ("diabetes", "physician", "confirmatory"):
    if required not in case_blob:
        errors.append(f"Clinical case is missing required narrative concept: {required}.")
for required_field in ("hba1c", "fasting blood glucose", "body-mass index", "age"):
    if required_field not in case_blob:
        errors.append(f"Clinical case is missing plain-language input context: {required_field}.")

participant_payload = {
    "label": module.get("label"),
    "domain": module.get("domain"),
    "provision_label": module.get("provision_label"),
    "legal_question": module.get("legal_question"),
    "legal_objective": module.get("legal_objective"),
    "evidence_guide": module.get("evidence_guide"),
    "legal_brief": module.get("legal_brief"),
    "cases": module.get("cases"),
    "comparison_case": module.get("comparison_case"),
    "conditions": [
        {
            "explanation": c.get("explanation"),
            "assurance": c.get("assurance"),
            "evidence_metrics": c.get("evidence_metrics"),
            "target_question_text": c.get("target_question_text"),
        }
        for c in module.get("conditions", [])
    ],
    "checklist": module.get("checklist"),
}
shown = json.dumps(participant_payload, ensure_ascii=False).lower()
for forbidden in (
    "wdbc",
    "worst concave",
    "worst area",
    "worst perimeter",
    "worst radius",
    "jaccard",
    "calibration r²",
    "calibration r2",
    "calibration population",
    "mean absolute contribution",
    "audited records",
    "global additive-attribution",
    "uncalibrated class score",
):
    if forbidden in shown:
        errors.append(f"Participant-facing MDR material still contains benchmark jargon: {forbidden!r}.")

# The participant-facing technical report must explain the properties it asks
# legal experts to use, rather than require machine-learning knowledge.
guide = module.get("evidence_guide", {})
for key in module.get("assurance_schema", []):
    item = guide.get(key, {})
    if not item.get("property") or not item.get("definition"):
        errors.append(f"Technical evidence guide {key} lacks a plain-language property definition.")
for condition in module.get("conditions", []):
    assurance = condition.get("assurance", {})
    metrics = condition.get("evidence_metrics", {})
    scores = condition.get("property_scores", {})
    expected_scores = {key: float(scores[key]) for key in module.get("assurance_schema", [])}
    for key in module.get("assurance_schema", []):
        if not str(assurance.get(key, "")).strip():
            errors.append(f"{condition.get('id')} lacks plain-language technical evidence for {key}.")
        metric = metrics.get(key, {})
        if not metric.get("score") or not metric.get("label"):
            errors.append(f"{condition.get('id')} lacks a numeric explanation-quality rating for {key}.")
            continue
        if not math.isclose(float(metric["score"]), expected_scores[key], rel_tol=0, abs_tol=1e-12):
            errors.append(f"{condition.get('id')} rating for {key} drifted from the configured catalogue property ratings.")

# The MDR participant stimulus is system-level and pre-use.
for condition in module.get("conditions", []):
    output = condition.get("explanation", {}).get("xai_output", {})
    if output.get("scope_label") != "Across reference patients":
        errors.append(f"{condition.get('id')} must be labelled as covering reference patients.")
    if not output.get("title") or not output.get("kind"):
        errors.append(f"{condition.get('id')} lacks a structured explanation title or kind.")
    if output.get("kind") == "local_surrogate" or output.get("patient_path"):
        errors.append(f"{condition.get('id')} contains a patient-specific MDR explanation artifact.")
    if not output.get("question"):
        errors.append(f"{condition.get('id')} lacks the explanation question.")
    if not output.get("text_representation"):
        errors.append(f"{condition.get('id')} lacks the plain-language interpretive summary.")
    if "subtitle" in output or "help" in output:
        errors.append(f"{condition.get('id')} still contains redundant auxiliary explanation copy.")

expected_mdr = "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A02017R0745-20260719"
if module.get("provision", {}).get("authority_url") != expected_mdr:
    errors.append("MDR authority URL is not the requested official consolidated EUR-Lex text.")

if not module.get("comparison_enabled"):
    errors.append("Clinical comparison must remain enabled.")

if errors:
    print("CONTROLLED MDR STIMULUS CHECK FAILED")
    for error in errors:
        print("-", error)
    raise SystemExit(1)

print("CONTROLLED MDR STIMULUS CHECK OK")
print("Participant-facing material uses the stipulated diabetes case and 1 to 5 technical-property ratings.")
print("Retained WDBC measurements are researcher-only development metadata, not clinical-validation evidence.")
