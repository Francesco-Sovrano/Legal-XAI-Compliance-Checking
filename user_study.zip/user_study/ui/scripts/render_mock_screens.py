#!/usr/bin/env python3
"""Render deterministic study mock screens for documentation and visual QA.

The script does not start the study server and does not write participant data.
It inlines the same Vue runtime, templates, CSS and study configuration used by
`demo` mode, renders representative states, and records browser/page errors and
horizontal overflow findings.
"""
from __future__ import annotations

import json
import os
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = ROOT / ".artifacts" / "screenshots"
REPORT = ROOT / ".artifacts" / "mock-render" / "report.json"


def chromium_path() -> str | None:
    candidates = [
        os.environ.get("CHROMIUM_PATH"),
        shutil.which("chromium"),
        shutil.which("chromium-browser"),
        shutil.which("google-chrome"),
        shutil.which("google-chrome-stable"),
    ]
    return next((value for value in candidates if value), None)


def inline_participant(query: str, config_text: str) -> str:
    html = (ROOT / "static" / "index.html").read_text()
    css = (ROOT / "static" / "assets" / "styles.css").read_text()
    vue = (ROOT / "static" / "assets" / "vendor" / "vue.global.prod.js").read_text()
    app = (ROOT / "static" / "assets" / "app.js").read_text()
    html = re.sub(r'<link rel="stylesheet" href="/assets/styles\.css">', f"<style>{css}</style>", html)
    html = html.replace('<script src="/assets/vendor/vue.global.prod.js"></script>', "")
    html = html.replace('<script src="/assets/app.js"></script>', "")
    app = app.replace("new URLSearchParams(window.location.search)", f"new URLSearchParams({json.dumps(query)})")
    app = app.replace('window.location.pathname.indexOf("/static/") >= 0', "true")
    fetch_stub = (
        "<script>window.fetch=async function(){return new Response("
        + json.dumps(config_text)
        + ",{status:200,headers:{'Content-Type':'application/json'}});};</script>"
    )
    return html.replace("</body>", f"<script>{vue}</script>{fetch_stub}<script>{app}</script></body>")


def inline_admin(config_text: str) -> str:
    html = (ROOT / "static" / "admin.html").read_text()
    css = (ROOT / "static" / "assets" / "styles.css").read_text() + "\n" + (ROOT / "static" / "assets" / "admin.css").read_text()
    vue = (ROOT / "static" / "assets" / "vendor" / "vue.global.prod.js").read_text()
    script = (ROOT / "static" / "assets" / "admin.js").read_text()
    html = re.sub(r'<link rel="stylesheet" href="/assets/styles\.css">', "", html)
    html = re.sub(r'<link rel="stylesheet" href="/assets/admin\.css">', f"<style>{css}</style>", html)
    html = html.replace('<script src="/assets/vendor/vue.global.prod.js"></script>', "")
    html = html.replace('<script src="/assets/admin.js"></script>', "")
    script = script.replace("new URLSearchParams(window.location.search)", 'new URLSearchParams("mock=1")')
    script = script.replace("var hash = await sha256(config);", 'var hash = "mock-config-hash-for-visual-render";')
    fetch_stub = (
        "<script>window.fetch=async function(){return new Response("
        + json.dumps(config_text)
        + ",{status:200,headers:{'Content-Type':'application/json'}});};</script>"
    )
    return html.replace("</body>", f"<script>{vue}</script>{fetch_stub}<script>{script}</script></body>")


def inline_workflow() -> str:
    html = (ROOT / "static" / "workflow.html").read_text()
    css = (ROOT / "static" / "assets" / "workflow.css").read_text()
    return re.sub(r'<link rel="stylesheet" href="/assets/workflow\.css">', f"<style>{css}</style>", html)


def overflow_report(page) -> dict:
    return page.evaluate(
        """() => ({
          viewportWidth: window.innerWidth,
          documentWidth: Math.max(document.documentElement.scrollWidth, document.body.scrollWidth),
          overflow: Math.max(document.documentElement.scrollWidth, document.body.scrollWidth) > window.innerWidth + 2
        })"""
    )


def main() -> int:
    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:  # pragma: no cover - environment dependency
        print(f"Playwright unavailable: {exc}")
        return 2

    executable = chromium_path()
    if not executable:
        print("No Chromium executable found. Set CHROMIUM_PATH or install Chromium.")
        return 2

    out = DEFAULT_OUT
    out.mkdir(parents=True, exist_ok=True)
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    for old in out.glob("*.png"):
        old.unlink()

    config_text = (ROOT / "config" / "study.json").read_text()
    cases = [
        ("01-entry", inline_participant("mock=1", config_text), 1440, 1000),
        ("02-orientation", inline_participant("mock=1&screen=orientation&module=credit_authority", config_text), 1440, 1000),
        ("02b-orientation-clinical", inline_participant("mock=1&screen=orientation&module=clinical_empirical", config_text), 1440, 1000),
        ("03-primary-clinical", inline_participant("mock=1&screen=trial&module=clinical_empirical&condition=0", config_text), 1440, 1000),
        ("03i-primary-clinical-pdp", inline_participant("mock=1&screen=trial&module=clinical_empirical&condition=1", config_text), 1440, 1000),
        ("03j-primary-clinical-tree", inline_participant("mock=1&screen=trial&module=clinical_empirical&condition=2", config_text), 1440, 1000),
        ("03k-primary-clinical-rules", inline_participant("mock=1&screen=trial&module=clinical_empirical&condition=3", config_text), 1440, 1000),
        ("03c-primary-credit", inline_participant("mock=1&screen=trial&module=credit_authority&condition=0", config_text), 1440, 1000),
        ("03f-primary-credit-b", inline_participant("mock=1&screen=trial&module=credit_authority&condition=1", config_text), 1440, 1000),
        ("03g-primary-credit-c", inline_participant("mock=1&screen=trial&module=credit_authority&condition=2", config_text), 1440, 1000),
        ("03h-primary-credit-d", inline_participant("mock=1&screen=trial&module=credit_authority&condition=3", config_text), 1440, 1000),
        ("03d-primary-clinical-report-open", inline_participant("mock=1&screen=trial&module=clinical_empirical&condition=0", config_text), 1440, 1000),
        ("03e-primary-credit-report-open", inline_participant("mock=1&screen=trial&module=credit_authority&condition=0", config_text), 1440, 1000),
        ("03a-primary-clinical-1024", inline_participant("mock=1&screen=trial&module=clinical_empirical&condition=0", config_text), 1024, 900),
        ("03b-primary-clinical-860", inline_participant("mock=1&screen=trial&module=clinical_empirical&condition=0", config_text), 860, 900),
        ("04-comparison", inline_participant("mock=1&screen=ranking&module=credit_authority", config_text), 1440, 1000),
        ("04a-comparison-credit-score-bearing", inline_participant("mock=1&screen=ranking&module=credit_authority&label=B", config_text), 1254, 1252),
        ("04b-comparison-clinical", inline_participant("mock=1&screen=ranking&module=clinical_empirical", config_text), 1440, 1000),
        ("05-checklist", inline_participant("mock=1&screen=checklist&module=credit_authority", config_text), 1440, 1000),
        ("06-researcher", inline_admin(config_text), 1440, 1000),
        ("07-workflow", inline_workflow(), 1440, 1000),
        ("08-mobile-primary", inline_participant("mock=1&screen=trial&module=clinical_empirical&condition=0", config_text), 390, 844),
    ]

    records = []
    failures = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, executable_path=executable, args=["--no-sandbox"])
        try:
            for name, html, width, height in cases:
                page = browser.new_page(viewport={"width": width, "height": height})
                page_errors: list[str] = []
                console_errors: list[str] = []
                page.on("pageerror", lambda exc, bucket=page_errors: bucket.append(str(exc)))
                page.on("console", lambda msg, bucket=console_errors: bucket.append(msg.text) if msg.type == "error" else None)
                page.set_content(html, wait_until="networkidle")
                page.wait_for_timeout(250)
                if name.endswith("-report-open"):
                    page.locator(".full-report-button").click()
                    page.wait_for_timeout(150)
                vue_version = page.evaluate("typeof Vue !== 'undefined' ? Vue.version : null")
                overflow = overflow_report(page)
                target = out / f"{name}.png"
                page.screenshot(path=str(target), full_page=True)
                record = {
                    "name": name,
                    "viewport": [width, height],
                    "vue_version": vue_version,
                    "page_errors": page_errors,
                    "console_errors": console_errors,
                    "horizontal_overflow": overflow,
                    "screenshot": str(target.relative_to(ROOT)),
                }
                records.append(record)
                if page_errors or console_errors or overflow["overflow"]:
                    failures.append(name)
                if name != "07-workflow" and vue_version != "3.5.13":
                    failures.append(name + ":vue")
                page.close()
        finally:
            browser.close()

    report = {
        "status": "pass" if not failures else "fail",
        "renderer": executable,
        "checks": records,
        "failures": sorted(set(failures)),
        "note": "Deterministic mock rendering validates layout/error conditions. Institutional supported-browser and assistive-technology acceptance remains a fieldwork gate.",
    }
    REPORT.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
