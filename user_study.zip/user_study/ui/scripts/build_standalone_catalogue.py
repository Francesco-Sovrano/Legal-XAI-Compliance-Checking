"""Embed authoritative profiles and comments in the independently runnable script."""
import json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def build():
 C=json.loads((R/'algorithm_profiles.json').read_text());S=json.loads((R/'literature_sources.json').read_text())
 f=R/'assess_xai_compliance.py';s=f.read_text();a=s.index('LITERATURE_SOURCES =');b=s.index('# add model families',a)
 block='LITERATURE_SOURCES = '+repr({k:v['url'] for k,v in S.items()})+'\n\n'
 for group in ['model_agnostic','model_specific']:
  block+='algorithms_'+group+' = {\n'
  for n,p in C.items():
   if p['group']!=group:continue
   block+=f'    # {p["assumptions"]}\n    {n!r}: {{\n        "subprops": {{\n'
   for k,v in p['subprops'].items():
    e=p['evidence'][k];block+=f'            # [{", ".join(e["sources"])}] {e["rationale"]}\n            {k!r}: {v},\n'
   block+='        },\n'
   for k in ['scope_stage','models','required_access','requires_model_replacement','component_only','explanation_target']:
    if k in p:block+=f'        {k!r}: {p[k]!r},\n'
   # Stable literal ordering makes independent rebuilds byte-identical.
   questions=', '.join(repr(q) for q in sorted(p["question_types"]))
   block+=f'        "question_types": {{{questions}}},\n    }},\n'
  block+='}\n\n'
 f.write_text(s[:a]+block+s[b:])
if __name__=='__main__':build()
