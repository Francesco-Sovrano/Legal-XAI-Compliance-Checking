"""Regenerate study scores, evidence text and predictions from the current catalogue."""
import json,sys,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from framework_scoring import ALGORITHM_PROFILES,SHAP_PROFILES,score_method
MAP={'credit-authority-a':'Approximate local SHAP','credit-authority-b':'PDP','credit-authority-c':'CEM','credit-authority-d':'DiCE','clinical-shap':'Global SHAP summaries','clinical-pdp':'PDP','clinical-tree':'Decision Trees','clinical-ruleshap':'RuleSHAP'}
PROPERTY_KEYS=['no_false_positives','no_false_negatives','completeness','stability','adversarial_robustness','consistency','hyperparameters_perturbation_robustness','sparsity','level_of_detail','confidentiality','traceability','runtime_performance_and_implementation_constraints']
GROUPS={key:[key] for key in PROPERTY_KEYS}
def sync():
 path=ROOT/'config/study.json';c=json.loads(path.read_text());sources=json.loads((ROOT/'literature_sources.json').read_text())
 c['method_catalogue'] = [{'name':n,**p,'category_alignment':{mid:score_method(p['subprops'],m['requirement_weights']).overall for mid,m in c['modules'].items()}} for n,p in ALGORITHM_PROFILES.items()]
 for m in c['modules'].values():
  # The evidence guide is shared across methods and legal contexts.
  m['shap_variant_comparison']=[{'name':n,'scope_stage':p['scope_stage'],'description':p['description'],'status':p['status'],'score':score_method(p['subprops'],m['requirement_weights']).overall,'properties':p['subprops']} for n,p in SHAP_PROFILES.items()]
  m['framework_scoring']['source']='Literature-informed comparative catalogue; independent expert adjudication pending.'
  for t in m['conditions']:
   n=MAP[t['id']];p=ALGORITHM_PROFILES[n];scores=p['subprops']
   t['method_identity']=t['literature_method']=n;t['property_scores']=scores.copy()
   t['property_score_comments']={k:e['rationale']+' ['+', '.join(e['sources'])+']; '+e['confidence']+' confidence in comparative coding.' for k,e in p['evidence'].items()}
   t['score_sources']={key:sources[key] for e in p['evidence'].values() for key in e['sources']}
   t['score_provenance']={'method_assumptions':p['assumptions'],'methodology':'Comparative integer 1–5 ratings use 3 as the neutral midpoint and the property definitions in SCORING_METHODOLOGY.md. Evidence, assumptions and source references are recorded in SCORE_EVIDENCE_LEDGER.md. Magnitudes are coding judgments rather than measured legal-compliance scores.','status':p['status']}
   # Evidence IDs and method identities are researcher-only metadata.
   facts={};t['evidence_metrics']={}
   for g,props in GROUPS.items():
    v=float(scores[g]);support=[g.replace('_',' ').capitalize()+f': {scores[g]}/5']
    rationale=' '.join(p['rationale'][k] for k in props)
    for name in sorted(ALGORITHM_PROFILES,key=len,reverse=True):rationale=re.sub(r'(?<!\w)'+re.escape(name)+r'(?!\w)','this method',rationale,flags=re.I)
    for token in ['SHAP','Shapley','TCAV','KernelSHAP','DeepLIFT','DeepExplainer']:rationale=re.sub(r'(?<!\w)'+re.escape(token)+r'(?!\w)','the method',rationale,flags=re.I)
    facts[g]=rationale.strip()
    t['evidence_metrics'][g]={'score':v,'display':f'{int(v) if v.is_integer() else v}/5','label':'Very strong' if v>=4.5 else 'Strong' if v>=3.5 else 'Moderate' if v>=2.5 else 'Limited','support':support}
   t['assurance']=facts.copy();t.pop('evidence_examples',None)
   fit=t['procedural_fit'];fit=fit if isinstance(fit,bool) else all(fit.get(k,False) for k in ['question','scope','stage','feasible'])
   if not fit:t['score_provenance']['procedural_fit']='The displayed global curve does not establish the individual explanatory scope required here; fit prior is zero.'
   t['literature_score']=score_method(scores,m['requirement_weights'],procedural_fit=fit).overall
  for i,t in enumerate(sorted(m['conditions'],key=lambda t:-t['literature_score']),1):t['framework_rank']=i
  byid={t['id']:t for t in m['conditions']}
  # Set the declared direction from the configured scores within each matched pair.
  for field in ['matched_predictions','confirmatory_contrasts']:
   for pair in m.get(field,[]):
    first,second=sorted([byid[pair['better']],byid[pair['worse']]],key=lambda t:-t['literature_score'])
    pair.update(id='audit-'+first['id']+'-over-'+second['id'],better=first['id'],worse=second['id'],basis=f"Ordinal ratings: {first['method_identity']} {first['literature_score']:.6f} > {second['method_identity']} {second['literature_score']:.6f}.")
 path.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':sync()
