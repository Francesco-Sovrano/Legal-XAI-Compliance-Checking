"""Regenerate current property-evidence outputs from the authoritative catalogue."""
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def export():
    profiles = json.loads((ROOT / 'algorithm_profiles.json').read_text())
    sources = json.loads((ROOT / 'literature_sources.json').read_text())
    rows = []
    ledger = [
        '# Property evidence ledger',
        '',
        'This ledger records the current comparative 1–5 property ratings, their rationale and their evidence basis. '
        'The ratings are literature-informed coding judgments, not measured legal-compliance scores. '
        'See `SCORING_METHODOLOGY.md` for the rating procedure.',
        '',
    ]
    for name, profile in profiles.items():
        ledger += [
            '## ' + name,
            '',
            profile['assumptions'],
            '',
            '| Property | Rating | Rationale | Evidence basis / confidence | Sources |',
            '|---|---:|---|---|---|',
        ]
        for prop, score in profile['subprops'].items():
            e = profile['evidence'][prop]
            assert e['score'] == score and e['rationale'] == profile['rationale'][prop]
            links = '; '.join(sources[k]['url'] for k in e['sources'])
            rows.append(dict(
                algorithm=name,
                property=prop,
                score=score,
                rationale=e['rationale'],
                sources=links,
                source_locators='; '.join(k + ': ' + v for k, v in e['source_locators'].items()),
                basis=e['basis'],
                confidence=e['confidence'],
                target=profile['explanation_target'],
            ))
            refs = ', '.join(f'[{k}]({sources[k]["url"]})' for k in e['sources'])
            cells = [prop.replace('_', ' '), score, e['rationale'], e['basis'] + '; ' + e['confidence'], refs]
            ledger.append('| ' + ' | '.join(str(x).replace('|', '\\|') for x in cells) + ' |')
        ledger.append('')

    out = ROOT / 'output' / 'property_scores.csv'
    with out.open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (ROOT / 'SCORE_EVIDENCE_LEDGER.md').write_text('\n'.join(ledger) + '\n')

    import assess_xai_compliance as a
    a.assess_xai_algorithms(a.algorithms_model_agnostic).to_csv(ROOT / 'output/best_model_agnostic.csv', index=False)
    a.assess_xai_algorithms({**a.algorithms_model_agnostic, **a.algorithms_model_specific}).to_csv(ROOT / 'output/best_all_methods.csv', index=False)
    print(f'Exported {len(rows)} current evidence rows across {len(profiles)} profiles.')


if __name__ == '__main__':
    export()
