#!/usr/bin/env python3
"""Compute predictive and explanation metrics for a WDBC random forest.

The continuous-feature LIME implementation uses Gaussian perturbations in
standardized space, an exponential kernel, highest-weight feature selection
and ridge regression. Technical metrics and legal-expert judgments are exported
as separate measurements.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Mapping, Sequence, Tuple

import joblib
import numpy as np
import pandas as pd
import shap
import sklearn
from scipy.stats import spearmanr
from sklearn.datasets import load_breast_cancer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import Ridge
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    brier_score_loss,
    confusion_matrix,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
    r2_score,
)
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor

SEED = 1729
TOP_K = 4
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
BENCHMARK_DIR = ROOT / "benchmark"
RESULTS_DIR = BENCHMARK_DIR / "results"
DATA_DIR = BENCHMARK_DIR / "data"
MODEL_DIR = BENCHMARK_DIR / "model"


@dataclass(frozen=True)
class LimeConfig:
    n_samples: int
    kernel_width_multiplier: float
    ridge_alpha: float = 1.0
    num_features: int = TOP_K
    sample_around_instance: bool = False
    discretize_continuous: bool = False

    @property
    def kernel_width(self) -> float:
        return self.kernel_width_multiplier * math.sqrt(30.0)


# The study baseline uses 1000 samples for tractable repeated testing; the
# 0.75*sqrt(p) kernel and Ridge(alpha=1) follow LIME's documented defaults. Continuous-feature discretisation is
# intentionally disabled to retain original feature identities in the study.
BASELINE_LIME = LimeConfig(n_samples=1000, kernel_width_multiplier=0.75)
LIME_GRID = [
    LimeConfig(150, 0.25),
    LimeConfig(500, 0.50),
    LimeConfig(1000, 0.75),
    LimeConfig(1500, 1.00),
    LimeConfig(2400, 1.50),
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def model_probability(model: RandomForestClassifier, X: np.ndarray) -> np.ndarray:
    """Return the RF class score for malignant (sklearn class 0)."""
    return model.predict_proba(X)[:, 0]


def standardize(X: np.ndarray, mean: np.ndarray, scale: np.ndarray) -> np.ndarray:
    return (X - mean) / scale


def cosine_abs(a: np.ndarray, b: np.ndarray) -> float:
    a = np.abs(a)
    b = np.abs(b)
    den = float(np.linalg.norm(a) * np.linalg.norm(b))
    return float(np.dot(a, b) / den) if den else 0.0


def topk(weights: np.ndarray, k: int = TOP_K) -> np.ndarray:
    return np.argsort(-np.abs(weights))[:k]


def jaccard(a: Sequence[int], b: Sequence[int]) -> float:
    sa, sb = set(map(int, a)), set(map(int, b))
    return len(sa & sb) / len(sa | sb) if (sa or sb) else 1.0


def rank_agreement(a: np.ndarray, b: np.ndarray) -> float:
    rho = spearmanr(np.abs(a), np.abs(b)).statistic
    if np.isnan(rho):
        return 0.0
    return float((rho + 1.0) / 2.0)


def weighted_r2(y: np.ndarray, yhat: np.ndarray, w: np.ndarray) -> float:
    return float(np.clip(r2_score(y, yhat, sample_weight=w), 0.0, 1.0))


def lime_kernel(distances: np.ndarray, kernel_width: float) -> np.ndarray:
    # Mirrors LIME's default kernel: sqrt(exp(-(d^2)/(kernel_width^2))).
    return np.sqrt(np.exp(-(distances**2) / max(kernel_width**2, 1e-12)))


def lime_neighbourhood(
    x: np.ndarray,
    mean: np.ndarray,
    scale: np.ndarray,
    n: int,
    seed: int,
    kernel_width: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Continuous-feature LimeTabularExplainer-style Gaussian neighbourhood."""
    rng = np.random.default_rng(seed)
    z = rng.normal(0.0, 1.0, size=(n, x.size))
    X = z * scale + mean
    # LIME explicitly places the original row first.
    X[0] = x
    z = standardize(X, mean, scale)
    z0 = standardize(x, mean, scale)
    distances = np.linalg.norm(z - z0, axis=1)
    weights = lime_kernel(distances, kernel_width)
    return X, z, weights


def highest_weights_select(
    z: np.ndarray,
    y: np.ndarray,
    w: np.ndarray,
    *,
    num_features: int,
) -> List[int]:
    """LIME ``highest_weights`` feature selection for dense tabular data.

    LIME fits a Ridge(alpha=0.01) model to all interpretable features and ranks
    the product of coefficient and the original interpretable row. We use the
    same documented option explicitly because repeated stability testing would
    make the default forward-selection path unnecessarily expensive.
    """
    clf = Ridge(alpha=0.01)
    clf.fit(z, y, sample_weight=w)
    weighted = clf.coef_ * z[0]
    return [int(i) for i in np.argsort(-np.abs(weighted))[:num_features]]


def lime_explain_detailed(
    model: RandomForestClassifier,
    x: np.ndarray,
    mean: np.ndarray,
    scale: np.ndarray,
    config: LimeConfig,
    seed: int,
) -> dict:
    t0 = time.perf_counter()
    X, z, w = lime_neighbourhood(
        x, mean, scale, config.n_samples, seed, config.kernel_width
    )
    y = model_probability(model, X)
    selected = highest_weights_select(z, y, w, num_features=config.num_features)
    reg = Ridge(alpha=config.ridge_alpha)
    reg.fit(z[:, selected], y, sample_weight=w)
    native_score = float(np.clip(reg.score(z[:, selected], y, sample_weight=w), 0.0, 1.0))

    # Independent neighbourhood for out-of-sample local fidelity.
    Xv, zv, wv = lime_neighbourhood(x, mean, scale, 300, seed + 100_000, config.kernel_width)
    independent_fidelity = weighted_r2(
        model_probability(model, Xv), reg.predict(zv[:, selected]), wv
    )

    full_coef = np.zeros(x.size, dtype=float)
    for local_i, feature_i in enumerate(selected):
        full_coef[feature_i] = float(reg.coef_[local_i])
    z0 = standardize(x, mean, scale)
    local_pred = float(reg.predict(z0[selected].reshape(1, -1))[0])
    elapsed = time.perf_counter() - t0
    return {
        "weights": full_coef,
        "independent_local_fidelity": independent_fidelity,
        "native_weighted_neighbourhood_r2": native_score,
        "intercept": float(reg.intercept_),
        "local_prediction": local_pred,
        "selected": selected,
        "elapsed": elapsed,
    }


def lime_explain(
    model: RandomForestClassifier,
    x: np.ndarray,
    mean: np.ndarray,
    scale: np.ndarray,
    config: LimeConfig,
    seed: int,
) -> Tuple[np.ndarray, float, float]:
    d = lime_explain_detailed(model, x, mean, scale, config, seed)
    return d["weights"], d["independent_local_fidelity"], d["elapsed"]


def fit_tree_surrogate(
    model: RandomForestClassifier,
    train_X: np.ndarray,
    eval_X: np.ndarray,
    depth: int,
    seed: int,
) -> Tuple[DecisionTreeRegressor, float, float]:
    t0 = time.perf_counter()
    tree = DecisionTreeRegressor(max_depth=depth, min_samples_leaf=10, random_state=seed)
    tree.fit(train_X, model_probability(model, train_X))
    fidelity = float(np.clip(
        r2_score(model_probability(model, eval_X), tree.predict(eval_X)), 0.0, 1.0
    ))
    return tree, fidelity, time.perf_counter() - t0


def tree_path_weights(tree: DecisionTreeRegressor, x: np.ndarray) -> np.ndarray:
    weights = np.zeros(tree.n_features_in_, dtype=float)
    node_ids = tree.decision_path(x.reshape(1, -1)).indices
    for node in node_ids:
        feature = int(tree.tree_.feature[node])
        if feature < 0:
            continue
        threshold = float(tree.tree_.threshold[node])
        child = (
            int(tree.tree_.children_left[node])
            if x[feature] <= threshold
            else int(tree.tree_.children_right[node])
        )
        parent_value = float(np.ravel(tree.tree_.value[node])[0])
        child_value = float(np.ravel(tree.tree_.value[child])[0])
        weights[feature] += abs(child_value - parent_value)
    return weights


def tree_path_rules(tree: DecisionTreeRegressor, x: np.ndarray, feature_names: Sequence[str]) -> List[dict]:
    rules: List[dict] = []
    node = 0
    while int(tree.tree_.feature[node]) >= 0:
        feature = int(tree.tree_.feature[node])
        threshold = float(tree.tree_.threshold[node])
        value = float(x[feature])
        go_left = value <= threshold
        rules.append({
            "feature": str(feature_names[feature]),
            "case_value": value,
            "operator": "<=" if go_left else ">",
            "threshold": threshold,
            "node_prediction": float(np.ravel(tree.tree_.value[node])[0]),
        })
        node = int(tree.tree_.children_left[node] if go_left else tree.tree_.children_right[node])
    return rules


def shap_explain(explainer: shap.TreeExplainer, x: np.ndarray) -> Tuple[np.ndarray, float, float, float]:
    t0 = time.perf_counter()
    values = explainer.shap_values(x.reshape(1, -1))
    if isinstance(values, list):
        weights = np.asarray(values[0])[0]
        expected = float(np.asarray(explainer.expected_value)[0])
    else:
        arr = np.asarray(values)
        if arr.ndim == 3:
            weights = arr[0, :, 0]
            expected = float(np.asarray(explainer.expected_value)[0])
        else:
            weights = arr[0]
            expected = float(np.asarray(explainer.expected_value).reshape(-1)[0])
    reconstructed = float(expected + weights.sum())
    return weights.astype(float), reconstructed, time.perf_counter() - t0, expected


def pdp_effects(
    model: RandomForestClassifier,
    train_X: np.ndarray,
    quantiles: Sequence[float] = (0.10, 0.25, 0.50, 0.75, 0.90),
) -> Tuple[np.ndarray, List[dict], float]:
    """Return global PDP effect ranges and the underlying grid-response records."""
    t0 = time.perf_counter()
    qs = np.quantile(train_X, quantiles, axis=0)
    out = np.zeros(train_X.shape[1], dtype=float)
    details: List[dict] = []
    base = train_X[: min(180, len(train_X))].copy()
    for j in range(train_X.shape[1]):
        means = []
        for q_idx in range(len(quantiles)):
            Xp = base.copy()
            Xp[:, j] = qs[q_idx, j]
            means.append(float(model_probability(model, Xp).mean()))
        out[j] = max(means) - min(means)
        details.append({
            "quantiles": [float(q) for q in quantiles],
            "feature_values": [float(v) for v in qs[:, j]],
            "mean_malignant_class_scores": means,
            "effect_range": float(out[j]),
        })
    return out, details, time.perf_counter() - t0


def coordinate_reference(model: RandomForestClassifier, x: np.ndarray, train_X: np.ndarray) -> np.ndarray:
    qs = np.quantile(train_X, [0.10, 0.25, 0.50, 0.75, 0.90], axis=0)
    # Vectorise all 30 x 5 interventions into one prediction call.
    blocks = []
    for j in range(x.size):
        Xp = np.repeat(x.reshape(1, -1), len(qs), axis=0)
        Xp[:, j] = qs[:, j]
        blocks.append(Xp)
    probs = model_probability(model, np.vstack(blocks)).reshape(x.size, len(qs))
    return np.ptp(probs, axis=1).astype(float)


def global_permutation_reference(model: RandomForestClassifier, eval_X: np.ndarray, *, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    baseline = model_probability(model, eval_X)
    out = np.zeros(eval_X.shape[1], dtype=float)
    for j in range(eval_X.shape[1]):
        Xp = eval_X.copy()
        Xp[:, j] = rng.permutation(Xp[:, j])
        out[j] = float(np.mean(np.abs(model_probability(model, Xp) - baseline)))
    return out


def feature_coverage(reference: np.ndarray, selected: Sequence[int]) -> float:
    mass = np.abs(reference)
    den = float(mass.sum())
    return float(mass[list(selected)].sum() / den) if den else 1.0


def generate_preserving_cases(
    model: RandomForestClassifier,
    x: np.ndarray,
    scale: np.ndarray,
    train_min: np.ndarray,
    train_max: np.ndarray,
    *,
    seed: int,
    count: int,
    max_delta: float,
    low_influence_idx: Sequence[int] | None = None,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    p0 = float(model_probability(model, x.reshape(1, -1))[0])
    y0 = p0 >= 0.5
    accepted: List[np.ndarray] = []
    attempts = 0
    while len(accepted) < count and attempts < 50_000:
        attempts += 1
        xp = x.copy()
        if low_influence_idx is None:
            xp += rng.normal(0.0, 0.025, size=x.size) * scale
        else:
            idx = np.asarray(low_influence_idx, dtype=int)
            xp[idx] += rng.normal(0.0, 0.20, size=len(idx)) * scale[idx]
        xp = np.clip(xp, train_min, train_max)
        p = float(model_probability(model, xp.reshape(1, -1))[0])
        if (p >= 0.5) == y0 and abs(p - p0) <= max_delta:
            accepted.append(xp)
    if len(accepted) < count:
        raise RuntimeError(f"Only found {len(accepted)} output-preserving perturbations")
    return np.vstack(accepted)


def nearest_prototype_output(
    model: RandomForestClassifier,
    x: np.ndarray,
    train_X: np.ndarray,
    mean: np.ndarray,
    scale: np.ndarray,
    feature_names: Sequence[str],
) -> dict:
    """Nearest same-predicted-class training example in standardized space."""
    pred = bool(model_probability(model, x.reshape(1, -1))[0] >= 0.5)
    train_pred = model_probability(model, train_X) >= 0.5
    candidates = train_X[train_pred == pred]
    z0 = standardize(x, mean, scale)
    zc = standardize(candidates, mean, scale)
    distances = np.linalg.norm(zc - z0, axis=1)
    idx = int(np.argmin(distances))
    proto = candidates[idx]
    delta_z = standardize(proto, mean, scale) - z0
    top = np.argsort(-np.abs(delta_z))[:TOP_K]
    return {
        "scope": "local case-based",
        "method": "Nearest prototype",
        "definition": "Nearest training-set record with the same model class in standardized Euclidean distance.",
        "standardized_distance": float(distances[idx]),
        "prototype_model_score": float(model_probability(model, proto.reshape(1, -1))[0]),
        "case_model_score": float(model_probability(model, x.reshape(1, -1))[0]),
        "top_differences": [
            {
                "feature": str(feature_names[j]),
                "case_value": float(x[j]),
                "prototype_value": float(proto[j]),
                "standardized_difference": float(delta_z[j]),
            } for j in top
        ],
    }


def counterfactual_output(
    model: RandomForestClassifier,
    x: np.ndarray,
    train_X: np.ndarray,
    mean: np.ndarray,
    scale: np.ndarray,
    feature_names: Sequence[str],
    *,
    max_candidates: int = 3,
) -> dict:
    """Deterministic data-manifold counterfactual search.

    The procedure finds nearby training records with the opposite model class and
    binary-searches along the segment from the case to each candidate for the
    smallest interpolation that flips the model class. It is a representative
    counterfactual-search baseline, not an implementation of DiCE or CEM.
    """
    p0 = float(model_probability(model, x.reshape(1, -1))[0])
    class0 = p0 >= 0.5
    train_scores = model_probability(model, train_X)
    opp = train_X[(train_scores >= 0.5) != class0]
    if len(opp) == 0:
        return {"scope": "local counterfactual", "method": "Counterfactual search", "success": False}
    z0 = standardize(x, mean, scale)
    zopp = standardize(opp, mean, scale)
    order = np.argsort(np.linalg.norm(zopp - z0, axis=1))[: max(12, max_candidates * 4)]
    found = []
    for idx in order:
        target = opp[int(idx)]
        lo, hi = 0.0, 1.0
        if (float(model_probability(model, target.reshape(1, -1))[0]) >= 0.5) == class0:
            continue
        for _ in range(28):
            mid = (lo + hi) / 2.0
            xm = x + mid * (target - x)
            flipped = (float(model_probability(model, xm.reshape(1, -1))[0]) >= 0.5) != class0
            if flipped:
                hi = mid
            else:
                lo = mid
        cf = x + hi * (target - x)
        cf_score = float(model_probability(model, cf.reshape(1, -1))[0])
        dz = standardize(cf, mean, scale) - z0
        proximity = float(np.linalg.norm(dz))
        changed = np.where(np.abs(dz) >= 0.10)[0]
        found.append((proximity, cf, cf_score, dz, changed))
    if not found:
        return {"scope": "local counterfactual", "method": "Counterfactual search", "success": False}
    found.sort(key=lambda row: row[0])
    selected = found[:max_candidates]
    records = []
    for proximity, cf, cf_score, dz, changed in selected:
        top = np.argsort(-np.abs(dz))[:TOP_K]
        records.append({
            "standardized_l2_proximity": proximity,
            "model_score": cf_score,
            "changed_feature_count_abs_z_ge_0_10": int(len(changed)),
            "top_changes": [
                {
                    "feature": str(feature_names[j]),
                    "case_value": float(x[j]),
                    "counterfactual_value": float(cf[j]),
                    "standardized_change": float(dz[j]),
                } for j in top
            ],
        })
    return {
        "scope": "local counterfactual",
        "method": "Deterministic counterfactual search",
        "success": True,
        "case_model_score": p0,
        "target": "opposite model class",
        "algorithm_note": "Nearest opposite-class training records plus binary search along data-supported line segments; representative research baseline, not DiCE/CEM.",
        "counterfactuals": records,
    }


def counterfactual_cross_case_summary(
    model: RandomForestClassifier,
    X_test: pd.DataFrame,
    train_X: np.ndarray,
    mean: np.ndarray,
    scale: np.ndarray,
    feature_names: Sequence[str],
) -> dict:
    successes = []
    proximities = []
    changed_counts = []
    for _, row in X_test.iterrows():
        out = counterfactual_output(model, row.to_numpy(dtype=float), train_X, mean, scale, feature_names, max_candidates=1)
        successes.append(bool(out.get("success")))
        if out.get("success"):
            rec = out["counterfactuals"][0]
            proximities.append(float(rec["standardized_l2_proximity"]))
            changed_counts.append(int(rec["changed_feature_count_abs_z_ge_0_10"]))
    return {
        "n": int(len(successes)),
        "success_rate": float(np.mean(successes)),
        "mean_standardized_l2_proximity_successes": float(np.mean(proximities)) if proximities else None,
        "median_changed_feature_count_successes": float(np.median(changed_counts)) if changed_counts else None,
    }


def efficiency_score(seconds: float) -> float:
    if seconds <= 2.0:
        return 1.0
    if seconds >= 20.0:
        return 0.0
    return float((20.0 - seconds) / 18.0)




def choose_target_case(model: RandomForestClassifier, X_test: pd.DataFrame, y_test: pd.Series) -> int:
    """Choose a central correctly-classified malignant case without using XAI outputs."""
    probs = model_probability(model, X_test.to_numpy())
    malignant = np.where(y_test.to_numpy() == 0)[0]
    candidates = [i for i in malignant if probs[i] >= 0.5]
    values = np.asarray([probs[i] for i in candidates])
    target = float(np.median(values))
    return min(candidates, key=lambda i: (abs(probs[i] - target), int(X_test.index[i])))


def calibrate_lime(
    model: RandomForestClassifier,
    X_cal: pd.DataFrame,
    train_X: np.ndarray,
    mean: np.ndarray,
    scale: np.ndarray,
) -> Tuple[LimeConfig, pd.DataFrame, List[int]]:
    # Seven fixed score-quantile records improve calibration coverage while the
    # expert-study test case remains completely excluded from tuning.
    probs = model_probability(model, X_cal.to_numpy())
    order = np.argsort(probs)
    picks = np.unique(np.linspace(0, len(order) - 1, 7, dtype=int))
    cal_rows = X_cal.iloc[order[picks]]
    cal_source_indices = [int(i) for i in cal_rows.index]
    rows = []
    for cfg in LIME_GRID:
        fidelity_vals, repeat_vals, ref_vals = [], [], []
        for row_i, (_, row) in enumerate(cal_rows.iterrows()):
            x = row.to_numpy(dtype=float)
            ref = coordinate_reference(model, x, train_X)
            w0, fid, _ = lime_explain(model, x, mean, scale, cfg, SEED + 1000 + row_i)
            repeats = []
            for rep in range(2):
                wr, _, _ = lime_explain(model, x, mean, scale, cfg, SEED + 2000 + row_i * 10 + rep)
                repeats.append(jaccard(topk(w0), topk(wr)))
            fidelity_vals.append(fid)
            repeat_vals.append(float(np.mean(repeats)))
            ref_vals.append(jaccard(topk(w0), topk(ref)))
        mean_fid = float(np.mean(fidelity_vals))
        mean_rep = float(np.mean(repeat_vals))
        mean_ref = float(np.mean(ref_vals))
        objective = 0.45 * mean_fid + 0.35 * mean_rep + 0.20 * mean_ref
        rows.append({
            "n_samples": cfg.n_samples,
            "kernel_width_multiplier": cfg.kernel_width_multiplier,
            "ridge_alpha": cfg.ridge_alpha,
            "num_features": cfg.num_features,
            "calibration_records": len(cal_rows),
            "mean_independent_local_fidelity": mean_fid,
            "mean_repeat_top4_jaccard": mean_rep,
            "mean_reference_top4_jaccard": mean_ref,
            "calibration_objective": objective,
        })
    frame = pd.DataFrame(rows).sort_values(
        ["calibration_objective", "n_samples"], ascending=[False, True]
    ).reset_index(drop=True)
    winner = frame.iloc[0]
    return LimeConfig(
        int(winner.n_samples), float(winner.kernel_width_multiplier), float(winner.ridge_alpha),
        int(winner.num_features), False, False
    ), frame, cal_source_indices


def evaluate_method(
    name: str,
    explain,
    x: np.ndarray,
    reference: np.ndarray,
    near_cases: np.ndarray | None,
    stress_cases: np.ndarray | None,
    hyper_explainers: Sequence | None,
    *,
    reference_scope: str,
) -> Tuple[dict, np.ndarray]:
    weights, fidelity, runtime = explain(x, SEED)
    selected = topk(weights)
    ref_selected = topk(reference)

    repeat_js, repeat_cos = [], []
    for s in range(5):
        wr, _, _ = explain(x, SEED + 10 + s)
        repeat_js.append(jaccard(selected, topk(wr)))
        repeat_cos.append(cosine_abs(weights, wr))

    near_js: list[float] | None = None
    if near_cases is not None:
        near_js = []
        for i, xp in enumerate(near_cases):
            wp, _, _ = explain(xp, SEED + 300 + i)
            near_js.append(jaccard(selected, topk(wp)))

    stress_js: list[float] | None = None
    if stress_cases is not None:
        stress_js = []
        for i, xp in enumerate(stress_cases):
            wp, _, _ = explain(xp, SEED + 500 + i)
            stress_js.append(jaccard(selected, topk(wp)))

    hp_js: list[float] | None = None
    if hyper_explainers:
        hp_js = []
        for i, hp_explain in enumerate(hyper_explainers):
            wh, _, _ = hp_explain(x, SEED + 700 + i)
            hp_js.append(jaccard(selected, topk(wh)))

    precision = len(set(selected) & set(ref_selected)) / len(selected)
    recall = len(set(selected) & set(ref_selected)) / len(ref_selected)
    coverage = feature_coverage(reference, selected)
    subprops: dict[str, float | None] = {
        "no_false_positives": float(precision),
        "no_false_negatives": float(recall),
        "completeness": float(coverage),
        "stability": None if near_js is None else float(np.mean(near_js)),
        "adversarial_robustness": None if stress_js is None else float(np.mean(stress_js)),
        "consistency": float(np.mean(repeat_js)),
        "hyperparameters_perturbation_robustness": None if hp_js is None else float(np.mean(hp_js)),
        "runtime_performance_and_implementation_constraints": efficiency_score(runtime),
    }
    result = {
        "method": name,
        "local_fidelity": None if fidelity is None else float(fidelity),
        "reference_scope": reference_scope,
        "reference_top4_jaccard": float(jaccard(selected, ref_selected)),
        "reference_rank_agreement": rank_agreement(weights, reference),
        "reference_mass_coverage": float(coverage),
        "repeat_top4_jaccard": float(np.mean(repeat_js)),
        "repeat_abs_cosine": float(np.mean(repeat_cos)),
        "near_equivalent_top4_jaccard": None if near_js is None else float(np.mean(near_js)),
        "stress_top4_jaccard": None if stress_js is None else float(np.mean(stress_js)),
        "hyperparameter_top4_jaccard": None if hp_js is None else float(np.mean(hp_js)),
        "runtime_seconds": float(runtime),
        "top_feature_indices": selected.tolist(),
        "empirical_subproperties": subprops,
        "controlled_dossier_properties": {
            "presentation": "method-native explanation constrained to a short, comparable technical record",
            "confidentiality": "no other patient row displayed",
            "traceability": "dataset/model/configuration/result hashes retained",
        },
    }
    return result, weights


def bootstrap_ci(values: Sequence[float], *, seed: int, reps: int = 1000) -> dict:
    a = np.asarray(values, dtype=float)
    if len(a) == 0:
        return {"n": 0, "mean": None, "median": None, "mean_ci95": [None, None]}
    rng = np.random.default_rng(seed)
    means = np.empty(reps)
    for i in range(reps):
        means[i] = rng.choice(a, size=len(a), replace=True).mean()
    return {
        "n": int(len(a)),
        "mean": float(a.mean()),
        "median": float(np.median(a)),
        "mean_ci95": [float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))],
    }


def cross_case_summary(
    model: RandomForestClassifier,
    X_test: pd.DataFrame,
    train_arr: np.ndarray,
    mean: np.ndarray,
    scale: np.ndarray,
    shap_explainer: shap.TreeExplainer,
    tree: DecisionTreeRegressor,
    tree_fidelity: float,
    lime_cfg: LimeConfig,
) -> Tuple[dict, pd.DataFrame]:
    rows: List[dict] = []
    scores = model_probability(model, X_test.to_numpy(dtype=float))
    ordered = np.argsort(scores)
    lime_positions = set(map(int, ordered[np.unique(np.linspace(0, len(ordered) - 1, 24, dtype=int))]))
    for pos, (source_idx, row) in enumerate(X_test.iterrows()):
        x = row.to_numpy(dtype=float)
        ref = coordinate_reference(model, x, train_arr)
        ref_top = topk(ref)
        pred = float(model_probability(model, x.reshape(1, -1))[0])

        sw, reconstructed, _, _ = shap_explain(shap_explainer, x)
        tw = tree_path_weights(tree, x)
        for method, weights, fidelity in [
            ("SHAP", sw, float(np.clip(1.0 - abs(reconstructed - pred), 0.0, 1.0))),
            ("Tree surrogate", tw, tree_fidelity),
        ]:
            sel = topk(weights)
            rows.append({
                "source_row_index": int(source_idx), "method": method,
                "reference_top4_jaccard": jaccard(sel, ref_top),
                "reference_mass_coverage": feature_coverage(ref, sel),
                "reference_rank_agreement": rank_agreement(weights, ref),
                "local_fidelity": fidelity,
            })

        if pos in lime_positions:
            lw = lime_explain_detailed(model, x, mean, scale, lime_cfg, SEED + 50_000 + pos)
            sel = topk(lw["weights"])
            rows.append({
                "source_row_index": int(source_idx), "method": "LIME baseline",
                "reference_top4_jaccard": jaccard(sel, ref_top),
                "reference_mass_coverage": feature_coverage(ref, sel),
                "reference_rank_agreement": rank_agreement(lw["weights"], ref),
                "local_fidelity": lw["independent_local_fidelity"],
            })
    frame = pd.DataFrame(rows)
    summary: Dict[str, dict] = {}
    for method in ["SHAP", "Tree surrogate", "LIME baseline"]:
        mf = frame[frame.method == method]
        summary[method] = {
            "audit_scope": "all 86 held-out test records" if method != "LIME baseline" else "24 deterministic test records spanning the model-score distribution",
            **{
                metric: bootstrap_ci(mf[metric].to_list(), seed=SEED + 90_000 + j)
                for j, metric in enumerate([
                    "reference_top4_jaccard", "reference_mass_coverage", "reference_rank_agreement", "local_fidelity"
                ])
            },
        }
    return summary, frame


def build_global_instruction_outputs(
    model: RandomForestClassifier,
    X_cal: pd.DataFrame,
    X_test: pd.DataFrame,
    train_arr: np.ndarray,
    mean: np.ndarray,
    scale: np.ndarray,
    shap_explainer: shap.TreeExplainer,
    tree: DecisionTreeRegressor,
    tree_fidelity: float,
    pdp_details: List[dict],
    pdp_weights: np.ndarray,
    feature_names: Sequence[str],
) -> dict:
    """Build reproducible system-level summaries for the ex-ante MDR instructions task.

    SHAP is aggregated across calibration records, PDP is already population-level,
    the decision tree is a global surrogate, and LIME is summarized across the same
    deterministic 24-record audit used in the cross-case safeguard.
    """
    shap_rows = []
    for _, row in X_cal.iterrows():
        weights, _reconstructed, _elapsed, _base = shap_explain(
            shap_explainer, row.to_numpy(dtype=float)
        )
        shap_rows.append(weights)
    shap_matrix = np.vstack(shap_rows)
    shap_mean_abs = np.mean(np.abs(shap_matrix), axis=0)
    shap_top = np.argsort(shap_mean_abs)[::-1][:TOP_K]

    pdp_top = topk(pdp_weights)
    pdp_output = []
    for i in pdp_top:
        d = pdp_details[i]
        pdp_output.append({
            "feature": str(feature_names[i]),
            "grid_low": float(d["feature_values"][0]),
            "grid_high": float(d["feature_values"][-1]),
            "score_low": float(d["mean_malignant_class_scores"][0]),
            "score_high": float(d["mean_malignant_class_scores"][-1]),
            "effect_range": float(d["effect_range"]),
        })

    tree_importance = np.asarray(tree.feature_importances_, dtype=float)
    tree_top = np.argsort(tree_importance)[::-1][:TOP_K]
    tree_rules = []
    queue = [0]
    while queue and len(tree_rules) < 8:
        node = queue.pop(0)
        feature_index = int(tree.tree_.feature[node])
        if feature_index >= 0:
            tree_rules.append({
                "feature": str(feature_names[feature_index]),
                "threshold": float(tree.tree_.threshold[node]),
                "samples": int(tree.tree_.n_node_samples[node]),
            })
            queue.extend([int(tree.tree_.children_left[node]), int(tree.tree_.children_right[node])])

    scores = model_probability(model, X_test.to_numpy(dtype=float))
    ordered = np.argsort(scores)
    lime_positions = set(map(int, ordered[np.unique(np.linspace(0, len(ordered) - 1, 24, dtype=int))]))
    lime_rows = []
    lime_fidelity = []
    for pos, (_source_idx, row) in enumerate(X_test.iterrows()):
        if pos not in lime_positions:
            continue
        detail = lime_explain_detailed(
            model, row.to_numpy(dtype=float), mean, scale, BASELINE_LIME, SEED + 50_000 + pos
        )
        lime_rows.append(detail["weights"])
        lime_fidelity.append(float(detail["independent_local_fidelity"]))
    lime_matrix = np.vstack(lime_rows)
    lime_mean_abs = np.mean(np.abs(lime_matrix), axis=0)
    lime_selected = np.sum(np.abs(lime_matrix) > 1e-12, axis=0)
    lime_top = np.argsort(lime_mean_abs)[::-1][:TOP_K]

    return {
        "SHAP": {
            "scope": "global aggregate of local additive attributions",
            "aggregation_population": f"{len(X_cal)} calibration records",
            "top_features": [
                {
                    "feature": str(feature_names[i]),
                    "mean_absolute_contribution": float(shap_mean_abs[i]),
                }
                for i in shap_top
            ],
        },
        "PDP": {
            "scope": "global partial dependence",
            "top_global_effects": pdp_output,
        },
        "Tree surrogate": {
            "scope": "global decision-tree surrogate",
            "surrogate_calibration_r2": float(tree_fidelity),
            "top_feature_importances": [
                {
                    "feature": str(feature_names[i]),
                    "importance": float(tree_importance[i]),
                }
                for i in tree_top
            ],
            "early_rules": tree_rules,
        },
        "LIME baseline": {
            "scope": "aggregate of deterministic local-surrogate audits",
            "audit_records": int(len(lime_rows)),
            "mean_independent_local_fidelity_r2": float(np.mean(lime_fidelity)),
            "min_independent_local_fidelity_r2": float(np.min(lime_fidelity)),
            "max_independent_local_fidelity_r2": float(np.max(lime_fidelity)),
            "top_features": [
                {
                    "feature": str(feature_names[i]),
                    "mean_absolute_standardized_coefficient": float(lime_mean_abs[i]),
                    "selected_records": int(lime_selected[i]),
                }
                for i in lime_top
            ],
        },
    }

def format_feature(name: str) -> str:
    return name.replace("_", " ")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-model-file", action="store_true", help="Do not persist model.joblib")
    args = parser.parse_args()
    for p in [RESULTS_DIR, DATA_DIR, MODEL_DIR]:
        p.mkdir(parents=True, exist_ok=True)

    bunch = load_breast_cancer(as_frame=True)
    X = bunch.data.copy()
    y = bunch.target.copy()
    all_df = X.copy(); all_df["target"] = y
    data_path = DATA_DIR / "wdbc_sklearn_snapshot.csv"
    all_df.to_csv(data_path, index=False)

    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=0.30, random_state=SEED, stratify=y
    )
    X_cal, X_test, y_cal, y_test = train_test_split(
        X_temp, y_temp, test_size=0.50, random_state=SEED + 1, stratify=y_temp
    )
    model = RandomForestClassifier(
        n_estimators=120, max_depth=None, min_samples_leaf=2, max_features="sqrt",
        class_weight="balanced", random_state=SEED, n_jobs=1,
    )
    model.fit(X_train.to_numpy(), y_train.to_numpy())

    malignant_prob = model_probability(model, X_test.to_numpy())
    y_malignant = (y_test.to_numpy() == 0).astype(int)
    pred_malignant = (malignant_prob >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_malignant, pred_malignant, labels=[0, 1]).ravel()
    performance = {
        "test_n": int(len(X_test)),
        "threshold": 0.5,
        "test_accuracy": float(accuracy_score(y_malignant, pred_malignant)),
        "test_balanced_accuracy": float(balanced_accuracy_score(y_malignant, pred_malignant)),
        "test_malignant_sensitivity_recall": float(recall_score(y_malignant, pred_malignant, pos_label=1)),
        "test_malignant_precision_ppv": float(precision_score(y_malignant, pred_malignant, pos_label=1)),
        "test_benign_specificity": float(tn / (tn + fp)),
        "test_negative_predictive_value": float(tn / (tn + fn)),
        "test_roc_auc_malignant_class": float(roc_auc_score(y_malignant, malignant_prob)),
        "test_brier_score_malignant_class": float(brier_score_loss(y_malignant, malignant_prob)),
        "test_log_loss": float(log_loss(y_malignant, np.column_stack([1 - malignant_prob, malignant_prob]), labels=[0, 1])),
        "confusion_matrix_malignant_positive": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
        "probability_note": "Random-forest class scores are uncalibrated research outputs; they are not clinically validated risk probabilities.",
    }

    train_arr = X_train.to_numpy(dtype=float)
    mean = train_arr.mean(axis=0)
    scale = train_arr.std(axis=0, ddof=0); scale[scale == 0] = 1.0
    train_min = train_arr.min(axis=0); train_max = train_arr.max(axis=0)

    tuned_lime, calibration_table, lime_cal_indices = calibrate_lime(model, X_cal, train_arr, mean, scale)
    calibration_table.to_csv(RESULTS_DIR / "lime_calibration_grid.csv", index=False)

    target_pos = choose_target_case(model, X_test, y_test)
    target_index = int(X_test.index[target_pos])
    x = X_test.iloc[target_pos].to_numpy(dtype=float)
    y_true = int(y_test.iloc[target_pos])
    target_score = float(model_probability(model, x.reshape(1, -1))[0])
    reference = coordinate_reference(model, x, train_arr)
    global_reference = global_permutation_reference(model, X_cal.to_numpy(dtype=float), seed=SEED + 55)
    ref_top = topk(reference); global_ref_top = topk(global_reference)
    low_idx = np.argsort(np.abs(reference))[:12]
    near_cases = generate_preserving_cases(model, x, scale, train_min, train_max, seed=SEED + 30, count=8, max_delta=0.03)
    stress_cases = generate_preserving_cases(
        model, x, scale, train_min, train_max, seed=SEED + 40, count=8, max_delta=0.02, low_influence_idx=low_idx
    )

    shap_tree = shap.TreeExplainer(model)
    def shap_fn(xp, seed):
        weights, reconstructed, elapsed, _ = shap_explain(shap_tree, xp)
        pred = float(model_probability(model, xp.reshape(1, -1))[0])
        return weights, float(np.clip(1.0 - abs(reconstructed - pred), 0.0, 1.0)), elapsed

    tree_cache: Dict[int, Tuple[DecisionTreeRegressor, float, float]] = {}
    def tree_fn(depth):
        if depth not in tree_cache:
            tree_cache[depth] = fit_tree_surrogate(model, train_arr, X_cal.to_numpy(dtype=float), depth, SEED + depth)
        tree, fidelity, fit_elapsed = tree_cache[depth]
        def explain(xp, seed):
            t0 = time.perf_counter(); weights = tree_path_weights(tree, xp)
            return weights, fidelity, fit_elapsed + (time.perf_counter() - t0)
        return explain

    def lime_fn(cfg):
        return lambda xp, seed: lime_explain(model, xp, mean, scale, cfg, seed)

    pdp_cache: Dict[str, Tuple[np.ndarray, List[dict], float]] = {}
    def make_pdp_fn(label, qs):
        if label not in pdp_cache:
            pdp_cache[label] = pdp_effects(model, train_arr, qs)
        def fn(xp, seed):
            w, _details, elapsed = pdp_cache[label]
            return w.copy(), None, elapsed
        return fn

    pdp_main = make_pdp_fn("main", (0.10, 0.25, 0.50, 0.75, 0.90))
    pdp_hyper = [
        make_pdp_fn("q1", (0.05, 0.25, 0.50, 0.75, 0.95)),
        make_pdp_fn("q2", (0.10, 0.30, 0.50, 0.70, 0.90)),
        make_pdp_fn("q3", (0.20, 0.35, 0.50, 0.65, 0.80)),
        pdp_main,
    ]

    methods = [
        ("SHAP", shap_fn, None),
        ("PDP", pdp_main, pdp_hyper),
        ("Tree surrogate", tree_fn(4), [tree_fn(d) for d in [3, 4, 5, 6, 7]]),
        ("LIME baseline", lime_fn(BASELINE_LIME), [lime_fn(c) for c in LIME_GRID]),
        ("LIME tuned", lime_fn(tuned_lime), [lime_fn(c) for c in LIME_GRID]),
    ]

    results = []; weight_rows = []
    for name, fn, hp in methods:
        if name == "PDP":
            method_reference = global_reference; method_near = None; method_stress = None
            reference_scope = "global calibration-set permutation reference"
        else:
            method_reference = reference; method_near = near_cases; method_stress = stress_cases
            reference_scope = "held-out-case coordinate intervention reference"
        result, weights = evaluate_method(
            name, fn, x, method_reference, method_near, method_stress, hp, reference_scope=reference_scope
        )
        result["top_features"] = [str(X.columns[i]) for i in result["top_feature_indices"]]
        results.append(result)
        for j, feature in enumerate(X.columns):
            weight_rows.append({"method": name, "feature": feature, "weight": float(weights[j])})

    # Add native method outputs for the participant technical record.
    shap_weights, shap_reconstructed, _, shap_base = shap_explain(shap_tree, x)
    shap_display = [{
        "feature": str(X.columns[i]), "case_value": float(x[i]), "signed_contribution": float(shap_weights[i])
    } for i in topk(shap_weights)]
    pdp_weights_main, pdp_details, _ = pdp_cache["main"]
    pdp_display = []
    for i in topk(pdp_weights_main):
        d = pdp_details[i]
        pdp_display.append({
            "feature": str(X.columns[i]),
            "case_value": float(x[i]),
            "grid_low": d["feature_values"][0], "grid_median": d["feature_values"][2], "grid_high": d["feature_values"][-1],
            "score_low": d["mean_malignant_class_scores"][0], "score_median": d["mean_malignant_class_scores"][2], "score_high": d["mean_malignant_class_scores"][-1],
            "effect_range": d["effect_range"],
        })
    tree4, tree4_fidelity, _ = tree_cache[4]
    tree_display = tree_path_rules(tree4, x, list(X.columns))
    lime_base_detail = lime_explain_detailed(model, x, mean, scale, BASELINE_LIME, SEED)
    lime_tuned_detail = lime_explain_detailed(model, x, mean, scale, tuned_lime, SEED)
    def lime_display(detail):
        return [{
            "feature": str(X.columns[i]), "case_value": float(x[i]),
            "standardized_case_value": float(standardize(x, mean, scale)[i]),
            "signed_local_coefficient": float(detail["weights"][i]),
        } for i in topk(detail["weights"])]

    native_outputs = {
        "SHAP": {
            "scope": "local",
            "base_malignant_class_score": float(shap_base),
            "reconstructed_malignant_class_score": float(shap_reconstructed),
            "model_malignant_class_score": target_score,
            "top_signed_contributions": shap_display,
        },
        "PDP": {
            "scope": "global",
            "interpretation": "Average model response when each feature is set to training-set quantile values; not an attribution of this individual output.",
            "top_global_effects": pdp_display,
        },
        "Tree surrogate": {
            "scope": "global surrogate with target-case path",
            "surrogate_calibration_r2": float(tree4_fidelity),
            "surrogate_case_score": float(tree4.predict(x.reshape(1, -1))[0]),
            "model_case_score": target_score,
            "target_case_path": tree_display,
        },
        "LIME baseline": {
            "scope": "local",
            "configuration": asdict(BASELINE_LIME),
            "native_weighted_neighbourhood_r2": float(lime_base_detail["native_weighted_neighbourhood_r2"]),
            "independent_local_fidelity_r2": float(lime_base_detail["independent_local_fidelity"]),
            "local_surrogate_case_score": float(lime_base_detail["local_prediction"]),
            "model_case_score": target_score,
            "top_signed_coefficients": lime_display(lime_base_detail),
        },
        "LIME tuned": {
            "scope": "local",
            "configuration": asdict(tuned_lime),
            "native_weighted_neighbourhood_r2": float(lime_tuned_detail["native_weighted_neighbourhood_r2"]),
            "independent_local_fidelity_r2": float(lime_tuned_detail["independent_local_fidelity"]),
            "local_surrogate_case_score": float(lime_tuned_detail["local_prediction"]),
            "model_case_score": target_score,
            "top_signed_coefficients": lime_display(lime_tuned_detail),
        },
    }
    instruction_outputs = build_global_instruction_outputs(
        model, X_cal, X_test, train_arr, mean, scale, shap_tree, tree4, tree4_fidelity,
        pdp_details, pdp_weights_main, list(X.columns)
    )
    representative_family_outputs = {
        "Nearest prototype": nearest_prototype_output(model, x, train_arr, mean, scale, list(X.columns)),
        "Counterfactual search": counterfactual_output(model, x, train_arr, mean, scale, list(X.columns)),
    }
    counterfactual_cross_case = counterfactual_cross_case_summary(
        model, X_test, train_arr, mean, scale, list(X.columns)
    )

    for r in results:
        r["native_output"] = native_outputs[r["method"]]

    result_frame = pd.DataFrame([{k: v for k, v in r.items() if not isinstance(v, (dict, list))} for r in results])
    result_frame.to_csv(RESULTS_DIR / "benchmark_summary.csv", index=False)
    pd.DataFrame(weight_rows).to_csv(RESULTS_DIR / "explanation_weights.csv", index=False)

    # No technical "validation correlation" is computed here. The literature
    # scores are hypotheses/priors and the heterogeneous technical metrics are
    # method-specific measurements, not ground truth on a common scale.
    # Predictive validity is assessed against independent expert judgments in
    # analysis.py after data collection.

    cross_summary, cross_frame = cross_case_summary(
        model, X_test, train_arr, mean, scale, shap_tree, tree4, tree4_fidelity, BASELINE_LIME
    )
    cross_frame.to_csv(RESULTS_DIR / "cross_case_test_metrics.csv", index=False)

    baseline_cal = calibration_table.loc[
        (calibration_table["n_samples"] == BASELINE_LIME.n_samples)
        & (calibration_table["kernel_width_multiplier"] == BASELINE_LIME.kernel_width_multiplier)
    ].iloc[0]
    tuned_cal = calibration_table.iloc[0]
    stressed_cal = calibration_table.loc[calibration_table["n_samples"] == 150].iloc[0]

    case_record = {
        "dataset": {
            "name": "Wisconsin Diagnostic Breast Cancer (WDBC)",
            "source": "UCI Machine Learning Repository; scikit-learn packaged copy",
            "doi": "10.24432/C5DW2B", "license": "CC BY 4.0",
            "rows": int(X.shape[0]), "features": int(X.shape[1]),
            "feature_origin": "Features are computed from digitized images of fine-needle aspirates of breast masses and describe cell-nucleus characteristics.",
            "target_encoding": {"0": "malignant", "1": "benign"},
            "snapshot_sha256": sha256(data_path),
        },
        "split": {"train": int(len(X_train)), "calibration": int(len(X_cal)), "test": int(len(X_test))},
        "model": {"type": "RandomForestClassifier", "parameters": model.get_params(), "performance": performance},
        "target_case_selection": {
            "rule": "Among correctly classified malignant test records, select the record whose malignant-class score is closest to the median of that set; break ties by source-row index. No XAI output is used for selection.",
            "cross_case_safeguard": "SHAP and the tree surrogate are summarized across all 86 held-out test records. Baseline LIME is summarized on 24 deterministic test records spanning the model-score distribution for tractable repeated evaluation. No XAI output is used to select the audit records.",
        },
        "target_case": {
            "source_row_index": target_index, "true_label": y_true,
            "true_label_text": "malignant" if y_true == 0 else "benign",
            "model_malignant_class_score": target_score,
            "score_note": "Uncalibrated random-forest class score used for research classification; not a clinically validated malignancy probability.",
            "displayed_case_values": {str(k): float(v) for k, v in X_test.iloc[target_pos].items()},
        },
        "reference": {
            "definition": "Held-out-case coordinate-wise model intervention range over training-set 10/25/50/75/90 percentiles while holding other case features fixed; used for local/case explanations as a reproducible behavioural reference, not causal ground truth.",
            "top_features": [str(X.columns[i]) for i in ref_top],
            "feature_scores": {str(X.columns[i]): float(reference[i]) for i in range(len(reference))},
        },
        "global_reference": {
            "definition": "Calibration-set permutation reference: mean absolute change in malignant-class score when one feature is permuted across calibration rows; used for global PDP comparison, not causal ground truth.",
            "top_features": [str(X.columns[i]) for i in global_ref_top],
            "feature_scores": {str(X.columns[i]): float(global_reference[i]) for i in range(len(global_reference))},
        },
        "lime": {
            "implementation": "LimeTabularExplainer-compatible continuous-feature configuration: Gaussian training-distribution sampling, sample_around_instance=False, discretize_continuous=False, sqrt-exponential proximity kernel, the supported highest_weights selector for four features, weighted Ridge(alpha=1).",
            "compatibility_note": "The code implements the documented algorithmic path locally for reproducibility and does not vendor the third-party lime package. Continuous discretisation is explicitly disabled; therefore this is a prespecified LIME configuration rather than every package default.",
            "baseline": asdict(BASELINE_LIME), "tuned": asdict(tuned_lime),
            "calibration_source_row_indices": lime_cal_indices,
            "tuning_rule": "Seven calibration-only score-quantile records; maximize 0.45*independent fidelity + 0.35*repeat top-4 Jaccard + 0.20*reference top-4 Jaccard. Test records are excluded from tuning.",
        },
        "literature_vs_technical_measurements": {
            "status": "not collapsed into a validation correlation",
            "reason": "The literature scores and method-specific technical measurements are not a shared ground-truth scale. Raw prespecified metrics are reported; predictive validity is tested against independent legal-expert judgments.",
        },
        "representative_family_outputs": representative_family_outputs,
        "counterfactual_cross_case_summary": counterfactual_cross_case,
        "cross_case_test_summary": cross_summary,
        "lime_parameter_sensitivity": {
            "stressed_low_sample_narrow_kernel": stressed_cal.to_dict(),
            "baseline": baseline_cal.to_dict(), "tuned_calibration_winner": tuned_cal.to_dict(),
            "fidelity_gain_stressed_to_tuned": float(tuned_cal["mean_independent_local_fidelity"] - stressed_cal["mean_independent_local_fidelity"]),
            "repeatability_gain_stressed_to_tuned": float(tuned_cal["mean_repeat_top4_jaccard"] - stressed_cal["mean_repeat_top4_jaccard"]),
            "note": "The grid is frozen and calibration-only; held-out test records are excluded from parameter selection.",
        },
        "native_outputs": native_outputs,
        "global_instruction_outputs": instruction_outputs,
        "results": results,
        "software": {
            "python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__,
            "scikit_learn": sklearn.__version__, "shap": shap.__version__, "joblib": joblib.__version__, "seed": SEED,
        },
    }
    (RESULTS_DIR / "case_study.json").write_text(json.dumps(case_record, indent=2, sort_keys=True))

    # A compact machine-readable preliminary technical report mirrors the source
    # JSON but foregrounds quantities needed before expert recruitment.
    prelim = {
        "scope": "Preliminary technical validation of a research classifier and four XAI methods; not clinical validation, conformity assessment, or legal compliance determination.",
        "dataset": case_record["dataset"], "split": case_record["split"], "model": case_record["model"],
        "target_case_selection": case_record["target_case_selection"], "target_case": case_record["target_case"],
        "native_outputs": native_outputs, "global_instruction_outputs": instruction_outputs,
        "case_method_results": results,
        "cross_case_test_summary": cross_summary,
        "literature_vs_technical_measurements": case_record["literature_vs_technical_measurements"],
        "representative_family_outputs": representative_family_outputs,
        "counterfactual_cross_case_summary": counterfactual_cross_case,
        "lime_parameter_sensitivity": case_record["lime_parameter_sensitivity"], "software": case_record["software"],
    }
    (RESULTS_DIR / "preliminary_technical_report.json").write_text(json.dumps(prelim, indent=2, sort_keys=True))

    if not args.no_model_file:
        model_path = MODEL_DIR / "wdbc_random_forest.joblib"
        joblib.dump(model, model_path)
        (MODEL_DIR / "model.sha256").write_text(sha256(model_path) + "\n")

    print(result_frame.to_string(index=False))
    print("\nTuned LIME:", tuned_lime)
    print("Target case index:", target_index, "malignant class score:", round(target_score, 4))
    print("Reference top features:", [X.columns[i] for i in ref_top])
    print("No technical validation correlation computed: technical metrics are not ground truth.")
    print("Counterfactual success rate across test set:", round(counterfactual_cross_case["success_rate"], 3))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
