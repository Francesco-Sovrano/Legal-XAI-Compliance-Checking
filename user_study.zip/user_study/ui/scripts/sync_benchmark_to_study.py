#!/usr/bin/env python3
"""Refresh researcher-only benchmark metadata without changing participant stimuli.

The participant-facing MDR case is a controlled diabetes scenario. Its explanation
quality ratings are derived from the paper's literature-based 1 to 5 property
scores and must not be replaced with WDBC measurements. This script therefore
updates only hidden researcher metadata used for methodological traceability.
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "study.json"
BENCH = ROOT / "benchmark" / "results" / "case_study.json"


def main() -> int:
    cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
    bench = json.loads(BENCH.read_text(encoding="utf-8"))
    module = cfg["modules"]["clinical_empirical"]
    rows = {row["method"]: row for row in bench["results"]}
    method_map = {
        "clinical-pdp": "PDP",
        "clinical-tree": "Tree surrogate",
    }

    for condition in module["conditions"]:
        method = method_map.get(condition["id"])
        if method is None:
            continue
        row = rows[method]
        condition["empirical_metrics"] = {
            key: row.get(key)
            for key in [
                "local_fidelity",
                "reference_scope",
                "reference_top4_jaccard",
                "reference_rank_agreement",
                "reference_mass_coverage",
                "repeat_top4_jaccard",
                "near_equivalent_top4_jaccard",
                "stress_top4_jaccard",
                "hyperparameter_top4_jaccard",
                "runtime_seconds",
            ]
        }


    # Keep SHAP benchmark metrics as researcher-only diagnostics for the attribution condition.
    approx = next((c for c in module["conditions"] if c["id"] == "clinical-shap"), None)
    if approx is not None and "SHAP" in rows:
        row = rows["SHAP"]
        approx["empirical_metrics"] = {
            key: row.get(key)
            for key in [
                "local_fidelity", "reference_scope", "reference_top4_jaccard",
                "reference_rank_agreement", "reference_mass_coverage",
                "repeat_top4_jaccard", "near_equivalent_top4_jaccard",
                "stress_top4_jaccard", "hyperparameter_top4_jaccard",
                "runtime_seconds",
            ]
        }

    module.setdefault("evidence_provenance", {})["researcher_reference_only"] = {
        "benchmark_record": "benchmark/results/case_study.json",
        "note": "WDBC benchmark measurements are retained for researcher-side methodological traceability only. They are not participant-facing diabetes evidence and do not replace the literature-based explanation-quality ratings."
    }

    CONFIG.write_text(json.dumps(cfg, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("Refreshed researcher-only clinical benchmark metadata.")
    print("Participant-facing diabetes explanations and technical quality ratings were left unchanged.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
