#!/usr/bin/env python3
"""Same-origin browser smoke checks for the Legal XAI study.

This script starts the demo server and validates representative participant,
participant and researcher routes in a real Chromium process. It checks Vue
version, page/console errors, route visibility and horizontal overflow. It is
software QA only; institutional supported-browser, keyboard and assistive-
technology acceptance remains a fieldwork gate before live recruitment.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[1]


def chromium_path() -> str | None:
    candidates = [
        os.environ.get("CHROMIUM_PATH"),
        shutil.which("chromium"),
        shutil.which("chromium-browser"),
        shutil.which("google-chrome"),
        shutil.which("google-chrome-stable"),
    ]
    return next((value for value in candidates if value), None)


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def wait(url: str, seconds: float = 15) -> None:
    deadline = time.time() + seconds
    while time.time() < deadline:
        try:
            with urlopen(url, timeout=1) as response:
                if response.status == 200:
                    return
        except Exception:
            time.sleep(0.15)
    raise RuntimeError("Study server did not become ready")


def write_report(out: Path, report: dict) -> None:
    out.mkdir(parents=True, exist_ok=True)
    (out / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(ROOT / ".artifacts" / "browser-smoke"))
    args = parser.parse_args()
    out = Path(args.out)

    executable = chromium_path()
    if not executable:
        write_report(out, {
            "status": "environment_blocked",
            "errors": ["No system Chromium executable found. Set CHROMIUM_PATH or install Chromium."],
            "checks": [],
        })
        return 2

    port = free_port()
    base = f"http://127.0.0.1:{port}"
    server = subprocess.Popen(
        [sys.executable, str(ROOT / "app.py"), "--mode", "demo", "--host", "127.0.0.1", "--port", str(port)],
        cwd=ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    records: list[dict] = []
    errors: list[str] = []
    try:
        wait(base + "/health")
        try:
            from playwright.sync_api import Error as PlaywrightError, sync_playwright
        except Exception as exc:
            write_report(out, {
                "status": "environment_blocked",
                "renderer": executable,
                "errors": [f"Playwright unavailable: {exc}"],
                "checks": [],
            })
            return 2

        cases = [
            ("entry", "/", "#app .entry-shell"),
            ("clinical-trial", "/?mock=1&screen=trial&module=clinical_empirical&condition=0", "#app .stage-section"),
            ("credit-orientation", "/?mock=1&screen=orientation&module=credit_authority", "#app .orientation-stage"),
            ("comparison", "/?mock=1&screen=ranking&module=credit_authority", "#app .flow-page"),
            ("checklist", "/?mock=1&screen=checklist&module=credit_authority", "#app .flow-page"),
            ("researcher", "/admin/debug?mock=1", "#admin"),
        ]

        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True, executable_path=executable, args=["--no-sandbox"])
                try:
                    for name, path, selector in cases:
                        page = browser.new_page(viewport={"width": 1440, "height": 1000})
                        page_errors: list[str] = []
                        console_errors: list[str] = []
                        page.on("console", lambda msg, bucket=console_errors: bucket.append(msg.text) if msg.type == "error" else None)
                        page.on("pageerror", lambda exc, bucket=page_errors: bucket.append(str(exc)))
                        response = page.goto(base + path, wait_until="networkidle")
                        page.locator(selector).wait_for(state="visible", timeout=10000)
                        version = page.evaluate("typeof Vue !== 'undefined' ? Vue.version : null")
                        overflow = page.evaluate(
                            "Math.max(document.documentElement.scrollWidth, document.body.scrollWidth) > window.innerWidth + 2"
                        )
                        if version != "3.5.13":
                            errors.append(f"chromium/{name}: expected vendored Vue 3.5.13, got {version}")
                        if overflow:
                            errors.append(f"chromium/{name}: horizontal overflow detected")
                        errors.extend(f"chromium/{name} console: {msg}" for msg in console_errors)
                        errors.extend(f"chromium/{name} pageerror: {msg}" for msg in page_errors)
                        page.screenshot(path=str(out / f"chromium-{name}.png"), full_page=True)
                        records.append({
                            "browser": "chromium",
                            "name": name,
                            "path": path,
                            "status": response.status if response else None,
                            "vue": version,
                            "horizontal_overflow": overflow,
                            "page_errors": page_errors,
                            "console_errors": console_errors,
                        })
                        page.close()
                finally:
                    browser.close()

                mobile = p.chromium.launch(headless=True, executable_path=executable, args=["--no-sandbox"])
                try:
                    page = mobile.new_page(viewport={"width": 390, "height": 844})
                    page.goto(base + "/?mock=1&screen=trial&module=clinical_empirical&condition=0", wait_until="networkidle")
                    page.locator("#app .stage-section").wait_for(state="visible")
                    overflow = page.evaluate(
                        "Math.max(document.documentElement.scrollWidth, document.body.scrollWidth) > window.innerWidth + 2"
                    )
                    if overflow:
                        errors.append("chromium-mobile/clinical-trial: horizontal overflow detected")
                    page.screenshot(path=str(out / "chromium-mobile-clinical.png"), full_page=True)
                    records.append({
                        "browser": "chromium-mobile",
                        "name": "clinical-trial",
                        "status": 200,
                        "vue": page.evaluate("Vue.version"),
                        "horizontal_overflow": overflow,
                    })
                    page.close()
                finally:
                    mobile.close()
        except PlaywrightError as exc:
            message = str(exc)
            if "ERR_BLOCKED_BY_ADMINISTRATOR" in message:
                write_report(out, {
                    "status": "environment_blocked",
                    "renderer": executable,
                    "checks": records,
                    "errors": ["The execution environment blocks Chromium navigation to the local study server."],
                    "note": "Run this script in the intended deployment environment. Deterministic same-template render checks are available via scripts/render_mock_screens.py.",
                })
                return 2
            raise

        report = {
            "status": "pass" if not errors else "fail",
            "renderer": executable,
            "checks": records,
            "errors": errors,
            "note": "Automated Chromium desktop/mobile server smoke testing supplements, but does not replace, institutional supported-browser, keyboard and assistive-technology acceptance before recruitment.",
        }
        write_report(out, report)
        return 0 if not errors else 1
    finally:
        server.terminate()
        try:
            server.wait(timeout=3)
        except subprocess.TimeoutExpired:
            server.kill()


if __name__ == "__main__":
    raise SystemExit(main())
