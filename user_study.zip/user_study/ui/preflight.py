#!/usr/bin/env python3
"""Software and fieldwork preflight for the Legal XAI study."""
from __future__ import annotations
import argparse, json, subprocess, sys
from pathlib import Path
from study_core import ConfigError, load_config, validate_config
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--require-live',action='store_true',help='Fail unless all institutional fieldwork gates are complete.')
args=parser.parse_args()
config=load_config(ROOT/'config/study.json')
errors=[]
try: validate_config(config,live=False)
except ConfigError as exc: errors.append(str(exc))
for command in [
    [sys.executable,'-m','py_compile','app.py','study_core.py','study_service.py','analysis.py','framework_scoring.py'],
    ['node','--check','static/assets/app.js'],
    ['node','--check','static/assets/admin.js'],
    [sys.executable,'scripts/verify_benchmark_binding.py'],
    [sys.executable,'-m','unittest','discover','-s','tests','-v'],
]:
    result=subprocess.run(command,cwd=ROOT,text=True,capture_output=True)
    if result.returncode:
        errors.append('$ '+' '.join(command)+'\n'+result.stdout+result.stderr)
external={
    'ethics approval':config.get('ethics',{}).get('approved'),
    'preregistration freeze':config.get('preregistration',{}).get('frozen'),
    'technical sign-off':config.get('technical_signoff',{}).get('complete'),
    'legal sign-off':config.get('legal_signoff',{}).get('complete'),
    'cognitive pilot':config.get('pilot',{}).get('cognitive_complete'),
    'soft launch':config.get('pilot',{}).get('soft_launch_complete'),
    'browser acceptance':config.get('acceptance_test',{}).get('complete'),
    'supported frontend dependency':config.get('acceptance_test',{}).get('frontend_dependency_supported'),
}
print('SOFTWARE PREFLIGHT:', 'PASS' if not errors else 'FAIL')
for label,value in external.items(): print(f"FIELDWORK GATE: {label}: {'complete' if value else 'pending'}")
if errors:
    for error in errors: print('\nERROR:',error)
    raise SystemExit(1)
if args.require_live and not all(external.values()):
    raise SystemExit('Live fieldwork gates are incomplete.')
