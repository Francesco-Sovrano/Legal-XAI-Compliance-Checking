# Study documentation

From the package root, `methods_scoring/assess_xai_compliance_documentation.md` specifies the study measures, instrument, database analysis and technical benchmark. `README.md` gives installation and execution commands.
