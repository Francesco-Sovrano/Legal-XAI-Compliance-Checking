#!/usr/bin/env python3
"""Analysis for the Legal XAI empirical and legal-expert validation study.

The script reads immutable pre-comparison judgments, tie-aware comparison ranks,
source-derived checklist responses, and study checks from the SQLite study file.
It reports descriptive predictive validity and concordance. It never excludes an
expert because a post-study comprehension or recognition check was missed.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import json
import math
from pathlib import Path
import sqlite3
from statistics import mean, median
from typing import Any, Iterable, Mapping, Sequence

from study_core import load_config

ROOT = Path(__file__).resolve().parent


def midranks(values: Sequence[float], *, higher_is_better: bool = True) -> list[float]:
    """Return 1=best midranks with ties."""
    order = sorted(range(len(values)), key=lambda i: values[i], reverse=higher_is_better)
    ranks = [0.0] * len(values)
    position = 1
    j = 0
    while j < len(order):
        k = j + 1
        while k < len(order) and values[order[k]] == values[order[j]]:
            k += 1
        rank = (position + (position + (k - j) - 1)) / 2.0
        for ix in order[j:k]:
            ranks[ix] = rank
        position += k - j
        j = k
    return ranks


def pearson(x: Sequence[float], y: Sequence[float]) -> float | None:
    if len(x) != len(y) or len(x) < 2:
        return None
    mx, my = mean(x), mean(y)
    dx = [v - mx for v in x]
    dy = [v - my for v in y]
    den = math.sqrt(sum(v * v for v in dx) * sum(v * v for v in dy))
    if not den:
        return None
    return sum(a * b for a, b in zip(dx, dy)) / den


def spearman(x: Sequence[float], y: Sequence[float]) -> float | None:
    if len(x) != len(y) or len(x) < 2:
        return None
    return pearson(midranks(x), midranks(y))


def kendall_tau_b(x: Sequence[float], y: Sequence[float]) -> float | None:
    """Kendall tau-b for two equally sized sequences, preserving ties."""
    if len(x) != len(y) or len(x) < 2:
        return None
    concordant = discordant = ties_x = ties_y = 0
    for i in range(len(x)):
        for j in range(i + 1, len(x)):
            dx = x[i] - x[j]
            dy = y[i] - y[j]
            if dx == 0 and dy == 0:
                continue
            if dx == 0:
                ties_x += 1
            elif dy == 0:
                ties_y += 1
            elif dx * dy > 0:
                concordant += 1
            else:
                discordant += 1
    den = math.sqrt((concordant + discordant + ties_x) * (concordant + discordant + ties_y))
    return (concordant - discordant) / den if den else None


def kendalls_w(matrix: Sequence[Sequence[float]], *, higher_is_better: bool = True) -> float | None:
    """Kendall's W with tie correction; rows are raters, columns are items."""
    if len(matrix) < 2 or not matrix or len(matrix[0]) < 2:
        return None
    n = len(matrix[0])
    if any(len(row) != n for row in matrix):
        return None
    ranks = [midranks(row, higher_is_better=higher_is_better) for row in matrix]
    m = len(ranks)
    rank_sums = [sum(row[j] for row in ranks) for j in range(n)]
    centre = m * (n + 1) / 2.0
    s = sum((value - centre) ** 2 for value in rank_sums)
    tie_term = 0.0
    for row in matrix:
        counts = Counter(row)
        tie_term += sum(count**3 - count for count in counts.values() if count > 1)
    denominator = m * m * (n**3 - n) - m * tie_term
    return 12.0 * s / denominator if denominator else None


def fmt(value: float | None, digits: int = 3) -> str:
    return "NA" if value is None or math.isnan(value) else f"{value:.{digits}f}"


def read_rows(connection: sqlite3.Connection) -> dict[str, list[dict[str, Any]]]:
    queries = {
        "trials": (
            "SELECT s.panel_slot,s.gdpr_familiarity,s.mdr_familiarity,t.module_id,t.condition_id,t.disposition,"
            "t.answers_legal_question,t.enables_legal_objective,t.confidence,t.rationale "
            "FROM sessions s JOIN trial_responses t ON t.session_id=s.id "
            "WHERE s.stage='complete' ORDER BY s.panel_slot,t.module_id,t.trial_index"
        ),
        "rankings": (
            "SELECT s.panel_slot,s.gdpr_familiarity,s.mdr_familiarity,r.module_id,r.condition_id,"
            "r.score_decision,r.revised_answers_legal_question,r.revised_enables_legal_objective,r.revised_confidence,r.rank_group "
            "FROM sessions s JOIN ranking_responses r ON r.session_id=s.id "
            "WHERE s.stage='complete' ORDER BY s.panel_slot,r.module_id,r.blind_label"
        ),
        "checklists": (
            "SELECT s.panel_slot,c.module_id,c.condition_id,c.item_id,c.score "
            "FROM sessions s JOIN checklist_responses c ON c.session_id=s.id "
            "WHERE s.stage='complete' ORDER BY s.panel_slot,c.module_id,c.condition_id,c.item_id"
        ),
        "poststudy": (
            "SELECT s.panel_slot,p.checklist_new_considerations,p.technical_fact_understanding,"
            "p.method_recognition,p.comments "
            "FROM sessions s JOIN poststudy_responses p ON p.session_id=s.id "
            "WHERE s.stage='complete' ORDER BY s.panel_slot"
        ),
    }
    return {name: [dict(row) for row in connection.execute(sql)] for name, sql in queries.items()}


def by_expert(rows: Iterable[dict[str, Any]], module_id: str, field: str) -> dict[str, dict[str, float]]:
    out: dict[str, dict[str, float]] = defaultdict(dict)
    for row in rows:
        if row["module_id"] == module_id:
            out[row["panel_slot"]][row["condition_id"]] = float(row[field])
    return out


def expert_matrix(
    rows: Iterable[dict[str, Any]], module_id: str, field: str, condition_ids: Sequence[str]
) -> tuple[list[str], list[list[float]]]:
    values = by_expert(rows, module_id, field)
    experts = sorted(expert for expert, row in values.items() if all(cid in row for cid in condition_ids))
    return experts, [[values[e][cid] for cid in condition_ids] for e in experts]


def directional_pairs(scores: Mapping[str, float], equivalence_band: float) -> list[tuple[str, str, float]]:
    items = sorted(scores, key=lambda cid: (-scores[cid], cid))
    pairs: list[tuple[str, str, float]] = []
    for i, better in enumerate(items):
        for worse in items[i + 1 :]:
            delta = scores[better] - scores[worse]
            if delta >= equivalence_band:
                pairs.append((better, worse, delta))
    return pairs


def analyse(config: dict[str, Any], rows: dict[str, list[dict[str, Any]]]) -> dict[str, Any]:
    experts = sorted({row["panel_slot"] for row in rows["trials"]})
    result: dict[str, Any] = {
        "study_id": config["study_id"],
        "complete_experts": experts,
        "n_complete": len(experts),
        "target_n": int(config["panel"]["target_experts"]),
        "minimum_n": int(config["panel"]["minimum_experts"]),
        "claim_boundary": config["small_n_analysis"]["claim_boundary"],
        "clinical_predictive_validity": {},
        "credit_authority_concordance": {},
        "study_checks": {},
    }

    clinical_id = "clinical_empirical"
    clinical = config["modules"][clinical_id]
    condition_ids = [c["id"] for c in clinical["conditions"]]
    familiarity_threshold = int(config.get("panel", {}).get("context_familiarity_threshold", 4))
    qualified_minimum = int(config.get("panel", {}).get("minimum_context_qualified_experts", 8))

    ordered_clinical = sorted(clinical["conditions"], key=lambda c: c["framework_rank"])
    clinical_ids = [c["id"] for c in ordered_clinical]
    # All participant ratings use one common MDR legal question/objective.
    # Confirmatory catalogue-score contrasts remain restricted to the two matched explanatory functions.
    expected_quality = [float(c.get("literature_score", 0.0)) for c in ordered_clinical]
    c_experts, primary = expert_matrix(rows["trials"], clinical_id, "enables_legal_objective", clinical_ids)
    primary_by = by_expert(rows["trials"], clinical_id, "enables_legal_objective")
    c_rank_by = by_expert(rows["rankings"], clinical_id, "rank_group")
    familiarity = {
        row["panel_slot"]: float(row.get("mdr_familiarity", 0))
        for row in rows["trials"] if row["module_id"] == clinical_id
    }

    clinical_expert = []
    for expert, ratings in zip(c_experts, primary):
        rank_vector = [c_rank_by[expert][cid] for cid in clinical_ids] if all(cid in c_rank_by.get(expert, {}) for cid in clinical_ids) else []
        clinical_expert.append({
            "panel_slot": expert,
            "mdr_familiarity": familiarity.get(expert),
            "kendall_tau_b_expected_order_vs_primary_rating": kendall_tau_b(expected_quality, ratings),
            "kendall_tau_b_expected_order_vs_complete_comparison": kendall_tau_b(expected_quality, [-r for r in rank_vector]) if rank_vector else None,
            "ratings": dict(zip(clinical_ids, ratings)),
            "rank_groups": dict(zip(clinical_ids, rank_vector)) if rank_vector else {},
        })

    directed_results = []
    for pred in clinical.get("confirmatory_contrasts", []):
        better, worse = pred["better"], pred["worse"]
        diffs = [
            primary_by[e][better] - primary_by[e][worse]
            for e in c_experts if better in primary_by.get(e, {}) and worse in primary_by.get(e, {})
        ]
        qualified_diffs = [
            primary_by[e][better] - primary_by[e][worse]
            for e in c_experts
            if familiarity.get(e, 0) >= familiarity_threshold
            and better in primary_by.get(e, {}) and worse in primary_by.get(e, {})
        ]
        # Smaller rank_group is better. A positive advantage therefore means the
        # predicted-better explanation finished above the comparator after re-ranking.
        rerank_advantages = [
            c_rank_by[e][worse] - c_rank_by[e][better]
            for e in c_experts if better in c_rank_by.get(e, {}) and worse in c_rank_by.get(e, {})
        ]
        qualified_rerank_advantages = [
            c_rank_by[e][worse] - c_rank_by[e][better]
            for e in c_experts
            if familiarity.get(e, 0) >= familiarity_threshold
            and better in c_rank_by.get(e, {}) and worse in c_rank_by.get(e, {})
        ]
        directed_results.append({
            "id": pred.get("id"),
            "better": better,
            "worse": worse,
            "basis": pred.get("basis"),
            "n_complete": len(diffs),
            "support": sum(d > 0 for d in diffs),
            "tie": sum(d == 0 for d in diffs),
            "reversal": sum(d < 0 for d in diffs),
            "median_primary_rating_difference": median(diffs) if diffs else None,
            "rerank_support": sum(d > 0 for d in rerank_advantages),
            "rerank_tie": sum(d == 0 for d in rerank_advantages),
            "rerank_reversal": sum(d < 0 for d in rerank_advantages),
            "median_rerank_position_advantage": median(rerank_advantages) if rerank_advantages else None,
            "n_context_qualified": len(qualified_diffs),
            "qualified_support": sum(d > 0 for d in qualified_diffs),
            "qualified_tie": sum(d == 0 for d in qualified_diffs),
            "qualified_reversal": sum(d < 0 for d in qualified_diffs),
            "qualified_median_primary_rating_difference": median(qualified_diffs) if qualified_diffs else None,
            "qualified_rerank_support": sum(d > 0 for d in qualified_rerank_advantages),
            "qualified_rerank_tie": sum(d == 0 for d in qualified_rerank_advantages),
            "qualified_rerank_reversal": sum(d < 0 for d in qualified_rerank_advantages),
            "qualified_median_rerank_position_advantage": median(qualified_rerank_advantages) if qualified_rerank_advantages else None,
        })

    mean_ratings = [mean(row[j] for row in primary) for j in range(len(clinical_ids))] if primary else []
    qualified_experts = [x for x in clinical_expert if (x.get("mdr_familiarity") or 0) >= familiarity_threshold]
    result["clinical_predictive_validity"] = {
        "analysis_unit": "MDR common-standard safe-use assessment with two matched explanatory-function comparisons",
        "expected_package_order": clinical_ids,
        "expected_near_tie": [],
        "directed_predictions": directed_results,
        "matched_predictions": directed_results,
        "expert_level": clinical_expert,
        "mean_primary_ratings": dict(zip(clinical_ids, mean_ratings)) if mean_ratings else {},
        "primary_rating_interexpert_kendalls_w": kendalls_w(primary),
        "context_familiarity_threshold": familiarity_threshold,
        "minimum_context_qualified_experts": qualified_minimum,
        "n_context_qualified": len(qualified_experts),
        "context_qualified_validation_ready": len(qualified_experts) >= qualified_minimum,
        "primary_context_qualified_median_kendall_tau_b": median([x["kendall_tau_b_expected_order_vs_primary_rating"] for x in qualified_experts if x["kendall_tau_b_expected_order_vs_primary_rating"] is not None]) if any(x["kendall_tau_b_expected_order_vs_primary_rating"] is not None for x in qualified_experts) else None,
        "primary_context_qualified_median_kendall_tau_b_complete_comparison": median([x["kendall_tau_b_expected_order_vs_complete_comparison"] for x in qualified_experts if x["kendall_tau_b_expected_order_vs_complete_comparison"] is not None]) if any(x["kendall_tau_b_expected_order_vs_complete_comparison"] is not None for x in qualified_experts) else None,
        "full_panel_median_expert_kendall_tau_b": median([x["kendall_tau_b_expected_order_vs_primary_rating"] for x in clinical_expert if x["kendall_tau_b_expected_order_vs_primary_rating"] is not None]) if clinical_expert else None,
        "full_panel_median_expert_kendall_tau_b_complete_comparison": median([x["kendall_tau_b_expected_order_vs_complete_comparison"] for x in clinical_expert if x["kendall_tau_b_expected_order_vs_complete_comparison"] is not None]) if clinical_expert else None,
        "interpretation": "All four MDR explanations are judged against one common safe-use legal question and objective. Confirmatory catalogue-score directionality is restricted to the two prespecified matched-function pairs. The post-lock four-output review is secondary. Technical evidence remains supporting evidence rather than legal ground truth.",
    }

    credit_id = "credit_authority"
    credit = config["modules"][credit_id]
    credit_ids = [c["id"] for c in sorted(credit["conditions"], key=lambda c: c["framework_rank"])]
    expected_quality = [float(c.get("literature_score", 0.0)) for c in sorted(credit["conditions"], key=lambda c: c["framework_rank"])]
    a_experts, a_primary = expert_matrix(rows["trials"], credit_id, "enables_legal_objective", credit_ids)
    authority_expert = []
    credit_rank_by = by_expert(rows["rankings"], credit_id, "rank_group")
    gdpr_familiarity = {row["panel_slot"]: float(row.get("gdpr_familiarity",0)) for row in rows["trials"] if row["module_id"] == credit_id}
    for expert, ratings in zip(a_experts, a_primary):
        rank_vector=[credit_rank_by[expert][cid] for cid in credit_ids] if all(cid in credit_rank_by.get(expert,{}) for cid in credit_ids) else []
        authority_expert.append({
            "panel_slot": expert,
            "gdpr_familiarity": gdpr_familiarity.get(expert),
            "kendall_tau_b_authority_order_vs_primary_rating": kendall_tau_b(expected_quality, ratings),
            "kendall_tau_b_authority_order_vs_complete_comparison": kendall_tau_b(expected_quality, [-r for r in rank_vector]) if rank_vector else None,
            "ratings": dict(zip(credit_ids, ratings)),
            "rank_groups": dict(zip(credit_ids, rank_vector)) if rank_vector else {},
        })
    checklist_by_condition: dict[str, list[float]] = defaultdict(list)
    for row in rows["checklists"]:
        if row["module_id"] == credit_id:
            checklist_by_condition[row["condition_id"]].append(float(row["score"]))
    checklist_means = {cid: mean(checklist_by_condition[cid]) for cid in credit_ids if checklist_by_condition[cid]}
    checklist_vector = [checklist_means[cid] for cid in credit_ids] if len(checklist_means) == len(credit_ids) else []
    result["credit_authority_concordance"] = {
        "authority_predicates": credit.get("authority_benchmark", {}).get("benchmark_predicates", []),
        "expected_package_order": credit_ids,
        "paper_fit_scores_by_question": {c["id"]: float(c.get("literature_score", 0.0)) for c in credit["conditions"]},
        "expert_level": authority_expert,
        "context_familiarity_threshold": familiarity_threshold,
        "minimum_context_qualified_experts": qualified_minimum,
        "n_context_qualified": sum((x.get("gdpr_familiarity") or 0) >= familiarity_threshold for x in authority_expert),
        "context_qualified_validation_ready": sum((x.get("gdpr_familiarity") or 0) >= familiarity_threshold for x in authority_expert) >= qualified_minimum,
        "primary_context_qualified_median_kendall_tau_b": median([x["kendall_tau_b_authority_order_vs_primary_rating"] for x in authority_expert if (x.get("gdpr_familiarity") or 0) >= familiarity_threshold and x["kendall_tau_b_authority_order_vs_primary_rating"] is not None]) if any((x.get("gdpr_familiarity") or 0) >= familiarity_threshold and x["kendall_tau_b_authority_order_vs_primary_rating"] is not None for x in authority_expert) else None,
        "primary_context_qualified_median_kendall_tau_b_complete_comparison": median([x["kendall_tau_b_authority_order_vs_complete_comparison"] for x in authority_expert if (x.get("gdpr_familiarity") or 0) >= familiarity_threshold and x["kendall_tau_b_authority_order_vs_complete_comparison"] is not None]) if any((x.get("gdpr_familiarity") or 0) >= familiarity_threshold and x["kendall_tau_b_authority_order_vs_complete_comparison"] is not None for x in authority_expert) else None,
        "full_panel_median_expert_kendall_tau_b": median([x["kendall_tau_b_authority_order_vs_primary_rating"] for x in authority_expert if x["kendall_tau_b_authority_order_vs_primary_rating"] is not None]) if authority_expert else None,
        "full_panel_median_expert_kendall_tau_b_complete_comparison": median([x["kendall_tau_b_authority_order_vs_complete_comparison"] for x in authority_expert if x["kendall_tau_b_authority_order_vs_complete_comparison"] is not None]) if authority_expert else None,
        "primary_rating_interexpert_kendalls_w": kendalls_w(a_primary),
        "mean_checklist_score_by_package": checklist_means,
        "kendall_tau_b_authority_order_vs_mean_checklist": kendall_tau_b(expected_quality, checklist_vector) if checklist_vector else None,
        "interpretation": "All four GDPR explanations are assessed against one common GDPR legal question and objective. They provide different explanatory functions, but the participant assessment prompt is held constant. The post-lock comparison is secondary. Associations with catalogue scores are exploratory because the outputs serve different explanatory functions. The legal sources do not endorse any particular XAI method.",
    }

    post = rows["poststudy"]
    result["study_checks"] = {
        "n_with_feedback": len(post),
        "median_technical_fact_understanding": median([row["technical_fact_understanding"] for row in post]) if post else None,
        "checklist_introduced_new_considerations": {
            "yes": sum(row["checklist_new_considerations"] == "yes" for row in post),
            "no": sum(row["checklist_new_considerations"] == "no" for row in post),
        },
        "exclusion_rule": "Final feedback does not exclude a participant from the primary analysis.",
    }
    return result


def markdown_report(result: dict[str, Any]) -> str:
    n = result["n_complete"]
    lines = [
        "# Legal XAI validation analysis",
        "",
        f"Complete expert sessions: **{n}** (target {result['target_n']}; minimum {result['minimum_n']}).",
        "",
        f"Claim boundary: {result['claim_boundary']}",
        "",
        "## MDR case: global ex-ante predictive validity",
        "",
    ]
    if not n:
        lines += [
            "No completed legal-expert sessions are present. The technical benchmark and analysis plan can be reproduced, but predictive legal validity cannot be estimated until expert responses are collected.",
            "",
        ]
    else:
        c = result["clinical_predictive_validity"]
        lines += [
            "All four blinded MDR outputs are rated against the same safe-use legal question and objective. Confirmatory analysis uses only the two prespecified matched-function directions. The later score-review screen records secondary comparison-stage scores and a final order while preserving the locked primary responses.",
            "",
            f"Context-qualified MDR experts: **{c['n_context_qualified']}** (required {c['minimum_context_qualified_experts']} at familiarity >= {c['context_familiarity_threshold']}/5).",
            "",
            f"Exploratory primary-population Kendall tau-b between configured catalogue scores and pre-comparison ratings: **{fmt(c['primary_context_qualified_median_kendall_tau_b'])}**.",
            f"Exploratory primary-population Kendall tau-b between those scores and the final post-lock re-ranking: **{fmt(c['primary_context_qualified_median_kendall_tau_b_complete_comparison'])}**.",
            f"Full-panel median expert Kendall tau-b for pre-comparison ratings: **{fmt(c['full_panel_median_expert_kendall_tau_b'])}**.",
            f"Full-panel median expert Kendall tau-b for final re-ranking orders: **{fmt(c['full_panel_median_expert_kendall_tau_b_complete_comparison'])}**.",
            f"Inter-expert Kendall W for the four primary ratings: **{fmt(c['primary_rating_interexpert_kendalls_w'])}**.",
            "",
            "| Prediction | Primary support | Primary tie | Primary reversal | Qualified median primary-rating difference | Re-rank support | Re-rank tie | Re-rank reversal | Qualified median re-rank position advantage |",
            "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
        ]
        for pair in c["directed_predictions"]:
            lines.append(
                f"| {pair['better']} > {pair['worse']} | {pair['qualified_support']} | {pair['qualified_tie']} | "
                f"{pair['qualified_reversal']} | {fmt(pair['qualified_median_primary_rating_difference'])} | "
                f"{pair['qualified_rerank_support']} | {pair['qualified_rerank_tie']} | {pair['qualified_rerank_reversal']} | "
                f"{fmt(pair['qualified_median_rerank_position_advantage'])} |"
            )
        lines += ["", c["interpretation"], ""]

    lines += ["## Credit case: common-standard GDPR explanation assessment", ""]
    if n:
        a = result["credit_authority_concordance"]
        lines += [
            f"Context-qualified GDPR experts: **{a['n_context_qualified']}** (required {a['minimum_context_qualified_experts']} at familiarity >= {a['context_familiarity_threshold']}/5).",
            "",
            f"Exploratory primary-population Kendall tau-b between configured catalogue scores and pre-comparison ratings: **{fmt(a['primary_context_qualified_median_kendall_tau_b'])}**.",
            f"Exploratory primary-population Kendall tau-b between those scores and the final post-lock re-ranking: **{fmt(a['primary_context_qualified_median_kendall_tau_b_complete_comparison'])}**.",
            f"Full-panel median expert Kendall tau-b for pre-comparison ratings: **{fmt(a['full_panel_median_expert_kendall_tau_b'])}**.",
            f"Full-panel median expert Kendall tau-b for final re-ranking orders: **{fmt(a['full_panel_median_expert_kendall_tau_b_complete_comparison'])}**.",
            f"Inter-expert Kendall W for credit primary ratings: **{fmt(a['primary_rating_interexpert_kendalls_w'])}**.",
            f"Exploratory Kendall tau-b between configured catalogue scores and mean source-derived checklist scores: **{fmt(a['kendall_tau_b_authority_order_vs_mean_checklist'])}**.",
            "",
            a["interpretation"],
            "",
        ]
    else:
        lines += ["No completed expert responses are available for this comparison.", ""]
    lines += [
        "## Study checks",
        "",
        result["study_checks"]["exclusion_rule"],
        "",
    ]
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", default=str(ROOT / "data" / "study.sqlite3"))
    parser.add_argument("--config", default=str(ROOT / "config" / "study.json"))
    parser.add_argument("--json-out")
    parser.add_argument("--markdown-out")
    args = parser.parse_args()
    config = load_config(args.config)
    db_path = Path(args.db)
    if not db_path.exists():
        rows = {"trials": [], "rankings": [], "checklists": [], "poststudy": []}
    else:
        connection = sqlite3.connect(db_path)
        connection.row_factory = sqlite3.Row
        try:
            rows = read_rows(connection)
        finally:
            connection.close()
    result = analyse(config, rows)
    report = markdown_report(result)
    print(report)
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    if args.markdown_out:
        Path(args.markdown_out).write_text(report + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
