# Scoring methodology

The canonical ratings and legal weights are in `../../methods_scoring/inputs/paper_inputs.json`. All 312 source-specific justifications are in `../../methods_scoring/inputs/score_evidence.json`. The complete specification is `../../methods_scoring/assess_xai_compliance_documentation.md`.
