# Third-party notices

## Vue

The participant and researcher interfaces use the vendored Vue 3.5.13 global production build at `static/assets/vendor/vue.global.prod.js`. Vue is distributed under the MIT License. Upstream project: https://github.com/vuejs/core

## WDBC dataset

The technical case uses the Wisconsin Diagnostic Breast Cancer dataset from the UCI Machine Learning Repository, DOI `10.24432/C5DW2B`, through the scikit-learn packaged copy. The repository documentation records the dataset source and dataset copy hash. UCI publishes this dataset under CC BY 4.0.

## Python benchmark libraries

The reproducibility environment uses NumPy, pandas, scikit-learn, SHAP and joblib. Exact versions recorded by the frozen benchmark are stored in `benchmark/results/case_study.json`. Their upstream licenses apply to those dependencies.

## Waitress

Waitress is the supported production WSGI server and is pinned in `requirements-runtime.txt`. Its upstream license applies.
