#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

usage() {
  printf 'Usage: %s PORT\nExample: %s 8080\n' "$0" "$0" >&2
  exit 2
}

[[ $# -eq 1 ]] || usage
PORT="$1"
[[ "$PORT" =~ ^[0-9]+$ ]] || usage
(( PORT >= 1 && PORT <= 65535 )) || usage

VENV_DIR="$ROOT/.venv"
SECRETS_FILE="$ROOT/.study-secrets.env"
DB_PATH="$ROOT/data/public-review.sqlite3"
APP_LOG="$ROOT/data/public-review-app.log"

[[ -x "$VENV_DIR/bin/python" ]] || {
  printf 'run error: setup has not been completed; run ./setup.sh first\n' >&2
  exit 1
}
[[ -f "$SECRETS_FILE" ]] || {
  printf 'run error: %s is missing; run ./setup.sh first\n' "$SECRETS_FILE" >&2
  exit 1
}

# shellcheck disable=SC1090
source "$SECRETS_FILE"
export STUDY_SECRET STUDY_ADMIN_TOKEN

# Refuse to trample any listener reachable on this port.
"$VENV_DIR/bin/python" - "$PORT" <<'PY'
import socket, sys
port = int(sys.argv[1])
s = socket.socket()
try:
    s.bind(("0.0.0.0", port))
except OSError as exc:
    raise SystemExit(f"port {port} is unavailable: {exc}")
finally:
    s.close()
PY

mkdir -p "$ROOT/data"
MODE="demo"

printf 'Starting Legal XAI study on 0.0.0.0:%s in %s mode.\n' "$PORT" "$MODE"
printf 'Direct-IP review uses plain HTTP: use for controlled demo/review only.\n'
printf 'Live recruitment remains fail-closed until approved HTTPS deployment and institutional gates are complete.\n'
printf 'Application log: %s\n\n' "$APP_LOG"

# Deliberately omit --secure-cookie because this launcher is plain HTTP.
# Live mode in app.py still requires Secure cookies and HTTPS termination.
"$VENV_DIR/bin/python" app.py \
  --host 0.0.0.0 \
  --port "$PORT" \
  --server waitress \
  --mode "$MODE" \
  --db "$DB_PATH" \
  >"$APP_LOG" 2>&1 &
APP_PID=$!

cleanup() {
  if kill -0 "$APP_PID" >/dev/null 2>&1; then
    kill "$APP_PID" >/dev/null 2>&1 || true
    wait "$APP_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT INT TERM

READY=0
for ((i=0; i<50; i++)); do
  if ! kill -0 "$APP_PID" >/dev/null 2>&1; then
    printf 'run error: application exited during startup\n' >&2
    cat "$APP_LOG" >&2 || true
    exit 1
  fi
  if "$VENV_DIR/bin/python" - "$PORT" <<'PY' >/dev/null 2>&1
import json, sys, urllib.request
port = int(sys.argv[1])
with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/public-config", timeout=0.5) as response:
    json.load(response)
PY
  then
    READY=1
    break
  fi
  sleep 0.1
done

if [[ "$READY" -ne 1 ]]; then
  printf 'run error: application did not become ready on port %s\n' "$PORT" >&2
  cat "$APP_LOG" >&2 || true
  exit 1
fi

SERVER_IP="$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for (i=1; i<=NF; i++) if ($i == "src") {print $(i+1); exit}}' || true)"
if [[ -z "$SERVER_IP" ]]; then
  SERVER_IP="$(hostname -I 2>/dev/null | awk '{print $1}' || true)"
fi

printf 'Application is ready.\n'
if [[ -n "$SERVER_IP" ]]; then
  printf 'Browser URL: http://%s:%s\n' "$SERVER_IP" "$PORT"
else
  printf 'Browser URL: http://<SERVER-PUBLIC-IP>:%s\n' "$PORT"
fi
printf 'The host/provider firewall must allow inbound TCP/%s.\n' "$PORT"
printf 'Press Ctrl-C to stop the application.\n'

wait "$APP_PID"
