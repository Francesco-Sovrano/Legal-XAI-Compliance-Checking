#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

PYTHON_BIN="${PYTHON_BIN:-python3}"
VENV_DIR="$ROOT/.venv"
VENV_PY="$VENV_DIR/bin/python"
SECRETS_FILE="$ROOT/.study-secrets.env"
RUNTIME_REQUIREMENTS="$ROOT/requirements-runtime.txt"

log()  { printf '[setup] %s\n' "$*"; }
warn() { printf '[setup] WARNING: %s\n' "$*" >&2; }
fail() { printf '[setup] ERROR: %s\n' "$*" >&2; exit 1; }

have_apt() {
  command -v apt-get >/dev/null 2>&1
}

# Install Debian/Ubuntu packages using root directly or sudo when available.
# This is only called when the requested capability is actually missing.
apt_install() {
  have_apt || return 1
  local -a elevate=()
  if [[ "$(id -u)" -ne 0 ]]; then
    command -v sudo >/dev/null 2>&1 || {
      warn "sudo is unavailable, so required OS packages cannot be installed automatically."
      return 1
    }
    elevate=(sudo)
  fi

  log "Installing required Debian packages: $*"
  export DEBIAN_FRONTEND=noninteractive
  "${elevate[@]}" apt-get update
  "${elevate[@]}" apt-get install -y --no-install-recommends "$@"
}

ensure_python() {
  if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
    if have_apt && apt_install python3; then
      PYTHON_BIN=python3
    else
      fail "python3 is required. On Debian run: sudo apt-get update && sudo apt-get install -y python3"
    fi
  fi

  "$PYTHON_BIN" - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit(f"Python 3.10 or newer is required; found {sys.version.split()[0]}")
print(f"Python {sys.version.split()[0]}")
PY
}

python_major_minor() {
  "$PYTHON_BIN" - <<'PY'
import sys
print(f"{sys.version_info.major}.{sys.version_info.minor}")
PY
}

install_venv_support_debian() {
  local py_mm exact_pkg
  py_mm="$(python_major_minor)"
  exact_pkg="python${py_mm}-venv"

  if command -v apt-cache >/dev/null 2>&1 && apt-cache show "$exact_pkg" >/dev/null 2>&1; then
    apt_install "$exact_pkg"
  else
    apt_install python3-venv
  fi
}

create_or_repair_venv() {
  # A failed `python -m venv` can leave an empty/partial .venv directory.
  # Merely checking `-d .venv` is therefore insufficient.  This was the
  # cause of the "bin/activate: No such file" failure on a fresh Debian host.
  if [[ -d "$VENV_DIR" && ! -x "$VENV_PY" ]]; then
    warn "Found an incomplete virtual environment at $VENV_DIR; removing it and rebuilding."
    rm -rf "$VENV_DIR"
  fi

  if [[ ! -x "$VENV_PY" ]]; then
    log "Creating Python virtual environment at $VENV_DIR"
    local first_error
    first_error="$(mktemp)"
    if ! "$PYTHON_BIN" -m venv "$VENV_DIR" 2> >(tee "$first_error" >&2); then
      rm -rf "$VENV_DIR"

      if have_apt; then
        warn "Python venv creation failed. Attempting to install Debian venv support."
        if ! install_venv_support_debian; then
          rm -f "$first_error"
          fail "could not install Python venv support automatically. Run: sudo apt-get update && sudo apt-get install -y python3-venv"
        fi
        log "Retrying virtual environment creation"
        "$PYTHON_BIN" -m venv "$VENV_DIR" || {
          rm -f "$first_error"
          fail "virtual environment creation still failed after installing venv support"
        }
      else
        cat "$first_error" >&2 || true
        rm -f "$first_error"
        fail "Python's venv support is unavailable. Install the venv package for your Python version and rerun setup.sh"
      fi
    fi
    rm -f "$first_error"
  else
    log "Using existing virtual environment at $VENV_DIR"
  fi

  [[ -x "$VENV_PY" ]] || fail "virtual environment is incomplete: $VENV_PY was not created"

  # Do not source bin/activate. Calling the venv interpreter directly is more
  # reliable in non-interactive shells and avoids depending on activate files.
  if ! "$VENV_PY" -m pip --version >/dev/null 2>&1; then
    log "pip is missing inside the virtual environment; attempting ensurepip"
    "$VENV_PY" -m ensurepip --upgrade || fail "pip could not be bootstrapped inside $VENV_DIR"
  fi
}

create_secrets() {
  if [[ ! -f "$SECRETS_FILE" ]]; then
    local study_secret admin_token
    study_secret="$($VENV_PY - <<'PY'
import secrets
print(secrets.token_urlsafe(64))
PY
)"
    admin_token="$($VENV_PY - <<'PY'
import secrets
print(secrets.token_urlsafe(48))
PY
)"
    umask 077
    cat > "$SECRETS_FILE" <<ENV
export STUDY_SECRET='$study_secret'
export STUDY_ADMIN_TOKEN='$admin_token'
ENV
    chmod 0600 "$SECRETS_FILE"
    log "Generated private study secrets in $SECRETS_FILE"
  else
    chmod 0600 "$SECRETS_FILE"
    log "Keeping existing study secrets in $SECRETS_FILE"
  fi
}

main() {
  ensure_python
  [[ -f "$RUNTIME_REQUIREMENTS" ]] || fail "missing $RUNTIME_REQUIREMENTS"

  create_or_repair_venv

  log "Installing Python runtime dependencies"
  if ! "$VENV_PY" -m pip install \
      --disable-pip-version-check \
      --retries 4 \
      --timeout 30 \
      -r "$RUNTIME_REQUIREMENTS"; then
    fail "Python dependency installation failed. Check this machine's Internet/DNS access and rerun ./setup.sh; the virtual environment can be reused safely."
  fi

  mkdir -p "$ROOT/data"
  create_secrets

  log "Running runtime import check"
  PYTHONPATH="$ROOT" "$VENV_PY" - <<'PY'
import waitress
import app
print("Runtime import check: PASS")
PY

  printf '\nSetup complete.\n'
  printf 'No shell activation is required.\n'
  printf 'Start the direct-IP demo review server with exactly one argument, the port:\n'
  printf '  ./run_public.sh 8080\n'
}

main "$@"
