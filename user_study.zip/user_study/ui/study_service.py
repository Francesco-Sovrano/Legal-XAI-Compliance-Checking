"""Persistence and state machine for the fixed-roster, small-N panel study.

Every invited legal expert completes both legal contexts. Both contexts'
primary judgments and comparisons are locked before any secondary checklist.
"""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import json
from pathlib import Path
import secrets
import sqlite3
import uuid
from typing import Any, Iterator

from study_core import (
    assignment_for,
    config_hash,
    hidden_debug_record,
    participant_comparison_cards,
    participant_module,
    participant_trial,
    randomized_checklist,
)


class StudyStateError(ValueError):
    """Raised for invalid or out-of-order participant actions."""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def db_connection(db_path: str | Path) -> Iterator[sqlite3.Connection]:
    connection = sqlite3.connect(str(db_path), timeout=20)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    connection.execute("PRAGMA journal_mode=WAL")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


SCHEMA_VERSION = "11"
SCHEMA = """
CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    panel_slot TEXT NOT NULL UNIQUE,
    module_order_json TEXT NOT NULL,
    module_id TEXT NOT NULL,
    sequence_index INTEGER NOT NULL,
    stage TEXT NOT NULL,
    current_trial INTEGER NOT NULL,
    csrf_token TEXT NOT NULL,
    experience_band TEXT NOT NULL,
    years_legal_experience INTEGER NOT NULL,
    gdpr_familiarity INTEGER NOT NULL,
    mdr_familiarity INTEGER NOT NULL,
    consent_version TEXT NOT NULL,
    consent_json TEXT NOT NULL,
    consented_at TEXT NOT NULL,
    config_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    completed_at TEXT
);
CREATE TABLE IF NOT EXISTS orientation_responses (
    session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    module_id TEXT NOT NULL,
    attempt_no INTEGER NOT NULL,
    responses_json TEXT NOT NULL,
    correct_count INTEGER NOT NULL,
    passed INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (session_id, module_id, attempt_no)
);
CREATE TABLE IF NOT EXISTS assignments (
    session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    module_id TEXT NOT NULL,
    trial_index INTEGER NOT NULL,
    case_id TEXT NOT NULL,
    condition_id TEXT NOT NULL,
    blind_label TEXT NOT NULL,
    PRIMARY KEY (session_id, module_id, trial_index),
    UNIQUE (session_id, module_id, condition_id),
    UNIQUE (session_id, module_id, blind_label)
);
CREATE TABLE IF NOT EXISTS trial_responses (
    session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    module_id TEXT NOT NULL,
    trial_index INTEGER NOT NULL,
    condition_id TEXT NOT NULL,
    disposition TEXT NOT NULL,
    answers_legal_question INTEGER NOT NULL,
    enables_legal_objective INTEGER NOT NULL,
    confidence INTEGER NOT NULL,
    rationale TEXT NOT NULL,
    additional_information TEXT NOT NULL,
    visual_appearance_influenced TEXT NOT NULL,
    visual_format_comments TEXT NOT NULL,
    elapsed_ms INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (session_id, module_id, trial_index)
);
CREATE TABLE IF NOT EXISTS ranking_responses (
    session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    module_id TEXT NOT NULL,
    blind_label TEXT NOT NULL,
    condition_id TEXT NOT NULL,
    score_decision TEXT NOT NULL,
    revised_answers_legal_question INTEGER NOT NULL,
    revised_enables_legal_objective INTEGER NOT NULL,
    revised_confidence INTEGER NOT NULL,
    rank_group INTEGER NOT NULL,
    rationale TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (session_id, module_id, blind_label)
);
CREATE TABLE IF NOT EXISTS checklist_responses (
    session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    module_id TEXT NOT NULL,
    condition_id TEXT NOT NULL,
    blind_label TEXT NOT NULL,
    item_id TEXT NOT NULL,
    score INTEGER NOT NULL,
    comment TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (session_id, module_id, condition_id, item_id)
);
CREATE TABLE IF NOT EXISTS poststudy_responses (
    session_id TEXT PRIMARY KEY REFERENCES sessions(id) ON DELETE CASCADE,
    checklist_new_considerations TEXT NOT NULL,
    technical_fact_understanding INTEGER NOT NULL,
    method_recognition TEXT NOT NULL,
    comments TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS withdrawal_metrics (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    withdrawn_sessions INTEGER NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT REFERENCES sessions(id) ON DELETE CASCADE,
    event_type TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);
"""


def ensure_database(db_path: str | Path, config: dict[str, Any]) -> None:
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    expected_hash = config_hash(config)
    with db_connection(db_path) as connection:
        connection.executescript(SCHEMA)
        schema_row = connection.execute(
            "SELECT value FROM metadata WHERE key='schema_version'"
        ).fetchone()
        if schema_row and schema_row["value"] != SCHEMA_VERSION:
            raise StudyStateError(
                "Database schema is from another study version; use a new database file."
            )
        connection.execute(
            "INSERT OR REPLACE INTO metadata(key,value) VALUES('schema_version',?)",
            (SCHEMA_VERSION,),
        )
        row = connection.execute(
            "SELECT value FROM metadata WHERE key='config_hash'"
        ).fetchone()
        if row and row["value"] != expected_hash:
            count = connection.execute("SELECT COUNT(*) AS n FROM sessions").fetchone()["n"]
            if count:
                raise StudyStateError(
                    "Database already contains responses for a different configuration hash."
                )
            connection.execute(
                "UPDATE metadata SET value=? WHERE key='config_hash'", (expected_hash,)
            )
        elif not row:
            connection.execute(
                "INSERT INTO metadata(key,value) VALUES('config_hash',?)", (expected_hash,)
            )
        connection.execute(
            "INSERT OR REPLACE INTO metadata(key,value) VALUES('study_id',?)",
            (config["study_id"],),
        )
        connection.execute(
            "INSERT OR IGNORE INTO withdrawal_metrics(id,withdrawn_sessions,updated_at) "
            "VALUES(1,0,?)",
            (utc_now(),),
        )


def _event(
    connection: sqlite3.Connection,
    session_id: str | None,
    event_type: str,
    payload: dict[str, Any] | None = None,
) -> None:
    connection.execute(
        "INSERT INTO events(session_id,event_type,payload_json,created_at) VALUES(?,?,?,?)",
        (session_id, event_type, json.dumps(payload or {}, sort_keys=True), utc_now()),
    )


def _session(connection: sqlite3.Connection, session_id: str) -> sqlite3.Row:
    row = connection.execute("SELECT * FROM sessions WHERE id=?", (session_id,)).fetchone()
    if not row:
        raise StudyStateError("Study session not found.")
    return row


def _module_order(session: sqlite3.Row) -> list[str]:
    return list(json.loads(session["module_order_json"]))


def _comparison_order(config: dict[str, Any], session: sqlite3.Row) -> list[str]:
    return [
        module_id for module_id in _module_order(session)
        if config["modules"][module_id].get("comparison_enabled", True)
    ]


def _checklist_order(config: dict[str, Any], session: sqlite3.Row) -> list[str]:
    return [
        module_id for module_id in _module_order(session)
        if config["modules"][module_id].get("show_checklist", False)
    ]


def _assignments(
    connection: sqlite3.Connection, session_id: str, module_id: str
) -> list[dict[str, Any]]:
    rows = connection.execute(
        "SELECT trial_index,case_id,condition_id,blind_label FROM assignments "
        "WHERE session_id=? AND module_id=? ORDER BY trial_index",
        (session_id, module_id),
    ).fetchall()
    return [dict(row) for row in rows]


def _bounded_int(value: Any, minimum: int, maximum: int, name: str) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError) as exc:
        raise StudyStateError(f"{name} must be an integer.") from exc
    if not minimum <= parsed <= maximum:
        raise StudyStateError(f"{name} must be between {minimum} and {maximum}.")
    return parsed


def _text(value: Any, name: str, minimum: int = 0, maximum: int = 4000) -> str:
    parsed = str(value or "").strip()
    if len(parsed) < minimum:
        raise StudyStateError(f"{name} must contain at least {minimum} characters.")
    if len(parsed) > maximum:
        raise StudyStateError(f"{name} must contain no more than {maximum} characters.")
    return parsed


EXPERIENCE_BANDS = {
    "legal-academic",
    "legal-practitioner",
    "regulator-policy",
    "mixed-legal-technical",
    "other-legal",
}
CONSENT_KEYS = {
    "age_confirmed",
    "participation_consent",
    "data_use_consent",
    "role_acknowledged",
}


def _roster_record(config: dict[str, Any], submitted_code: Any) -> dict[str, Any]:
    code = str(submitted_code or "").strip().upper()
    if not code:
        raise StudyStateError("Enter the invitation code supplied by the research team.")
    for record in config.get("panel", {}).get("roster", []):
        expected = str(record.get("access_code", "")).strip().upper()
        if expected and secrets.compare_digest(code, expected):
            return record
    raise StudyStateError("Invitation code not recognised.")


def resume_session(
    db_path: str | Path,
    config: dict[str, Any],
    panel_code: str,
) -> dict[str, Any]:
    """Resume an existing unfinished session using only the invitation code."""
    record = _roster_record(config, panel_code)
    slot_id = record["slot_id"]
    with db_connection(db_path) as connection:
        connection.execute("BEGIN IMMEDIATE")
        existing = connection.execute(
            "SELECT id,csrf_token,module_id,stage FROM sessions WHERE panel_slot=?", (slot_id,)
        ).fetchone()
        if not existing:
            raise StudyStateError(
                "No unfinished study was found for this invitation code. If you are starting for the first time, complete the participant details below."
            )
        if existing["stage"] == "complete":
            raise StudyStateError("This study has already been completed for this invitation code.")
        _event(connection, existing["id"], "session_resumed", {"panel_slot": slot_id})
        return {
            "session_id": existing["id"],
            "csrf_token": existing["csrf_token"],
            "module_id": existing["module_id"],
            "panel_slot": slot_id,
            "resumed": True,
        }


def start_session(
    db_path: str | Path,
    config: dict[str, Any],
    panel_code: str,
    experience_band: str,
    years_legal_experience: Any,
    gdpr_familiarity: Any,
    mdr_familiarity: Any,
    consent: dict[str, Any] | None,
) -> dict[str, Any]:
    record = _roster_record(config, panel_code)
    if experience_band not in EXPERIENCE_BANDS:
        raise StudyStateError("Please select a valid professional background.")
    years = _bounded_int(years_legal_experience, 0, 70, "Years of legal experience")
    gdpr = _bounded_int(gdpr_familiarity, 1, 5, "GDPR familiarity")
    mdr = _bounded_int(mdr_familiarity, 1, 5, "MDR familiarity")
    if not isinstance(consent, dict) or not all(consent.get(key) is True for key in CONSENT_KEYS):
        raise StudyStateError("All consent and role-separation confirmations are required.")

    slot_id = record["slot_id"]
    module_order = list(record["module_order"])
    sequence_index = int(record["sequence_index"])
    with db_connection(db_path) as connection:
        connection.execute("BEGIN IMMEDIATE")
        existing = connection.execute(
            "SELECT id,csrf_token,module_id FROM sessions WHERE panel_slot=?", (slot_id,)
        ).fetchone()
        if existing:
            _event(connection, existing["id"], "session_resumed", {"panel_slot": slot_id})
            return {
                "session_id": existing["id"],
                "csrf_token": existing["csrf_token"],
                "module_id": existing["module_id"],
                "panel_slot": slot_id,
                "resumed": True,
            }

        session_id = uuid.uuid4().hex
        csrf_token = secrets.token_urlsafe(24)
        now = utc_now()
        connection.execute(
            "INSERT INTO sessions(id,panel_slot,module_order_json,module_id,sequence_index,"
            "stage,current_trial,csrf_token,experience_band,years_legal_experience,"
            "gdpr_familiarity,mdr_familiarity,consent_version,consent_json,consented_at,config_hash,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                session_id,
                slot_id,
                json.dumps(module_order),
                module_order[0],
                sequence_index,
                "orientation",
                0,
                csrf_token,
                experience_band,
                years,
                gdpr,
                mdr,
                config.get("ethics", {}).get("consent_version", "unspecified"),
                json.dumps(consent, sort_keys=True),
                now,
                config_hash(config),
                now,
            ),
        )
        sequence_map = record.get("condition_sequence_indices", {})
        for module_position, module_id in enumerate(module_order):
            assignment_index = int(
                sequence_map.get(module_id, (sequence_index + 2 * module_position) % 4)
            )
            assignment = assignment_for(
                config["modules"][module_id],
                assignment_index,
                f"{config['study_id']}:{slot_id}:{module_id}",
                case_sequence_index=0,
            )
            connection.executemany(
                "INSERT INTO assignments(session_id,module_id,trial_index,case_id,"
                "condition_id,blind_label) VALUES(?,?,?,?,?,?)",
                [
                    (
                        session_id,
                        module_id,
                        item["trial_index"],
                        item["case_id"],
                        item["condition_id"],
                        item["blind_label"],
                    )
                    for item in assignment
                ],
            )
        _event(
            connection,
            session_id,
            "session_started",
            {
                "panel_slot": slot_id,
                "module_order": module_order,
                "sequence_index": sequence_index,
                "consent_version": config.get("ethics", {}).get("consent_version"),
            },
        )
    return {
        "session_id": session_id,
        "csrf_token": csrf_token,
        "module_id": module_order[0],
        "panel_slot": slot_id,
        "resumed": False,
    }


def get_state(
    db_path: str | Path, config: dict[str, Any], session_id: str
) -> dict[str, Any]:
    with db_connection(db_path) as connection:
        session = _session(connection, session_id)
        order = _module_order(session)
        active_module = session["module_id"]
        completed_trials = int(connection.execute(
            "SELECT COUNT(*) AS n FROM trial_responses WHERE session_id=?", (session_id,)
        ).fetchone()["n"])
        completed_orientations = int(connection.execute(
            "SELECT COUNT(DISTINCT module_id) AS n FROM orientation_responses "
            "WHERE session_id=? AND passed=1", (session_id,)
        ).fetchone()["n"])
        completed_comparisons = int(connection.execute(
            "SELECT COUNT(DISTINCT module_id) AS n FROM ranking_responses WHERE session_id=?",
            (session_id,),
        ).fetchone()["n"])
        completed_checklists = int(connection.execute(
            "SELECT COUNT(DISTINCT module_id) AS n FROM checklist_responses WHERE session_id=?",
            (session_id,),
        ).fetchone()["n"])
        attempts = int(connection.execute(
            "SELECT COUNT(*) AS n FROM orientation_responses WHERE session_id=? AND module_id=?",
            (session_id, active_module),
        ).fetchone()["n"])
        total_trials = sum(len(config["modules"][item]["conditions"]) for item in order)
        poststudy_checks: list[dict[str, Any]] = []
        for module_id in order:
            poststudy_checks.extend(
                {key: value for key, value in item.items() if key != "correct"}
                for item in config["modules"][module_id].get("poststudy_checks", [])
            )
        return {
            "session_id": session_id,
            "panel_slot": session["panel_slot"],
            "stage": session["stage"],
            "current_trial": int(session["current_trial"]),
            "global_trial_number": min(completed_trials + 1, total_trials),
            "completed_trials": completed_trials,
            "total_trials": total_trials,
            "completed_orientations": completed_orientations,
            "completed_comparisons": completed_comparisons,
            "total_comparisons": len(_comparison_order(config, session)),
            "completed_checklists": completed_checklists,
            "total_checklists": len(_checklist_order(config, session)),
            "total_modules": len(order),
            "module_position": order.index(active_module) + 1,
            "module_order": [participant_module(config["modules"][item]) for item in order],
            "orientation_attempts": attempts,
            "module": participant_module(config["modules"][active_module]),
            "poststudy_checks": poststudy_checks,
            "csrf_token": session["csrf_token"],
            "study_title": config["title"],
            "study_version": config["version"],
            "withdrawal_allowed": session["stage"] != "complete",
        }


def participant_results_rows(
    db_path: str | Path, config: dict[str, Any], session_id: str
) -> list[dict[str, str]]:
    """Return a compact participant-facing export for exactly one authenticated session.

    The caller supplies the session identifier recovered from the signed HttpOnly
    cookie. No participant or researcher identifier is accepted from a query
    string or request body, and hidden method identities are never exported.
    """
    columns = ("context", "explanation", "section", "item", "response", "note", "recorded_at")
    rows: list[dict[str, str]] = []

    def add(context: str, explanation: str, section: str, item: str, response: Any, note: Any, recorded_at: Any) -> None:
        rows.append({
            "context": str(context or ""),
            "explanation": str(explanation or ""),
            "section": str(section or ""),
            "item": str(item or ""),
            "response": "" if response is None else str(response),
            "note": "" if note is None else str(note),
            "recorded_at": "" if recorded_at is None else str(recorded_at),
        })

    with db_connection(db_path) as connection:
        _session(connection, session_id)  # validates that the authenticated session still exists
        assignments = connection.execute(
            "SELECT module_id,trial_index,condition_id,blind_label FROM assignments "
            "WHERE session_id=? ORDER BY module_id,trial_index", (session_id,)
        ).fetchall()
        label_by_condition = {(r["module_id"], r["condition_id"]): r["blind_label"] for r in assignments}

        for row in connection.execute(
            "SELECT * FROM trial_responses WHERE session_id=? ORDER BY created_at,module_id,trial_index",
            (session_id,),
        ).fetchall():
            context = config["modules"][row["module_id"]]["short_label"]
            label = label_by_condition.get((row["module_id"], row["condition_id"]), "")
            explanation = f"Explanation {label}" if label else ""
            values = [
                ("overall_assessment", row["disposition"]),
                ("answers_legal_question_1_to_7", row["answers_legal_question"]),
                ("enables_legal_objective_1_to_7", row["enables_legal_objective"]),
                ("confidence_1_to_5", row["confidence"]),
                ("additional_information", row["additional_information"]),
                ("visual_appearance_influenced", row["visual_appearance_influenced"]),
                ("visual_format_comments", row["visual_format_comments"]),
            ]
            for item, value in values:
                add(context, explanation, "primary_judgment", item, value, row["rationale"] if item == "overall_assessment" else "", row["created_at"])

        for row in connection.execute(
            "SELECT * FROM ranking_responses WHERE session_id=? ORDER BY created_at,module_id,rank_group",
            (session_id,),
        ).fetchall():
            context = config["modules"][row["module_id"]]["short_label"]
            explanation = f"Explanation {row['blind_label']}"
            values = [
                ("score_decision", row["score_decision"]),
                ("revised_answers_legal_question_1_to_7", row["revised_answers_legal_question"]),
                ("revised_enables_legal_objective_1_to_7", row["revised_enables_legal_objective"]),
                ("revised_confidence_1_to_5", row["revised_confidence"]),
                ("final_rank_1_is_strongest", row["rank_group"]),
            ]
            for item, value in values:
                add(context, explanation, "explanation_reranking", item, value, row["rationale"] if item == "score_decision" else "", row["created_at"])

        for row in connection.execute(
            "SELECT * FROM checklist_responses WHERE session_id=? ORDER BY created_at,module_id,blind_label,item_id",
            (session_id,),
        ).fetchall():
            context = config["modules"][row["module_id"]]["short_label"]
            add(context, f"Explanation {row['blind_label']}", "theory_guided_checklist", row["item_id"], row["score"], row["comment"], row["created_at"])

        post = connection.execute(
            "SELECT * FROM poststudy_responses WHERE session_id=?", (session_id,)
        ).fetchone()
        if post:
            for item, value in [
                ("checklist_new_considerations", post["checklist_new_considerations"]),
                ("technical_fact_understanding_1_to_5", post["technical_fact_understanding"]),
                ("method_recognition", post["method_recognition"]),
                ("comments", post["comments"]),
            ]:
                add("Study-wide", "", "final_feedback", item, value, "", post["created_at"])

    # Assert the export contract stays lightweight and contains no accidental extra fields.
    assert all(tuple(row.keys()) == columns for row in rows)
    return rows


def get_orientation(
    db_path: str | Path, config: dict[str, Any], session_id: str
) -> dict[str, Any]:
    with db_connection(db_path) as connection:
        session = _session(connection, session_id)
        if session["stage"] != "orientation":
            raise StudyStateError("The current legal-context briefing is not available.")
        module = config["modules"][session["module_id"]]
        orientation = config["orientation"]
        return {
            "title": orientation["title"],
            "instructions": module.get("orientation_instructions", orientation["instructions"]),
            "legal_context": participant_module(module),
            "evidence_explainer": orientation["evidence_explainer"],
            "questions": [
                {key: value for key, value in item.items() if key != "correct"}
                for item in orientation["questions"]
            ],
        }


def save_orientation(
    db_path: str | Path,
    config: dict[str, Any],
    session_id: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    answers = payload.get("answers")
    if not isinstance(answers, dict):
        raise StudyStateError("Orientation answers must be supplied.")
    questions = config["orientation"]["questions"]
    expected_ids = {item["id"] for item in questions}
    if set(answers) != expected_ids:
        raise StudyStateError("Answer every orientation question exactly once.")
    allowed = {item["id"]: {option["value"] for option in item["options"]} for item in questions}
    if any(answers[item_id] not in allowed[item_id] for item_id in expected_ids):
        raise StudyStateError("Orientation contains an unknown answer option.")
    correct_count = sum(answers[item["id"]] == item["correct"] for item in questions)
    passed = correct_count == len(questions)
    with db_connection(db_path) as connection:
        connection.execute("BEGIN IMMEDIATE")
        session = _session(connection, session_id)
        if session["stage"] != "orientation":
            raise StudyStateError("The current legal-context briefing is already complete.")
        module_id = session["module_id"]
        attempt = int(connection.execute(
            "SELECT COUNT(*) AS n FROM orientation_responses WHERE session_id=? AND module_id=?",
            (session_id, module_id),
        ).fetchone()["n"]) + 1
        connection.execute(
            "INSERT INTO orientation_responses(session_id,module_id,attempt_no,responses_json,"
            "correct_count,passed,created_at) VALUES(?,?,?,?,?,?,?)",
            (
                session_id,
                module_id,
                attempt,
                json.dumps(answers, sort_keys=True),
                correct_count,
                int(passed),
                utc_now(),
            ),
        )
        if passed:
            connection.execute("UPDATE sessions SET stage='trials' WHERE id=?", (session_id,))
            _event(connection, session_id, "orientation_passed", {"module": module_id, "attempt": attempt})
        else:
            _event(connection, session_id, "orientation_failed", {
                "module": module_id, "attempt": attempt, "correct_count": correct_count
            })
    return {
        "passed": passed,
        "attempt": attempt,
        "correct_count": correct_count,
        "total": len(questions),
        "feedback": (
            "All answers are correct. This context can begin."
            if passed
            else "Review the role separation and legal task packet, then try again."
        ),
        "state": get_state(db_path, config, session_id),
    }


def continue_after_break(
    db_path: str | Path, config: dict[str, Any], session_id: str
) -> dict[str, Any]:
    with db_connection(db_path) as connection:
        connection.execute("BEGIN IMMEDIATE")
        session = _session(connection, session_id)
        if session["stage"] != "intermission":
            raise StudyStateError("The midpoint break is not available at this stage.")
        connection.execute("UPDATE sessions SET stage='orientation' WHERE id=?", (session_id,))
        _event(connection, session_id, "midpoint_break_completed", {"next_module": session["module_id"]})
    return get_state(db_path, config, session_id)


def get_current_trial(
    db_path: str | Path, config: dict[str, Any], session_id: str
) -> dict[str, Any]:
    with db_connection(db_path) as connection:
        session = _session(connection, session_id)
        if session["stage"] != "trials":
            raise StudyStateError("Primary trials are not available at this stage.")
        assignment = _assignments(connection, session_id, session["module_id"])[
            int(session["current_trial"])
        ]
        return participant_trial(config["modules"][session["module_id"]], assignment)


DISPOSITIONS = {
    "sufficient", "minor-remediation", "material-remediation",
    "inadequate", "insufficient-information",
}
RELIANCE = {"yes", "no", "uncertain"}


def save_trial(
    db_path: str | Path,
    config: dict[str, Any],
    session_id: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    with db_connection(db_path) as connection:
        connection.execute("BEGIN IMMEDIATE")
        session = _session(connection, session_id)
        if session["stage"] != "trials":
            raise StudyStateError("Primary trials are not available at this stage.")
        module_id = session["module_id"]
        current_trial = int(session["current_trial"])
        if int(payload.get("trial_index", -1)) != current_trial:
            raise StudyStateError("Out-of-order trial submission rejected.")
        assignment = _assignments(connection, session_id, module_id)[current_trial]
        disposition = payload.get("disposition")
        if disposition not in DISPOSITIONS:
            raise StudyStateError("Select an overall legal assessment.")
        if payload.get("visual_appearance_influenced") != "no":
            raise StudyStateError(
                "Review the explanation again and confirm that visual appearance did not influence the legal assessment."
            )
        values = (
            session_id, module_id, current_trial, assignment["condition_id"],
            disposition,
            _bounded_int(payload.get("answers_legal_question"), 1, 7, "Legal-question rating"),
            _bounded_int(payload.get("enables_legal_objective"), 1, 7, "Legal-objective rating"),
            _bounded_int(payload.get("confidence"), 1, 5, "Confidence"),
            _text(payload.get("rationale"), "Legal rationale", 20),
            _text(payload.get("additional_information"), "Additional information"),
            "no",
            _text(payload.get("visual_format_comments"), "Visual-format comments", 0, 2000),
            _bounded_int(payload.get("elapsed_ms", 0), 0, 7_200_000, "Elapsed time"),
            utc_now(),
        )
        try:
            connection.execute(
                "INSERT INTO trial_responses(session_id,module_id,trial_index,condition_id,"
                "disposition,answers_legal_question,enables_legal_objective,confidence,rationale,"
                "additional_information,visual_appearance_influenced,visual_format_comments,elapsed_ms,created_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                values,
            )
        except sqlite3.IntegrityError as exc:
            raise StudyStateError("This primary judgment is already locked.") from exc
        next_trial = current_trial + 1
        total = len(config["modules"][module_id]["conditions"])
        order = _module_order(session)
        module_index = order.index(module_id)
        if next_trial < total:
            connection.execute("UPDATE sessions SET current_trial=? WHERE id=?", (next_trial, session_id))
        elif module_index + 1 < len(order):
            connection.execute(
                "UPDATE sessions SET module_id=?,current_trial=0,stage='intermission' WHERE id=?",
                (order[module_index + 1], session_id),
            )
        else:
            comparison_order = _comparison_order(config, session)
            checklist_order = _checklist_order(config, session)
            if comparison_order:
                next_stage, next_module = "ranking", comparison_order[0]
            elif checklist_order:
                next_stage, next_module = "checklist", checklist_order[0]
            else:
                next_stage, next_module = "poststudy", order[-1]
            connection.execute(
                "UPDATE sessions SET module_id=?,current_trial=?,stage=? WHERE id=?",
                (next_module, total, next_stage, session_id),
            )
        _event(connection, session_id, "primary_judgment_locked", {
            "module": module_id,
            "trial_index": current_trial,
            "condition_id": assignment["condition_id"],
        })
    return get_state(db_path, config, session_id)


def get_comparison(
    db_path: str | Path, config: dict[str, Any], session_id: str
) -> dict[str, Any]:
    with db_connection(db_path) as connection:
        session = _session(connection, session_id)
        if session["stage"] not in {"ranking", "checklist"}:
            raise StudyStateError("Comparison is not available at this stage.")
        module_id = session["module_id"]
        module = config["modules"][module_id]
        assignments = _assignments(connection, session_id, module_id)
        comparison = participant_comparison_cards(module, assignments)
        comparison["legal_question"] = module["legal_question"]
        comparison["legal_objective"] = module["legal_objective"]
        labels = {item["condition_id"]: item["blind_label"] for item in assignments}
        rows = connection.execute(
            "SELECT condition_id,disposition,answers_legal_question,enables_legal_objective,confidence "
            "FROM trial_responses WHERE session_id=? AND module_id=?",
            (session_id, module_id),
        ).fetchall()
        by_label = {
            labels[row["condition_id"]]: {
                "disposition": row["disposition"],
                "answers_legal_question": row["answers_legal_question"],
                "enables_legal_objective": row["enables_legal_objective"],
                "confidence": row["confidence"],
            }
            for row in rows if row["condition_id"] in labels
        }
        order = sorted(
            by_label,
            key=lambda label: (
                -(by_label[label]["answers_legal_question"] + by_label[label]["enables_legal_objective"]),
                -by_label[label]["answers_legal_question"],
                label,
            ),
        )
        comparison["previous_assessments"] = {"order": order, "by_label": by_label}
        return comparison


def save_ranking(
    db_path: str | Path,
    config: dict[str, Any],
    session_id: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    rationale = _text(payload.get("rationale"), "Comparison rationale", 20)
    responses = payload.get("responses")
    if not isinstance(responses, list):
        raise StudyStateError("Comparison responses must be a list.")
    with db_connection(db_path) as connection:
        connection.execute("BEGIN IMMEDIATE")
        session = _session(connection, session_id)
        if session["stage"] != "ranking":
            raise StudyStateError("Comparison is already locked or not yet available.")
        module_id = session["module_id"]
        module = config["modules"][module_id]
        ranking_assignments = _assignments(connection, session_id, module_id)
        comparison_cards = participant_comparison_cards(module, ranking_assignments)["cards"]
        label_to_condition = {item["blind_label"]: item["condition_id"] for item in ranking_assignments}
        if len(responses) != len(label_to_condition):
            raise StudyStateError("Re-rank every explanation shown in this comparison.")
        prior_rows = connection.execute(
            "SELECT condition_id,answers_legal_question,enables_legal_objective,confidence "
            "FROM trial_responses WHERE session_id=? AND module_id=?",
            (session_id, module_id),
        ).fetchall()
        prior_by_condition = {
            row["condition_id"]: {
                "answers_legal_question": row["answers_legal_question"],
                "enables_legal_objective": row["enables_legal_objective"],
                "confidence": row["confidence"],
            }
            for row in prior_rows
        }
        if set(label_to_condition.values()) - set(prior_by_condition):
            raise StudyStateError("Primary judgments are required before re-ranking.")
        observed: set[str] = set()
        normalized: list[tuple[Any, ...]] = []
        rank_groups: list[int] = []
        now = utc_now()
        for item in responses:
            if not isinstance(item, dict):
                raise StudyStateError("Every re-ranking response must be an object.")
            label = item.get("blind_label")
            if label not in label_to_condition or label in observed:
                raise StudyStateError("Re-ranking must contain each blinded label once.")
            observed.add(label)
            condition_id = label_to_condition[label]
            prior = prior_by_condition[condition_id]
            score_decision = item.get("score_decision")
            if score_decision not in {"keep", "revise"}:
                raise StudyStateError(
                    f"Choose whether to keep or revise the scores for Explanation {label}."
                )
            revised_question = _bounded_int(
                item.get("revised_answers_legal_question", prior["answers_legal_question"]),
                1, 7, "Revised legal-question rating",
            )
            revised_objective = _bounded_int(
                item.get("revised_enables_legal_objective", prior["enables_legal_objective"]),
                1, 7, "Revised legal-objective rating",
            )
            revised_confidence = _bounded_int(
                item.get("revised_confidence", prior["confidence"]),
                1, 5, "Revised confidence rating",
            )
            prior_scores = (
                prior["answers_legal_question"],
                prior["enables_legal_objective"],
                prior["confidence"],
            )
            revised_scores = (revised_question, revised_objective, revised_confidence)
            if score_decision == "keep" and revised_scores != prior_scores:
                raise StudyStateError(
                    f"Explanation {label} is marked to keep its scores, so all scores must match the individual assessment."
                )
            if score_decision == "revise" and revised_scores == prior_scores:
                raise StudyStateError(
                    f"Explanation {label} is marked for revision; change at least one score."
                )
            revision_rationale = ""
            if score_decision == "revise":
                revision_rationale = _text(
                    item.get("revision_rationale"),
                    f"Reason for revised scores for Explanation {label}",
                    20,
                )
            row_rationale = rationale
            if revision_rationale:
                row_rationale = (
                    f"Score revision rationale: {revision_rationale}\n"
                    f"Final-order rationale: {rationale}"
                )
            rank_group = _bounded_int(item.get("rank_group"), 1, max(1, len(label_to_condition)), "Rank group")
            rank_groups.append(rank_group)
            normalized.append((
                session_id, module_id, label, condition_id, score_decision,
                revised_question, revised_objective, revised_confidence, rank_group, row_rationale, now,
            ))
        if observed != set(label_to_condition):
            raise StudyStateError("Re-ranking must contain each blinded label once.")
        unique_groups = sorted(set(rank_groups))
        expected_groups = list(range(1, len(normalized) + 1))
        if unique_groups != expected_groups:
            raise StudyStateError("The drag-and-drop ranking must place each explanation in one unique position.")
        connection.executemany(
            "INSERT INTO ranking_responses(session_id,module_id,blind_label,condition_id,"
            "score_decision,revised_answers_legal_question,revised_enables_legal_objective,"
            "revised_confidence,rank_group,rationale,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            normalized,
        )
        order = _comparison_order(config, session)
        index = order.index(module_id)
        if index + 1 < len(order):
            next_stage, next_module = "ranking", order[index + 1]
        else:
            checklist_order = _checklist_order(config, session)
            if checklist_order:
                next_stage, next_module = "checklist", checklist_order[0]
            else:
                next_stage, next_module = "poststudy", module_id
        connection.execute(
            "UPDATE sessions SET stage=?,module_id=? WHERE id=?",
            (next_stage, next_module, session_id),
        )
        _event(connection, session_id, "comparison_locked", {
            "module": module_id,
            "rank_groups": {item[2]: item[9] for item in normalized},
            "score_decisions": {item[2]: item[5] for item in normalized},
            "revision_rationale_recorded": {item[2]: item[5] == "revise" for item in normalized},
            "revised_scores": {
                item[2]: {
                    "answers_legal_question": item[6],
                    "enables_legal_objective": item[7],
                    "confidence": item[8],
                }
                for item in normalized
            },
            "ties_present": len(unique_groups) < len(normalized),
        })
    return get_state(db_path, config, session_id)


def get_checklist(
    db_path: str | Path, config: dict[str, Any], session_id: str
) -> dict[str, Any]:
    with db_connection(db_path) as connection:
        session = _session(connection, session_id)
        if session["stage"] != "checklist":
            raise StudyStateError("Secondary checklist is not available at this stage.")
        module_id = session["module_id"]
        module = config["modules"][module_id]
        return {
            "comparison": participant_comparison_cards(module, _assignments(connection, session_id, module_id)),
            "items": randomized_checklist(module, f"{session_id}:{module_id}"),
            "scale": {"1": "Clearly no", "2": "Leaning towards no", "3": "Leaning towards yes", "4": "Clearly yes"},
            "provenance": module.get("checklist_provenance", ""),
        }


def save_checklist(
    db_path: str | Path,
    config: dict[str, Any],
    session_id: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    responses = payload.get("responses")
    if not isinstance(responses, list):
        raise StudyStateError("Checklist responses must be a list.")
    with db_connection(db_path) as connection:
        connection.execute("BEGIN IMMEDIATE")
        session = _session(connection, session_id)
        if session["stage"] != "checklist":
            raise StudyStateError("Secondary checklist is already locked or not yet available.")
        module_id = session["module_id"]
        module = config["modules"][module_id]
        label_to_condition = {
            item["blind_label"]: item["condition_id"]
            for item in _assignments(connection, session_id, module_id)
        }
        item_ids = {item["id"] for item in module.get("checklist", [])}
        expected = {(label, item_id) for label in label_to_condition for item_id in item_ids}
        observed: set[tuple[str, str]] = set()
        normalized: list[tuple[Any, ...]] = []
        now = utc_now()
        for item in responses:
            label = item.get("blind_label")
            item_id = item.get("item_id")
            key = (label, item_id)
            if key not in expected or key in observed:
                raise StudyStateError("Checklist contains missing, duplicate, or unknown entries.")
            observed.add(key)
            normalized.append((
                session_id, module_id, label_to_condition[label], label, item_id,
                _bounded_int(item.get("score"), 1, 4, "Checklist score"),
                _text(item.get("comment"), "Checklist comment", maximum=1000), now,
            ))
        if observed != expected:
            raise StudyStateError("Complete every checklist item for every explanation.")
        connection.executemany(
            "INSERT INTO checklist_responses(session_id,module_id,condition_id,blind_label,"
            "item_id,score,comment,created_at) VALUES(?,?,?,?,?,?,?,?)",
            normalized,
        )
        order = _checklist_order(config, session)
        index = order.index(module_id)
        next_stage = "checklist" if index + 1 < len(order) else "poststudy"
        next_module = order[index + 1] if index + 1 < len(order) else module_id
        connection.execute(
            "UPDATE sessions SET stage=?,module_id=? WHERE id=?",
            (next_stage, next_module, session_id),
        )
        _event(connection, session_id, "secondary_checklist_locked", {
            "module": module_id, "count": len(normalized)
        })
    return get_state(db_path, config, session_id)


def save_poststudy(
    db_path: str | Path,
    config: dict[str, Any],
    session_id: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    understanding = _bounded_int(
        payload.get("technical_fact_understanding"), 1, 5, "Technical-fact understanding"
    )
    new_considerations = payload.get("checklist_new_considerations")
    if new_considerations not in {"yes", "no"}:
        raise StudyStateError("Select whether the checklist introduced new considerations.")
    recognition = _text(payload.get("method_recognition"), "Method recognition", maximum=2000)
    comments = _text(payload.get("comments"), "Comments", maximum=6000)
    with db_connection(db_path) as connection:
        connection.execute("BEGIN IMMEDIATE")
        session = _session(connection, session_id)
        if session["stage"] != "poststudy":
            raise StudyStateError("Final feedback is already locked or not yet available.")
        connection.execute(
            "INSERT INTO poststudy_responses(session_id,checklist_new_considerations,"
            "technical_fact_understanding,method_recognition,comments,created_at) "
            "VALUES(?,?,?,?,?,?)",
            (session_id, new_considerations, understanding, recognition, comments, utc_now()),
        )
        connection.execute(
            "UPDATE sessions SET stage='complete',completed_at=? WHERE id=?",
            (utc_now(), session_id),
        )
        _event(connection, session_id, "study_completed", {"final_feedback_complete": True})
    return get_state(db_path, config, session_id)


def withdraw_session(db_path: str | Path, session_id: str) -> dict[str, Any]:
    with db_connection(db_path) as connection:
        connection.execute("BEGIN IMMEDIATE")
        session = _session(connection, session_id)
        if session["stage"] == "complete":
            raise StudyStateError(
                "This pseudonymous session is complete; follow the frozen ethics protocol."
            )
        connection.execute("DELETE FROM sessions WHERE id=?", (session_id,))
        connection.execute(
            "UPDATE withdrawal_metrics SET withdrawn_sessions=withdrawn_sessions+1,updated_at=? "
            "WHERE id=1", (utc_now(),),
        )
    return {"withdrawn": True, "data_erased": True}


def admin_summary(db_path: str | Path, config: dict[str, Any]) -> dict[str, Any]:
    with db_connection(db_path) as connection:
        counts = [dict(row) for row in connection.execute(
            "SELECT panel_slot,module_id,stage,COUNT(*) AS count FROM sessions "
            "GROUP BY panel_slot,module_id,stage ORDER BY panel_slot"
        ).fetchall()]
        withdrawn = connection.execute(
            "SELECT withdrawn_sessions FROM withdrawal_metrics WHERE id=1"
        ).fetchone()["withdrawn_sessions"]
        roster_progress = [dict(row) for row in connection.execute(
            "SELECT panel_slot,module_id,stage,created_at,completed_at FROM sessions ORDER BY panel_slot"
        ).fetchall()]
        pre_theory_rows = [dict(row) for row in connection.execute(
            "SELECT module_id,condition_id,AVG(revised_answers_legal_question) AS legal_question_mean,"
            "AVG(revised_enables_legal_objective) AS legal_objective_mean,COUNT(DISTINCT session_id) AS participants "
            "FROM ranking_responses GROUP BY module_id,condition_id ORDER BY module_id,condition_id"
        ).fetchall()]
        checklist_rows = [dict(row) for row in connection.execute(
            "SELECT module_id,condition_id,AVG(score) AS checklist_mean,COUNT(DISTINCT session_id) AS participants "
            "FROM checklist_responses GROUP BY module_id,condition_id ORDER BY module_id,condition_id"
        ).fetchall()]
        consideration_rows = [dict(row) for row in connection.execute(
            "SELECT checklist_new_considerations AS answer,COUNT(*) AS count FROM poststudy_responses "
            "GROUP BY checklist_new_considerations"
        ).fetchall()]
    modules = [
        {
            "id": module_id,
            "label": module["label"],
            "research_label": module.get("research_label"),
            "study_type": module.get("study_type"),
            "recruitment_enabled": bool(module.get("recruitment_enabled")),
            "comparison_enabled": bool(module.get("comparison_enabled", True)),
            "matched_predictions": module.get("matched_predictions", []),
            "provision_label": module["provision_label"],
            "authority_links": module.get("provision", {}).get("authority_links", []),
            "gate_policy": module["gate_policy"],
            "sensitivity_gate_policy": module.get("sensitivity_gate_policy", {}),
            "rank_basis": module.get("rank_basis", "gated_weighted"),
            "framework_scoring": module.get("framework_scoring"),
            "shap_variant_comparison": module.get("shap_variant_comparison", []),
            "confirmatory_contrasts": module.get("confirmatory_contrasts", []),
            "evidence_guide": module.get("evidence_guide", {}),
            "conditions": [hidden_debug_record(module, item) for item in module["conditions"]],
        }
        for module_id, module in config["modules"].items()
    ]
    pre_lookup = {(row["module_id"], row["condition_id"]): row for row in pre_theory_rows}
    checklist_lookup = {(row["module_id"], row["condition_id"]): row for row in checklist_rows}
    theory_modules = []
    for module_id, module in config["modules"].items():
        rows = []
        for condition in module["conditions"]:
            pre = pre_lookup.get((module_id, condition["id"]), {})
            guided = checklist_lookup.get((module_id, condition["id"]), {})
            rows.append({
                "condition_id": condition["id"],
                "method_identity": condition.get("method_identity", condition["id"]),
                "pre_legal_question_mean": pre.get("legal_question_mean"),
                "pre_legal_objective_mean": pre.get("legal_objective_mean"),
                "theory_checklist_mean": guided.get("checklist_mean"),
                "pre_participants": pre.get("participants", 0),
                "checklist_participants": guided.get("participants", 0),
            })
        theory_modules.append({"id": module_id, "label": module["label"], "rows": rows})
    consideration_counts = {row["answer"]: row["count"] for row in consideration_rows}

    return {
        "method_catalogue": config.get("method_catalogue", []),
        "study": {
            "id": config["study_id"],
            "version": config["version"],
            "config_hash": config_hash(config),
            "database_file": Path(db_path).name,
            "ready_for_collection": config.get("ready_for_collection", False),
            "technical_signoff": config.get("technical_signoff", {}),
            "legal_signoff": config.get("legal_signoff", {}),
            "ethics": config.get("ethics", {}),
            "preregistration": config.get("preregistration", {}),
            "pilot": config.get("pilot", {}),
            "panel": {key: value for key, value in config.get("panel", {}).items() if key != "roster"},
            "acceptance_test": config.get("acceptance_test", {}),
        },
        "session_counts": counts,
        "roster_progress": roster_progress,
        "withdrawn_sessions": withdrawn,
        "theory_comparison": {
            "note": "The pre-theory columns use the locked scores from the explanation re-ranking completed before the theory-guided checklist. There is no separate non-theory checklist. The 1 to 7 assessment scores and the 1 to 4 checklist scale measure different constructs and should be read side by side rather than subtracted as a same-scale change score.",
            "modules": theory_modules,
            "new_considerations": {
                "yes": consideration_counts.get("yes", 0),
                "no": consideration_counts.get("no", 0),
            },
        },
        "modules": modules,
    }


def export_tables(db_path: str | Path) -> dict[str, list[dict[str, Any]]]:
    tables = [
        "sessions", "orientation_responses", "assignments", "trial_responses",
        "ranking_responses", "checklist_responses", "poststudy_responses",
        "withdrawal_metrics", "events",
    ]
    with db_connection(db_path) as connection:
        return {
            table: [dict(row) for row in connection.execute(f"SELECT * FROM {table}").fetchall()]
            for table in tables
        }
