#!/usr/bin/env python3
"""Create the live study manifest after every external launch gate is complete."""
from __future__ import annotations
import argparse, datetime as dt, json
from pathlib import Path
from study_core import config_hash, load_config, validate_config

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--config',default=str(ROOT/'config/study.json'))
parser.add_argument('--out',default=str(ROOT/'study-manifest.json'))
args=parser.parse_args()
config=load_config(args.config)
validate_config(config,live=True)
manifest={
    'study_id':config['study_id'],
    'version':config['version'],
    'config_sha256':config_hash(config),
    'frozen_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
}
Path(args.out).write_text(json.dumps(manifest,indent=2)+"\n",encoding='utf-8')
print(Path(args.out).resolve())
