(function () {
  "use strict";

  function canonical(value) {
    if (Array.isArray(value)) return value.map(canonical);
    if (value && typeof value === "object") {
      return Object.keys(value).sort().reduce(function (result, key) {
        result[key] = canonical(value[key]);
        return result;
      }, {});
    }
    return value;
  }

  async function sha256(value) {
    var bytes = new TextEncoder().encode(JSON.stringify(canonical(value)));
    var digest = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(digest)).map(function (item) { return item.toString(16).padStart(2, "0"); }).join("");
  }

  function clone(value) { return JSON.parse(JSON.stringify(value)); }

  function resolveModules(rawModules) {
    var resolved = {};
    function resolve(id, stack) {
      if (resolved[id]) return clone(resolved[id]);
      if ((stack || []).indexOf(id) >= 0) throw new Error("Cyclic module inheritance.");
      var current = clone(rawModules[id]);
      var parentId = current.extends;
      delete current.extends;
      if (parentId) current = Object.assign(resolve(parentId, (stack || []).concat([id])), current);
      resolved[id] = current;
      return clone(current);
    }
    Object.keys(rawModules).forEach(function (id) { resolve(id, []); });
    return resolved;
  }

  function threshold(value) {
    return value && typeof value === "object" ? Number(value.threshold) : Number(value);
  }



  function gateRecord(module, condition) {
    var checks = Object.keys(module.gate_policy).map(function (property) {
      var score = condition.property_scores[property];
      var minimum = threshold(module.gate_policy[property]);
      return { property: property, score: score, threshold: minimum, passed: score >= minimum };
    });
    var weightedTotal = 0;
    var weightTotal = 0;
    var normalized = [];
    Object.keys(module.requirement_weights).forEach(function (property) {
      var value = Number(condition.property_scores[property]) / 5;
      var rawWeight = module.requirement_weights[property];
      var weight = Number(rawWeight && typeof rawWeight === "object" ? rawWeight.weight : rawWeight);
      normalized.push(value);
      weightedTotal += value * weight;
      weightTotal += weight;
    });
    var fit = condition.procedural_fit || {};
    return {
      id: condition.id,
      method_identity: condition.method_identity,
      framework_rank: condition.framework_rank == null ? null : Number(condition.framework_rank),
      display_order: condition.display_order == null ? null : Number(condition.display_order),
      target_question_archetype: condition.target_question_archetype || null,
      target_question_text: condition.target_question_text || null,
      procedural_fit: typeof fit === "boolean" ? fit : Boolean(fit.question && fit.scope && fit.stage && fit.feasible),
      unweighted_alignment: normalized.reduce(function (sum, value) { return sum + value; }, 0) / normalized.length,
      weighted_alignment: weightedTotal / weightTotal,
      rank_basis: module.rank_basis || "gated_weighted",
      gate_pass: checks.every(function (item) { return item.passed; }),
      gate_checks: checks,
      property_scores: condition.property_scores,
      score_provenance: condition.score_provenance || {},
      score_sources: condition.score_sources || {},
      property_score_comments: condition.property_score_comments || {},
      assurance: condition.assurance,
      literature_score: condition.literature_score == null ? null : Number(condition.literature_score),
      literature_universe_rank: condition.literature_universe_rank == null ? null : Number(condition.literature_universe_rank),
      selection_tier: condition.selection_tier == null ? null : Number(condition.selection_tier),
      empirical_metrics: condition.empirical_metrics || {}
    };
  }

  var application = Vue.createApp({
    data: function () {
      return {
        loading: true,
        isMock: new URLSearchParams(window.location.search).get("mock") === "1",
        needsToken: false,
        token: "",
        error: "",
        summary: null,
        selectedModuleId: "credit_authority",
        selectedConditionId: "",
        selectedCatalogueName: "MechaRule",
        exporting: false,
        downloadMessage: ""
      };
    },
    computed: {
      catalogueProfile: function () {
        var entries = (this.summary && this.summary.method_catalogue) || [];
        return entries.find(item => item.name === this.selectedCatalogueName) || entries[0] || null;
      },
      shortHash: function () {
        return this.summary ? this.summary.study.config_hash.slice(0, 18) + "…" : "";
      },
      totalSessions: function () {
        return this.summary ? (this.summary.roster_progress || []).length : 0;
      },
      completedSessions: function () {
        return this.summary ? (this.summary.roster_progress || []).filter(function (item) { return Boolean(item.completed_at); }).length : 0;
      },
      inProgressSessions: function () {
        return Math.max(0, this.totalSessions - this.completedSessions);
      },
      selectedModule: function () {
        if (!this.summary) return null;
        var id = this.selectedModuleId;
        return this.summary.modules.find(function (item) { return item.id === id; }) || this.summary.modules[0];
      },
      selectedTheoryModule: function () {
        if (!this.summary || !this.summary.theory_comparison) return null;
        var modules = this.summary.theory_comparison.modules || [];
        var id = this.selectedModuleId;
        return modules.find(function (item) { return item.id === id; }) || modules[0] || null;
      },
      sortedConditions: function () {
        return this.selectedModule ? this.selectedModule.conditions.slice().sort(function (a, b) {
          var left = a.framework_rank == null ? (a.display_order == null ? 999 : a.display_order) : a.framework_rank;
          var right = b.framework_rank == null ? (b.display_order == null ? 999 : b.display_order) : b.framework_rank;
          return left - right;
        }) : [];
      },
      selectedCondition: function () {
        if (!this.selectedModule) return null;
        var id = this.selectedConditionId;
        return this.selectedModule.conditions.find(function (item) { return item.id === id; }) || this.sortedConditions[0];
      },
      failedChecks: function () {
        return this.selectedCondition ? this.selectedCondition.gate_checks.filter(function (item) { return !item.passed; }) : [];
      },
      selectedHasGate: function () {
        return Boolean(this.selectedModule && Object.keys(this.selectedModule.gate_policy || {}).length);
      }
    },
    methods: {
      pretty: function (value) {
        return String(value).replace(/_/g, " ").replace(/\b\w/g, function (letter) { return letter.toUpperCase(); });
      },
      threshold: threshold,
      moduleLabel: function (id) {
        if (!id || !this.summary) return " - ";
        var module = this.summary.modules.find(function (item) { return item.id === id; });
        return module ? module.label : id;
      },
      stageLabel: function (stage) {
        var labels = {
          orientation: "Legal brief",
          trials: "Primary judgments",
          intermission: "Midpoint break",
          ranking: "Blinded comparisons",
          checklist: "Secondary checklists",
          poststudy: "Instrument checks",
          complete: "Complete"
        };
        return labels[stage] || this.pretty(stage || "In progress");
      },
      formatMean: function (value) {
        if (value == null || value === "") return "No data";
        var number = Number(value);
        return Number.isFinite(number) ? number.toFixed(2) : "No data";
      },
      formatDate: function (value) {
        if (!value) return " - ";
        var date = new Date(value);
        if (Number.isNaN(date.getTime())) return value;
        return new Intl.DateTimeFormat(undefined, { year: "numeric", month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit" }).format(date);
      },
      downloadExport: async function () {
        if (this.isMock || this.exporting) return;
        this.exporting = true;
        this.downloadMessage = "";
        try {
          var response = await fetch("/api/admin/export.zip", { headers: { "X-Admin-Token": this.token } });
          if (!response.ok) {
            var message = "Could not export results.";
            try { var body = await response.json(); message = body.error || message; } catch (_error) {}
            throw new Error(message);
          }
          var blob = await response.blob();
          var url = URL.createObjectURL(blob);
          var link = document.createElement("a");
          link.href = url;
          link.download = (this.summary.study.id || "legal-xai") + "-export.zip";
          document.body.appendChild(link);
          link.click();
          link.remove();
          URL.revokeObjectURL(url);
          this.downloadMessage = "Export downloaded.";
        } catch (error) {
          this.downloadMessage = error.message;
        } finally {
          this.exporting = false;
        }
      },
      selectModule: function (id) {
        this.selectedModuleId = id;
        var module = this.summary.modules.find(function (item) { return item.id === id; });
        this.selectedConditionId = module.conditions.slice().sort(function (a, b) {
          var left = a.framework_rank == null ? (a.display_order == null ? 999 : a.display_order) : a.framework_rank;
          var right = b.framework_rank == null ? (b.display_order == null ? 999 : b.display_order) : b.framework_rank;
          return left - right;
        })[0].id;
      },
      loadProtected: async function () {
        this.error = "";
        try {
          var result = await fetch("/api/admin/debug", { headers: { "X-Admin-Token": this.token } });
          var body = await result.json();
          if (!result.ok) throw new Error(body.error || "Researcher access failed.");
          this.summary = body;
          this.needsToken = false;
          this.selectModule(this.summary.modules[0].id);
        } catch (error) {
          this.error = error.message;
        }
      },
      initialize: async function () {
        try {
          if (!this.isMock) {
            this.needsToken = true;
            return;
          }
          var configUrl = "/config/study.json";
          var response = await fetch(configUrl);
          if (!response.ok) throw new Error("Could not load the local demo configuration.");
          var config = await response.json();
          config.modules = resolveModules(config.modules);
          var hash = await sha256(config);
          this.summary = {
            study: {
              id: config.study_id,
              version: config.version,
              config_hash: hash,
              database_file: "study.sqlite3 (mock view)",
              ready_for_collection: config.ready_for_collection,
              technical_signoff: config.technical_signoff,
              legal_signoff: config.legal_signoff,
              ethics: config.ethics,
              preregistration: config.preregistration,
              pilot: config.pilot,
              panel: config.panel,
              small_n_analysis: config.small_n_analysis,
              acceptance_test: config.acceptance_test
            },
            method_catalogue: config.method_catalogue || [],
            session_counts: [],
            roster_progress: [],
            withdrawn_sessions: 0,
            theory_comparison: {
              note: "The pre-theory columns use the locked scores from the explanation re-ranking completed before the theory-guided checklist. There is no separate non-theory checklist. The 1 to 7 assessment scores and the 1 to 4 checklist scale measure different constructs and should be read side by side rather than subtracted as a same-scale change score.",
              new_considerations: { yes: 0, no: 0 },
              modules: Object.keys(config.modules).map(function (id) {
                var module = config.modules[id];
                return {
                  id: id,
                  label: module.label,
                  rows: module.conditions.map(function (condition) {
                    return {
                      condition_id: condition.id,
                      method_identity: condition.method_identity,
                      pre_legal_question_mean: null,
                      pre_legal_objective_mean: null,
                      theory_checklist_mean: null,
                      pre_participants: 0,
                      checklist_participants: 0
                    };
                  })
                };
              })
            },
            modules: Object.keys(config.modules).map(function (id) {
              var module = config.modules[id];
              return {
                id: id,
                label: module.label,
                provision_label: module.provision_label,
                authority_links: (module.provision && module.provision.authority_links) || [],
                study_type: module.study_type,
                recruitment_enabled: module.recruitment_enabled,
                comparison_enabled: Boolean(module.comparison_enabled),
                matched_predictions: module.matched_predictions || [],
                rank_basis: module.rank_basis || "gated_weighted",
                framework_scoring: module.framework_scoring || null,
                shap_variant_comparison: module.shap_variant_comparison || [],
                evidence_guide: module.evidence_guide || {},
                gate_policy: module.gate_policy,
                sensitivity_gate_policy: module.sensitivity_gate_policy || {},
                confirmatory_contrasts: module.confirmatory_contrasts,
                conditions: module.conditions.map(function (condition) { return gateRecord(module, condition); })
              };
            })
          };
          this.selectedModuleId = new URLSearchParams(window.location.search).get("module") || this.summary.modules[0].id;
          this.selectModule(this.selectedModuleId);
          var conditionId = new URLSearchParams(window.location.search).get("condition");
          if (conditionId && this.selectedModule.conditions.some(function (item) { return item.id === conditionId; })) this.selectedConditionId = conditionId;
        } catch (error) {
          this.error = error.message;
        } finally {
          this.loading = false;
        }
      }
    },
    mounted: function () { this.initialize(); }
  });
  application.mount("#admin");
}());
