(function () {
  "use strict";

  var scaleQuestion = {
    props: {
      modelValue: { default: null },
      label: { type: String, required: true },
      max: { type: Number, default: 7 },
      lowLabel: { type: String, default: "Low / not adequate" },
      highLabel: { type: String, default: "High / fully adequate" }
    },
    emits: ["update:modelValue"],
    computed: {
      options: function () {
        return Array.from({ length: this.max }, function (_, index) { return index + 1; });
      }
    },
    template: "<div class='question-block'><label class='question-label'>{{ label }}</label><div class='scale-control' :class='max === 5 ? \"five-scale\" : \"\"'><button v-for='option in options' :key='option' type='button' :aria-pressed='Number(modelValue) === option' :class='{selected: Number(modelValue) === option}' @click='$emit(\"update:modelValue\", option)'>{{ option }}</button></div><div class='scale-anchors'><span>{{ lowLabel }}</span><span>{{ highLabel }}</span></div></div>"
  };


  var xaiOutputCard = {
    props: {
      output: { type: Object, required: true },
      compact: { type: Boolean, default: false }
    },
    methods: {
      gaugePosition: function (value) {
        var max = Number(this.output.scale_max || 25);
        var n = Number(value);
        if (!Number.isFinite(n) || !Number.isFinite(max) || max <= 0) return 0;
        return Math.max(0, Math.min(100, (n / max) * 100));
      },
      ruleImportanceWidth: function (value, items) {
        var vals = (items || []).map(function (item) { return Math.abs(Number(item.importance) || 0); });
        var max = Math.max.apply(Math, vals.concat([1e-9]));
        return Math.max(4, Math.min(100, (Math.abs(Number(value) || 0) / max) * 100));
      },
      contributionWidth: function (value) {
        var n = Math.abs(Number(value) || 0);
        var values = (this.output.items || []).map(function (item) { return Math.abs(Number(item.contribution) || 0); });
        var max = Math.max.apply(Math, values.concat([1]));
        return Math.max(8, Math.min(100, (n / max) * 100));
      },
      signedWidth: function (value) {
        var n = Math.abs(Number(value) || 0);
        var values = (this.output.items || []).map(function (item) { return Math.abs(Number(item.contribution) || 0); });
        var max = Math.max.apply(Math, values.concat([1]));
        return Math.max(4, Math.min(48, (n / max) * 48));
      },
      signedLeft: function (value) {
        return Number(value) < 0 ? (50 - this.signedWidth(value)) : 50;
      },
      dotImpact: function (point) {
        if (point && typeof point === 'object') return Number(point.impact) || 0;
        return Number(point) || 0;
      },
      dotTone: function (point) {
        if (point && typeof point === 'object' && Number.isFinite(Number(point.tone))) return Math.max(0, Math.min(4, Number(point.tone)));
        return 2;
      },
      dotLeft: function (point) {
        var n = this.dotImpact(point);
        return Math.max(2, Math.min(98, 50 + n * 44));
      },
      curvePoints: function (series) {
        var values = series.y || [];
        var min = Number(this.output.y_min);
        var max = Number(this.output.y_max);
        if (!Number.isFinite(min)) min = Math.min.apply(Math, values);
        if (!Number.isFinite(max)) max = Math.max.apply(Math, values);
        if (max <= min) max = min + 1;
        return values.map(function (y, index) {
          var x = values.length <= 1 ? 120 : 14 + (212 * index / (values.length - 1));
          var yy = 102 - ((Number(y) - min) / (max - min)) * 82;
          return x.toFixed(1) + ',' + yy.toFixed(1);
        }).join(' ');
      },
      curveCx: function (series, index) {
        var values = series.y || [];
        return values.length <= 1 ? 120 : 14 + (212 * index / (values.length - 1));
      },
      curveCy: function (series, index) {
        var values = series.y || [];
        var min = Number(this.output.y_min);
        var max = Number(this.output.y_max);
        if (!Number.isFinite(min)) min = Math.min.apply(Math, values);
        if (!Number.isFinite(max)) max = Math.max.apply(Math, values);
        if (max <= min) max = min + 1;
        return 102 - ((Number(values[index]) - min) / (max - min)) * 82;
      },
      thresholdY: function () {
        var min = Number(this.output.y_min), max = Number(this.output.y_max), t = Number(this.output.threshold);
        if (!Number.isFinite(min) || !Number.isFinite(max) || !Number.isFinite(t) || max <= min) return null;
        return 102 - ((t - min) / (max - min)) * 82;
      },
      readingHint: function () {
        switch (this.output.kind) {
          case 'local_contributions':
            return 'Read the starting estimate, refusal cutoff and final estimate together. Longer bars show larger changes in the estimate.';
          case 'attribution_summary':
            return 'Dots to the left tend to lower the score; dots to the right tend to raise it. Colour shows relatively lower or higher measurement values.';
          case 'partial_dependence':
            return 'Each chart changes one measurement or characteristic at a time. The highlighted point marks the recorded value.';
          case 'rule_tree':
            return 'Start at the first split and follow the branch matching the recorded measurement value until you reach a final box.';
          case 'rule_importance':
            return 'The ranked cards run from the strongest pattern to the weakest pattern in this summary.';
          case 'contrastive':
            return 'Part 1 shows what is enough to keep the current result. Part 2 shows the changes that switch the result.';
          case 'counterfactuals':
            return 'Each card changes only the listed values and then reruns the same model on the same case.';
          default:
            return '';
        }
      },
      ruleParts: function (label) {
        return String(label || '').split(/\s+and\s+/i).filter(Boolean);
      },
      rankFill: function (rank, items) {
        var total = Math.max(1, (items || []).length || 1);
        var pos = total - Number(rank) + 1;
        return Math.max(18, Math.min(100, (pos / total) * 100));
      },
      rankDescriptor: function (rank) {
        var n = Number(rank);
        if (n === 1) return 'Strongest pattern';
        if (n === 2) return 'Second strongest';
        if (n === 3) return 'Third strongest';
        return 'Rank #' + n;
      },
      explanationContextLead: function () {
        var scope = String(this.output.scope_label || '').toLowerCase();
        if (scope.indexOf('reference patients') >= 0) {
          return "This explanation describes the software’s general behaviour across reference patients and helps answer the following question:";
        }
        return 'This explanation helps answer the following question:';
      },
      isMainTakeaway: function (line) {
        return /^main takeaway\s*:/i.test(String(line || ''));
      },
      takeawayBody: function (line) {
        return String(line || '').replace(/^main takeaway\s*:\s*/i, '');
      },
      treeOutcomeClass: function (label) {
        var value = String(label || '').toLowerCase();
        if (value.indexOf('higher') >= 0) return 'outcome-high';
        if (value.indexOf('lower') >= 0) return 'outcome-low';
        return 'outcome-mid';
      }
    },
    template: `
      <section class="xai-artifact" :class="['xai-kind-' + output.kind, {'xai-artifact-compact': compact}]">
        <header class="xai-artifact-header xai-question-header">
          <div>
            <p class="xai-context-lead">{{ explanationContextLead() }}</p>
            <h3 v-if="output.question" class="xai-question-lead">{{ output.question }}</h3>
          </div>
          <div v-if="output.score_display && output.kind !== 'local_contributions'" class="xai-score-badge">
            <small>{{ output.score_label || 'Model score' }}</small>
            <strong>{{ output.score_display }}</strong>
          </div>
          <div v-else-if="output.score && output.kind === 'local_surrogate'" class="xai-score-badge">
            <small>Model score</small><strong>{{ output.score }}</strong>
          </div>
        </header>

        <div v-if="output.text_representation && output.text_representation.length" class="xai-text-intro" aria-label="Explanation summary">
          <p class="xai-text-takeaway"><template v-if="isMainTakeaway(output.text_representation[0])"><strong>Main takeaway:</strong> {{ takeawayBody(output.text_representation[0]) }}</template><template v-else>{{ output.text_representation[0] }}</template></p>
          <ul v-if="output.text_representation.length > 1" class="xai-summary-details" aria-label="Explanation details"><li v-for="(line, ti) in output.text_representation.slice(1)" :key="ti">{{ line }}</li></ul>
          <p v-if="readingHint()" class="xai-reading-hint"><strong>How to read it:</strong> {{ readingHint() }}</p>
          <p class="xai-visual-scope-note"><strong>Assessment note:</strong> the visual below is another representation of the same explanation content. Judge the information conveyed, not the visual design.</p>
        </div>

        <div v-if="output.score_display && output.scale_max && output.kind !== 'local_contributions'" class="xai-score-scale" aria-label="Model score scale">
          <div class="xai-score-track">
            <span class="xai-score-fill" :style="{width: gaugePosition(output.score) + '%'}"></span>
            <span v-if="output.baseline !== undefined && output.baseline !== null" class="xai-baseline-marker" :style="{left: gaugePosition(output.baseline) + '%'}"><i></i><em>{{ output.baseline_display }}</em></span>
            <span v-if="output.threshold !== undefined && output.threshold !== null" class="xai-threshold-marker" :style="{left: gaugePosition(output.threshold) + '%'}"><i></i><em>{{ output.threshold_display }}</em></span>
            <span class="xai-score-marker" :style="{left: gaugePosition(output.score) + '%'}"><i></i><em>{{ output.score_display }}</em></span>
          </div>
          <div class="xai-scale-labels">
            <span v-if="output.baseline_label"><strong>{{ output.baseline_label }}</strong> {{ output.baseline_display }}</span>
            <span v-if="output.threshold_label"><strong>{{ output.threshold_label }}</strong> {{ output.threshold_display }}</span>
          </div>
        </div>

        <div v-if="output.kind === 'local_contributions'" class="xai-local-contribution-explanation" aria-label="Decision-specific contribution explanation">
          <div class="xai-credit-summary" aria-label="Credit-risk estimate, cutoff and result">
            <span><small>Starting estimate from comparison applications</small><strong>{{ output.baseline_display }}</strong></span>
            <i aria-hidden="true">→</i>
            <span><small>Final estimate for this application</small><strong>{{ output.score_display }}</strong></span>
            <span><small>Bank refusal cutoff</small><strong>{{ output.threshold_display }}</strong></span>
            <b>{{ output.outcome_label }}</b>
          </div>
          <div class="xai-contribution-chart">
            <div v-for="item in output.items" :key="item.label" class="xai-contribution-row">
              <div class="xai-contribution-name"><strong>{{ item.label }}</strong><span v-if="item.case_value">Applicant characteristic: {{ item.case_value }}</span></div>
              <div class="xai-contribution-plot" :aria-label="item.label + ' contribution ' + item.value_display"><span class="xai-contribution-bar" :class="Number(item.contribution) < 0 ? 'negative' : 'positive'" :style="{width: contributionWidth(item.contribution) + '%'}"></span></div>
              <strong class="xai-contribution-value"><span>{{ item.value_short || item.value_display }}</span><small v-if="item.value_unit">{{ item.value_unit }}</small></strong>
            </div>
          </div>
        </div>

        <div v-else-if="output.kind === 'attribution_summary'" class="xai-summary-chart" aria-label="Across-patient influence summary">
          <div class="xai-summary-axis"><span>tends to lower diabetes risk score</span><i></i><span>tends to raise diabetes risk score</span></div>
          <div v-for="item in output.items" :key="item.label" class="xai-summary-row">
            <div class="xai-summary-label"><strong>{{ item.label }}</strong><span v-if="item.summary_label" class="xai-summary-rank">{{ item.summary_label }}</span><span>{{ item.mean_abs }}</span></div>
            <div class="xai-dot-strip"><i class="xai-zero-line"></i><b v-for="(point, pi) in item.points" :key="pi" :class="'tone-' + dotTone(point)" :style="{left: dotLeft(point) + '%'}"></b></div>
          </div>
          <div v-if="output.value_legend" class="xai-value-legend"><span>{{ output.value_legend }}:</span><i class="low"></i><small>lower</small><span class="gradient"></span><small>higher</small><i class="high"></i></div>
        </div>

        <div v-else-if="output.kind === 'partial_dependence'" class="xai-curve-grid" aria-label="Average response curves">
          <div v-if="output.y_axis_label" class="xai-curve-measure"><strong>Vertical axis: {{ output.y_axis_label }}</strong><span v-if="output.y_min !== undefined && output.y_max !== undefined">Displayed range: {{ output.y_min }} to {{ output.y_max }}</span></div>
          <article v-for="series in output.series" :key="series.label" class="xai-curve-card">
            <div class="xai-curve-heading"><strong>{{ series.label }}</strong><span v-if="series.current_label">{{ series.current_label }}</span></div>
            <div v-if="series.trend_label" class="xai-curve-trend">{{ series.trend_label }}</div>
            <div class="xai-curve-plot-wrap">
              <div class="xai-curve-y-range" aria-hidden="true"><span>{{ output.y_max }}{{ output.y_axis_suffix || '' }}</span><span>{{ output.y_min }}{{ output.y_axis_suffix || '' }}</span></div>
              <svg viewBox="0 0 240 118" role="img" :aria-label="series.label + ' model response curve'">
                <line x1="14" y1="102" x2="226" y2="102" class="curve-axis"></line>
                <line x1="14" y1="18" x2="14" y2="102" class="curve-axis"></line>
                <line v-if="thresholdY() !== null" x1="14" :y1="thresholdY()" x2="226" :y2="thresholdY()" class="curve-threshold"></line>
                <polyline :points="curvePoints(series)" class="curve-line"></polyline>
                <circle v-for="(v, index) in series.y" :key="index" :cx="curveCx(series,index)" :cy="curveCy(series,index)" r="2.8" class="curve-point"></circle>
                <circle v-if="series.current_index !== undefined" :cx="curveCx(series,series.current_index)" :cy="curveCy(series,series.current_index)" r="5" class="curve-current"></circle>
              </svg>
            </div>
            <div class="xai-curve-x"><span>{{ series.x[0] }} {{ series.unit }}</span><span>{{ series.x[series.x.length-1] }} {{ series.unit }}</span></div>
            <div v-if="series.current_index !== undefined" class="xai-curve-current-note"><span>Recorded value</span><strong>{{ series.x[series.current_index] }} {{ series.unit }} → average estimate {{ series.y[series.current_index] }}%</strong></div>
          </article>
          <div v-if="output.threshold_display" class="curve-legend"><i></i><span>{{ output.threshold_display }}</span></div>
        </div>

        <div v-else-if="output.kind === 'rule_tree'" class="xai-rule-tree-diagram" aria-label="Decision-tree explanation">
          <div v-if="output.levels && output.levels.length >= 3" class="xai-tree-graphic">
            <div class="xai-tree-root-wrap">
              <div class="xai-tree-node xai-tree-root"><strong>{{ output.levels[0][0].label }}</strong></div>
            </div>
            <div class="xai-tree-parent-grid">
              <div v-for="(node, idx) in output.levels[1]" :key="node.id" class="xai-tree-parent-col">
                <div class="xai-tree-branch-chip">{{ node.branch }}</div>
                <div class="xai-tree-node xai-tree-split"><strong>{{ node.label }}</strong></div>
                <div class="xai-tree-children-grid">
                  <div v-for="leaf in output.levels[2].slice(idx * 2, idx * 2 + 2)" :key="leaf.id" class="xai-tree-child-col">
                    <div class="xai-tree-branch-chip child-branch">{{ leaf.branch }}</div>
                    <div class="xai-tree-node xai-tree-leaf" :class="treeOutcomeClass(leaf.label)"><strong>{{ leaf.label }}</strong></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div v-else class="xai-rule-map">
            <div v-for="(level, li) in output.levels" :key="li" class="xai-rule-level" :class="'rule-level-' + li">
              <div v-for="node in level" :key="node.id" class="xai-rule-node" :class="{'active': node.active, 'result': node.result, 'has-branch': node.branch}">
                <span v-if="node.branch" class="xai-rule-branch">{{ node.branch }}</span><strong>{{ node.label }}</strong>
              </div>
            </div>
          </div>
          <div v-if="output.patient_path" class="xai-path-callout"><span>Current patient path</span><strong>{{ output.patient_path }}</strong></div>
        </div>

        <div v-else-if="output.kind === 'local_surrogate'" class="xai-local-surrogate" aria-label="Local contribution summary">
          <div class="local-surrogate-axis"><span>pushes lower</span><i></i><span>pushes higher</span></div>
          <div v-for="item in output.items" :key="item.label" class="local-surrogate-row">
            <strong>{{ item.label }}</strong>
            <div class="local-surrogate-track"><i></i><span :class="Number(item.contribution) < 0 ? 'negative' : 'positive'" :style="{left: signedLeft(item.contribution) + '%', width: signedWidth(item.contribution) + '%'}"></span></div>
            <b>{{ item.value_display }}</b>
          </div>
        </div>

        <div v-else-if="output.kind === 'rule_importance'" class="xai-rule-importance" aria-label="Ranked measurement-pattern summary">
          <article v-for="item in output.items" :key="item.label" class="rule-importance-card">
            <div class="rule-card-topline">
              <span class="rule-rank-badge">#{{ item.rank }}</span>
              <span class="rule-rank-text">{{ rankDescriptor(item.rank) }}</span>
              <strong class="rule-direction" :class="item.direction === 'lower' ? 'negative' : 'positive'">{{ item.direction_label }}</strong>
            </div>
            <div class="rule-rank-meter" aria-hidden="true"><span :style="{width: rankFill(item.rank, output.items) + '%'}"></span></div>
            <div class="rule-condition-list">
              <span v-for="(part, pi) in ruleParts(item.label)" :key="item.label + '-' + pi" class="rule-condition-chip">{{ part }}</span>
            </div>
            <div class="rule-card-footer">
              <strong>Pattern {{ item.rank }}</strong>
              <span>{{ item.direction === 'lower' ? 'Associated with lower diabetes risk scores' : 'Associated with higher diabetes risk scores' }}</span>
            </div>
          </article>
        </div>

        <div v-else-if="output.kind === 'contrastive'" class="xai-contrastive" aria-label="Two-part explanation of what keeps the refusal and what switches the result">
          <section v-if="output.support_items && output.support_items.length" class="contrast-support-panel">
            <div class="contrast-subheading"><span>Part 1 · what is enough to keep the refusal</span><strong>{{ output.support_title }}</strong></div>
            <div class="contrast-support-items"><div v-for="item in output.support_items" :key="item.label"><span>{{ item.label }}</span><strong>{{ item.value }}</strong></div></div>
            <p v-if="output.support_note">{{ output.support_note }}</p>
          </section>
          <section class="contrast-change-panel">
            <div v-if="output.support_items && output.support_items.length" class="contrast-subheading"><span>Part 2 · what switches the result to approval</span><strong>{{ output.alternative_title }}</strong></div>
            <div class="contrast-score-row"><div><span>{{ output.current_title }}</span><strong>{{ output.current_score }}</strong><small>{{ output.current_score_label || 'Model estimate' }}</small><small>{{ output.current_decision || 'Refused' }}</small></div><div class="contrast-arrow">→</div><div><span>{{ output.alternative_title }}</span><strong>{{ output.alternative_score }}</strong><small>{{ output.alternative_score_label || 'Model estimate' }}</small><small>{{ output.alternative_decision || 'Approved' }}</small></div></div>
            <div class="contrast-table"><div class="contrast-head"><span>Applicant characteristic</span><span>{{ output.current_column_label || 'Recorded value' }}</span><span>{{ output.alternative_column_label || 'Comparison value' }}</span></div><div v-for="row in output.rows" :key="row.label" class="contrast-row" :class="{'unchanged': row.unchanged}"><strong>{{ row.label }}</strong><span>{{ row.current }}</span><span>{{ row.alternative }}</span></div></div>
          </section>
        </div>

        <div v-else-if="output.kind === 'counterfactuals'" class="xai-counterfactual-grid" aria-label="Hypothetical versions of the submitted application">
          <div v-if="output.threshold" class="counterfactual-policy"><strong>Bank decision cutoff</strong><span>{{ output.threshold }} or higher: refused · below {{ output.threshold }}: approved</span></div>
          <div class="counterfactual-origin">
            <div class="counterfactual-origin-copy"><span>{{ output.current_title || 'Application as submitted' }}</span></div>
            <div class="counterfactual-origin-score"><small>{{ output.current_score_label || 'Model credit-risk estimate' }}</small><strong>{{ output.current_score }}</strong><span>{{ output.current_decision }}</span></div>
          </div>
          <article v-for="item in output.items" :key="item.title" class="counterfactual-card">
            <div class="counterfactual-head"><span>{{ item.title }}</span><small>{{ item.score_label || 'Model credit-risk estimate after these changes' }}</small><strong>{{ item.score }}</strong><small class="counterfactual-outcome">{{ item.decision_label }}</small></div>
            <div v-for="change in item.changes" :key="change.label" class="counterfactual-change">
              <strong>{{ change.label }}</strong>
              <div class="counterfactual-values" :aria-label="change.label + ': from ' + change.from + ' to ' + change.to">
                <span class="counterfactual-from">{{ change.from }}</span><i aria-hidden="true">→</i><b>{{ change.to }}</b>
              </div>
            </div>
          </article>
        </div>

      </section>`
  };

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function resolveModules(rawModules) {
    var resolved = {};
    function resolve(id, stack) {
      if (resolved[id]) return clone(resolved[id]);
      if ((stack || []).indexOf(id) >= 0) throw new Error("Cyclic module inheritance.");
      var current = clone(rawModules[id]);
      if (!current) throw new Error("Unknown module " + id);
      var parentId = current.extends;
      delete current.extends;
      if (parentId) current = Object.assign(resolve(parentId, (stack || []).concat([id])), current);
      resolved[id] = current;
      return clone(current);
    }
    Object.keys(rawModules).forEach(function (id) { resolve(id, []); });
    return resolved;
  }

  function replaceTokens(value, caseData) {
    if (typeof value === "string") {
      return value.replace(/\{\{\s*([A-Za-z0-9_]+)\s*\}\}/g, function (match, key) {
        return Object.prototype.hasOwnProperty.call(caseData, key) ? String(caseData[key]) : match;
      });
    }
    if (Array.isArray(value)) return value.map(function (item) { return replaceTokens(item, caseData); });
    if (value && typeof value === "object") {
      return Object.keys(value).reduce(function (result, key) {
        result[key] = replaceTokens(value[key], caseData);
        return result;
      }, {});
    }
    return value;
  }

  var assuranceTitles = {
    performance_context: "Faithfulness to the AI system",
    stability: "Stability across similar cases and repeated runs",
    configuration_sensitivity: "XAI model or hyperparameters perturbation robustness",
    limitations: "Detail and coverage",
    provenance: "Traceability / accountability",
    reference: "Independent reference comparison",
    near_equivalent: "Near-equivalent cases",
    strategic: "Targeted stress tests",
    repeated_runs: "Repeated runs",
    configuration_changes: "Reasonable configuration changes",
    presentation_load: "Presentation burden and detail",
    disclosure: "Information disclosure audit",
    reconstruction: "Reconstruction record",
    availability: "Availability"
  };

  function publicModule(module) {
    return {
      label: module.label,
      short_label: module.short_label,
      domain: module.domain,
      provision_label: module.provision_label,
      legal_question: module.legal_question,
      legal_objective: module.legal_objective,
      evidence_scale: clone(module.evidence_scale || {}),
      case_scope_note: module.case_scope_note || "",
      case_visual_kind: module.case_visual_kind || "",
      explanation_recipient: module.explanation_recipient || "Recipient",
      expert_memo_title: module.expert_memo_title || "Technical review of the explanation",
      expert_memo_visibility: module.expert_memo_visibility || "For the legal assessor only",
      expert_memo_button: module.expert_memo_button || "Open technical expert memo",
      show_checklist: Boolean(module.show_checklist),
      legal_brief: clone(module.legal_brief || {}),
      provision: clone(module.provision || {}),
      poststudy_checks: (module.poststudy_checks || []).map(function (item) {
        var safe = clone(item);
        delete safe.correct;
        return safe;
      })
    };
  }

  function mockCard(module, condition, blindLabel, caseData) {
    var renderedAssurance = replaceTokens(condition.assurance, caseData);
    var renderedMetrics = replaceTokens(condition.evidence_metrics || {}, caseData);
    return {
      blind_label: blindLabel,
      legal_question: module.legal_question || "",
      legal_objective: module.legal_objective || "",
      explanation: replaceTokens(condition.explanation, caseData),
      assurance: module.assurance_schema.map(function (key) {
        var guide = (module.evidence_guide || {})[key] || {};
        return {
          key: key,
          category: guide.category || "Other",
          title: assuranceTitles[key] || key,
          property: guide.property || "",
          heading: guide.heading || guide.tested || guide.property || assuranceTitles[key] || key,
          technical_term: guide.technical_term || guide.property || "",
          short_label: guide.short_label || guide.property || "",
          definition: guide.definition || "",
          example: guide.example || "",
          tested: guide.tested || "",
          protocol: guide.protocol || "",
          fact: renderedAssurance[key],
          metric: renderedMetrics[key] || {}
        };
      })
    };
  }

  function newTrialForm() {
    return {
      disposition: null,
      answers_legal_question: null,
      enables_legal_objective: null,
      confidence: null,
      rationale: "",
      additional_information: "",
      visual_appearance_influenced: null,
      visual_format_comments: ""
    };
  }

  var application = Vue.createApp({
    data: function () {
      return {
        loading: true,
        saving: false,
        withdrawing: false,
        fatalError: "",
        formError: "",
        withdrawalNotice: "",
        isMock: new URLSearchParams(window.location.search).get("mock") === "1",
        params: new URLSearchParams(window.location.search),
        publicConfig: {
          title: "Legal XAI Expert Validation",
          version: "",
          mode: "",
          participant_copy: {},
          participant_module_choice: false,
          contexts: []
        },
        rawConfig: null,
        state: null,
        orientation: null,
        orientationForm: { answers: {} },
        orientationResult: null,
        trial: null,
        comparison: null,
        checklist: null,
        activeComparisonLabel: "A",
        activeChecklistLabel: "A",
        comparisonResponses: {},
        comparisonRationale: "",
        comparisonRerankReason: "",
        reportModalOpen: false,
        rankingOrder: [],
        draggedRankLabel: null,
        checklistScores: {},
        trialStartedAt: Date.now(),
        startForm: {
          panel_code: "",
          module_id: "credit",
          experience_band: "",
          years_legal_experience: "",
          gdpr_familiarity: "",
          mdr_familiarity: "",
          age_confirmed: false,
          participation_consent: false,
          data_use_consent: false,
          role_acknowledged: false
        },
        trialForm: newTrialForm(),
        postForm: {
          checklist_new_considerations: null,
          technical_fact_understanding: null,
          method_recognition: "",
          comments: ""
        },
        dispositions: [
          { value: "sufficient", label: "Legally adequate as provided", help: "The explanation satisfies the stated standard." },
          { value: "minor-remediation", label: "Mostly adequate", help: "Minor clarification or correction is needed." },
          { value: "material-remediation", label: "Material gaps", help: "Substantial changes to the explanation are needed." },
          { value: "inadequate", label: "Legally inadequate", help: "The explanation does not satisfy the stated standard." },
          { value: "insufficient-information", label: "Not enough information to judge", help: "The record does not support a legal conclusion." }
        ],
        postConsiderationOptions: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" }
        ]
      };
    },
    computed: {
      canStart: function () {
        return Boolean(
          this.startForm.panel_code.trim().length >= 8 &&
          this.startForm.experience_band &&
          this.startForm.years_legal_experience !== "" &&
          this.startForm.gdpr_familiarity &&
          this.startForm.mdr_familiarity &&
          this.startForm.age_confirmed &&
          this.startForm.participation_consent &&
          this.startForm.data_use_consent &&
          this.startForm.role_acknowledged
        );
      },
      progressSteps: function () {
        return [
          { key: "briefs", label: "Legal briefs " + (this.state ? this.state.completed_orientations + "/2" : "") },
          { key: "judgments", label: "Primary judgments " + (this.state ? this.state.completed_trials + "/8" : "") },
          { key: "comparisons", label: "Explanation re-rankings " + (this.state ? this.state.completed_comparisons + "/" + this.state.total_comparisons : "") },
          { key: "checklists", label: "Theory-guided checklists " + (this.state ? this.state.completed_checklists + "/" + this.state.total_checklists : "") },
          { key: "poststudy", label: "Final feedback" }
        ];
      },
      trialComplete: function () {
        return Boolean(
          this.trialForm.disposition &&
          this.trialForm.answers_legal_question &&
          this.trialForm.enables_legal_objective &&
          this.trialForm.confidence &&
          this.trialForm.rationale.trim().length >= 20 &&
          this.trialForm.visual_appearance_influenced === "no"
        );
      },
      activeComparisonCard: function () {
        if (!this.comparison) return null;
        var label = this.activeComparisonLabel;
        return this.comparison.cards.find(function (item) { return item.blind_label === label; }) || this.comparison.cards[0];
      },
      activeComparisonPosition: function () {
        if (!this.comparison) return 0;
        var labels = this.comparison.cards.map(function (item) { return item.blind_label; });
        var index = labels.indexOf(this.activeComparisonLabel);
        return index >= 0 ? index + 1 : 1;
      },
      activeChecklistCard: function () {
        if (!this.checklist) return null;
        var label = this.activeChecklistLabel;
        return this.checklist.comparison.cards.find(function (item) { return item.blind_label === label; }) || null;
      },
      activeComparisonPrior: function () {
        if (!this.comparison || !this.comparison.previous_assessments) return null;
        return this.comparison.previous_assessments.by_label[this.activeComparisonLabel] || null;
      },
      activeComparisonResponse: function () {
        return this.comparisonResponses[this.activeComparisonLabel] || null;
      },
      activeComparisonScoresChanged: function () {
        var prior = this.activeComparisonPrior;
        var response = this.activeComparisonResponse;
        if (!prior || !response) return false;
        return Boolean(
          response.answers_legal_question !== prior.answers_legal_question ||
          response.enables_legal_objective !== prior.enables_legal_objective ||
          response.confidence !== prior.confidence
        );
      },
      comparisonDecisionCount: function () {
        if (!this.comparison) return 0;
        return this.comparison.cards.filter(function (card) {
          return this.comparisonScoreDecisionComplete(card.blind_label);
        }, this).length;
      },
      unrankedLabels: function () {
        if (!this.comparison) return [];
        return this.comparison.cards.map(function (card) { return card.blind_label; }).filter(function (label) {
          return this.rankingOrder.indexOf(label) < 0;
        }, this);
      },
      primaryAssessmentOrder: function () {
        return this.comparison && this.comparison.previous_assessments ? (this.comparison.previous_assessments.order || []) : [];
      },
      comparisonComplete: function () {
        if (!this.comparison || this.comparisonRationale.trim().length < 20) return false;
        if (this.rankingOrder.length !== this.comparison.cards.length) return false;
        return this.comparison.cards.every(function (card) {
          var response = this.comparisonResponses[card.blind_label];
          return Boolean(response &&
            this.comparisonScoreDecisionComplete(card.blind_label) &&
            response.answers_legal_question >= 1 && response.answers_legal_question <= 7 &&
            response.enables_legal_objective >= 1 && response.enables_legal_objective <= 7 &&
            response.confidence >= 1 && response.confidence <= 5);
        }, this);
      },
      checklistExpectedCount: function () {
        return this.checklist ? this.checklist.items.length * this.checklist.comparison.cards.length : 0;
      },
      checklistCompletedCount: function () {
        if (!this.checklist) return 0;
        return this.checklist.comparison.cards.reduce(function (total, card) {
          return total + this.checklistCountFor(card.blind_label);
        }.bind(this), 0);
      },
      isLastChecklistCard: function () {
        if (!this.checklist) return false;
        var cards = this.checklist.comparison.cards;
        return cards.findIndex(function (item) {
          return item.blind_label === this.activeChecklistLabel;
        }, this) === cards.length - 1;
      },
      postComplete: function () {
        return Boolean(this.postForm.checklist_new_considerations && this.postForm.technical_fact_understanding);
      }
    },
    methods: {
      progressClass: function (key) {
        if (!this.state) return "";
        if (key === "briefs") {
          if (this.state.completed_orientations >= 2) return "complete";
          if (["orientation", "intermission"].indexOf(this.state.stage) >= 0) return "active";
        }
        if (key === "judgments") {
          if (this.state.completed_trials >= 8) return "complete";
          if (["trials", "intermission"].indexOf(this.state.stage) >= 0) return "active";
        }
        if (key === "comparisons") {
          if (this.state.completed_comparisons >= this.state.total_comparisons) return "complete";
          if (this.state.stage === "ranking") return "active";
        }
        if (key === "checklists") {
          if (this.state.completed_checklists >= this.state.total_checklists) return "complete";
          if (this.state.stage === "checklist") return "active";
        }
        if (key === "poststudy") {
          if (this.state.stage === "complete") return "complete";
          if (this.state.stage === "poststudy") return "active";
        }
        return "";
      },
      api: async function (url, options) {
        var config = options || {};
        config.headers = Object.assign({ "Content-Type": "application/json" }, config.headers || {});
        if (config.method && config.method !== "GET" && this.state && this.state.csrf_token) {
          config.headers["X-CSRF-Token"] = this.state.csrf_token;
        }
        var result = await fetch(url, config);
        var body = await result.json().catch(function () { return {}; });
        if (!result.ok) throw new Error(body.error || "The study request failed.");
        return body;
      },
      initialize: async function () {
        try {
          if (this.isMock) {
            await this.initializeMock();
          } else {
            this.publicConfig = await this.api("/api/public-config");
            try {
              this.state = await this.api("/api/state");
            } catch (error) {
              if (!/No active study session/.test(error.message)) throw error;
              this.state = null;
            }
            await this.loadStage();
          }
        } catch (error) {
          this.fatalError = error.message;
        } finally {
          this.loading = false;
        }
      },
      initializeMock: async function () {
        var configUrl = window.location.pathname.indexOf("/static/") >= 0 ?
          "../config/study.json" : "/config/study.json";
        var response = await fetch(configUrl);
        if (!response.ok) throw new Error("Could not load the local demo configuration.");
        this.rawConfig = await response.json();
        this.rawConfig.modules = resolveModules(this.rawConfig.modules);
        this.publicConfig = {
          title: this.rawConfig.title,
          version: this.rawConfig.version,
          mode: "mock",
          participant_copy: this.rawConfig.participant_copy,
          participant_module_choice: false,
          minimum_age: this.rawConfig.ethics.minimum_age,
          withdrawal_policy: this.rawConfig.ethics.withdrawal_policy,
          contexts: this.rawConfig.design.primary_study_modules.map(function (id) {
            var module = this.rawConfig.modules[id];
            return {
              id: id,
              label: module.label,
              domain: module.domain,
              provision_label: module.provision_label
            };
          }, this)
        };
        var screen = this.params.get("screen") || "intro";
        var firstModuleId = this.rawConfig.design.primary_study_modules[0];
        var secondModuleId = this.rawConfig.design.primary_study_modules[1];
        var moduleId = this.params.get("module") || firstModuleId;
        this.startForm.module_id = moduleId;
        if (this.params.get("prefill") === "1") {
          this.startForm.panel_code = "DEMO-E01-LEGAL-XAI";
          this.startForm.experience_band = "legal-practitioner";
          this.startForm.years_legal_experience = 12;
          this.startForm.gdpr_familiarity = 5;
          this.startForm.mdr_familiarity = 5;
          this.startForm.age_confirmed = true;
          this.startForm.participation_consent = true;
          this.startForm.data_use_consent = true;
          this.startForm.role_acknowledged = true;
        }
        if (screen === "intro") {
          this.state = null;
          return;
        }
        var module = this.rawConfig.modules[moduleId] || this.rawConfig.modules[firstModuleId];
        if (screen === "ranking" && !module.comparison_enabled) {
          var comparisonModuleId = this.rawConfig.design.primary_study_modules.find(function (id) {
            return Boolean(this.rawConfig.modules[id].comparison_enabled);
          }, this);
          if (!comparisonModuleId) throw new Error("No comparison-enabled module is configured.");
          moduleId = comparisonModuleId;
          module = this.rawConfig.modules[moduleId];
          this.startForm.module_id = moduleId;
        }
        var isFirstModule = moduleId === firstModuleId;
        this.state = {
          session_id: "mock-session",
          stage: screen === "trial" ? "trials" : screen,
          current_trial: Number(this.params.get("trial") || 0),
          global_trial_number: Number(this.params.get("global") || (isFirstModule ? 1 : 5)),
          completed_trials: screen === "trial" ? (isFirstModule ? 0 : 4) : (screen === "orientation" ? 0 : 8),
          total_trials: 8,
          completed_orientations: isFirstModule ? 0 : 1,
          completed_comparisons: screen === "checklist" || screen === "poststudy" || screen === "complete" ? 2 : (screen === "ranking" && moduleId === secondModuleId ? 1 : 0),
          total_comparisons: 2,
          completed_checklists: screen === "poststudy" || screen === "complete" ? 2 : 0,
          total_checklists: 2,
          total_modules: 2,
          module_position: isFirstModule ? 1 : 2,
          panel_slot: "E01",
          orientation_attempts: 0,
          module: publicModule(module),
          poststudy_checks: this.rawConfig.design.primary_study_modules.reduce(function (all, id) {
            return all.concat((this.rawConfig.modules[id].poststudy_checks || []).map(function (item) {
              var safe = clone(item); delete safe.correct; return safe;
            }));
          }.bind(this), []),
          csrf_token: "mock",
          study_title: this.rawConfig.title,
          study_version: this.rawConfig.version,
          withdrawal_allowed: screen !== "complete"
        };
        await this.loadMockStage(module);
      },
      initializeComparison: function (cards, prefill) {
        this.comparisonResponses = {};
        var prior = this.comparison && this.comparison.previous_assessments ? this.comparison.previous_assessments : { order: [], by_label: {} };
        cards.forEach(function (card, index) {
          var locked = prior.by_label && prior.by_label[card.blind_label];
          var fallbackQuestion = prefill ? [6, 5, 3, 2][index] : null;
          var fallbackObjective = prefill ? [6, 5, 3, 2][index] : null;
          var fallbackConfidence = prefill ? [4, 4, 3, 3][index] : null;
          this.comparisonResponses[card.blind_label] = {
            prior_question_rating: locked ? locked.answers_legal_question : fallbackQuestion,
            answers_legal_question: locked ? locked.answers_legal_question : fallbackQuestion,
            enables_legal_objective: locked ? locked.enables_legal_objective : fallbackObjective,
            confidence: locked ? locked.confidence : fallbackConfidence,
            score_decision: prefill ? "keep" : null,
            revision_rationale: prefill ? "Comparison with the other explanations confirms this revised score reflects the legal assessment more accurately." : ""
          };
        }, this);
        var validLabels = cards.map(function (card) { return card.blind_label; });
        var priorOrder = (prior.order || []).filter(function (label) { return validLabels.indexOf(label) >= 0; });
        this.rankingOrder = priorOrder.length === validLabels.length ? priorOrder.slice() : validLabels.slice();
        this.draggedRankLabel = null;
        this.comparisonRerankReason = "";
      },
      comparisonScoresChanged: function (label) {
        if (!this.comparison || !this.comparison.previous_assessments) return false;
        var prior = this.comparison.previous_assessments.by_label[label];
        var response = this.comparisonResponses[label];
        if (!prior || !response) return false;
        return Boolean(
          response.answers_legal_question !== prior.answers_legal_question ||
          response.enables_legal_objective !== prior.enables_legal_objective ||
          response.confidence !== prior.confidence
        );
      },
      comparisonScoreDecisionComplete: function (label) {
        var response = this.comparisonResponses[label];
        if (!response || !response.score_decision) return false;
        if (response.score_decision === "keep") return true;
        return response.score_decision === "revise" && this.comparisonScoresChanged(label) && String(response.revision_rationale || "").trim().length >= 20;
      },
      comparisonDecisionStatus: function (label) {
        var response = this.comparisonResponses[label];
        if (!response || !response.score_decision) return "Score decision required";
        if (response.score_decision === "keep") return "Keep scores selected";
        if (!this.comparisonScoresChanged(label)) return "Change at least one score";
        return String(response.revision_rationale || "").trim().length >= 20 ? "Revised scores and reason complete" : "Revision reason required";
      },
      setComparisonScoreDecision: function (label, decision) {
        var response = this.comparisonResponses[label];
        var prior = this.comparison && this.comparison.previous_assessments ? this.comparison.previous_assessments.by_label[label] : null;
        if (!response || !prior || ["keep", "revise"].indexOf(decision) < 0) return;
        response.score_decision = decision;
        if (decision === "keep") {
          response.answers_legal_question = prior.answers_legal_question;
          response.enables_legal_objective = prior.enables_legal_objective;
          response.confidence = prior.confidence;
          response.revision_rationale = "";
        }
      },
      startRankDrag: function (label) {
        this.draggedRankLabel = label;
      },
      dropRankAt: function (index) {
        var label = this.draggedRankLabel;
        if (!label) return;
        var current = this.rankingOrder.slice();
        var previousIndex = current.indexOf(label);
        if (previousIndex >= 0) {
          current.splice(previousIndex, 1);
          if (previousIndex < index) index -= 1;
        }
        current.splice(Math.max(0, Math.min(index, current.length)), 0, label);
        this.rankingOrder = current;
        this.draggedRankLabel = null;
      },
      addToRanking: function (label) {
        if (this.rankingOrder.indexOf(label) < 0) this.rankingOrder = this.rankingOrder.concat([label]);
      },
      removeFromRanking: function (label) {
        this.rankingOrder = this.rankingOrder.filter(function (item) { return item !== label; });
      },
      moveRank: function (label, delta) {
        var current = this.rankingOrder.slice();
        var index = current.indexOf(label);
        var next = index + delta;
        if (index < 0 || next < 0 || next >= current.length) return;
        current.splice(index, 1);
        current.splice(next, 0, label);
        this.rankingOrder = current;
      },
      loadMockStage: async function (module) {
        var labels = ["B", "D", "A", "C"];
        var prefill = this.params.get("prefill") === "1";
        if (this.state.stage === "orientation") {
          this.orientation = {
            title: this.rawConfig.orientation.title,
            instructions: module.orientation_instructions || this.rawConfig.orientation.instructions,
            legal_context: publicModule(module),
            evidence_explainer: this.rawConfig.orientation.evidence_explainer,
            questions: this.rawConfig.orientation.questions.map(function (item) {
              var safe = clone(item); delete safe.correct; return safe;
            })
          };
          if (prefill) {
            this.rawConfig.orientation.questions.forEach(function (item) {
              this.orientationForm.answers[item.id] = item.correct;
            }, this);
          }
          return;
        }
        if (this.state.stage === "trials") {
          var conditionIndex = Number(this.params.get("condition") || this.state.current_trial || 0) % 4;
          var caseIndex = Number(this.params.get("case") || 0) % module.cases.length;
          var condition = module.conditions[conditionIndex];
          var caseData = module.cases[caseIndex];
          var card = mockCard(module, condition, labels[conditionIndex], caseData);
          this.trial = {
            trial_index: this.state.current_trial,
            blind_label: card.blind_label,
            case: {
              case_ref: caseData.case_ref,
              decision: caseData.decision,
              model_output: caseData.model_output,
              case_narrative: caseData.case_narrative || "",
              profile: caseData.profile
            },
            legal_question: card.legal_question,
            legal_objective: card.legal_objective,
            explanation: card.explanation,
            assurance: card.assurance
          };
          if (prefill) {
            this.trialForm = {
              disposition: "material-remediation",
              answers_legal_question: 4,
              enables_legal_objective: 3,
              confidence: 4,
              rationale: "The independent technical expert memo identifies a material issue that affects my legal assessment.",
              additional_information: "I would request the complete audit record and any omitted information.",
              visual_appearance_influenced: "no",
              visual_format_comments: ""
            };
          }
          return;
        }
        if (["ranking", "checklist"].indexOf(this.state.stage) >= 0) {
          var cards = module.conditions.map(function (condition, index) {
            return mockCard(module, condition, labels[index], module.comparison_case);
          }).sort(function (a, b) { return a.blind_label.localeCompare(b.blind_label); });
          this.comparison = {
            case: {
              case_ref: module.comparison_case.case_ref,
              decision: module.comparison_case.decision,
              model_output: module.comparison_case.model_output,
              case_narrative: module.comparison_case.case_narrative || "",
              profile: module.comparison_case.profile
            },
            cards: cards,
            legal_question: module.legal_question,
            legal_objective: module.legal_objective,
            previous_assessments: {
              order: ["A", "B", "C", "D"],
              by_label: {
                "A": { answers_legal_question: 6, enables_legal_objective: 6, confidence: 4, disposition: "sufficient" },
                "B": { answers_legal_question: 5, enables_legal_objective: 5, confidence: 4, disposition: "minor-remediation" },
                "C": { answers_legal_question: 3, enables_legal_objective: 3, confidence: 3, disposition: "material-remediation" },
                "D": { answers_legal_question: 2, enables_legal_objective: 2, confidence: 3, disposition: "inadequate" }
              }
            }
          };
          this.activeComparisonLabel = this.params.get("label") || "A";
          this.initializeComparison(cards, prefill);
          this.comparisonRationale = prefill ?
            "The higher groups provide a more complete and reviewable basis; the lower groups contain material defects." : "";
          if (this.state.stage === "checklist") {
            this.checklist = {
              comparison: this.comparison,
              items: module.checklist,
              scale: { "1": "Clearly no", "2": "Leaning towards no", "3": "Leaning towards yes", "4": "Clearly yes" },
              provenance: module.checklist_provenance || ""
            };
            this.activeChecklistLabel = this.params.get("label") || "A";
            this.initializeChecklistScores();
            if (prefill) {
              module.checklist.forEach(function (item, index) {
                this.setChecklistValue(this.activeChecklistLabel, item.id, index < 2 ? 3 : 2);
              }, this);
            }
          }
          return;
        }
        if (this.state.stage === "poststudy" && prefill) {
          this.postForm.checklist_new_considerations = "no";
          this.postForm.technical_fact_understanding = 5;
          this.postForm.method_recognition = "";
          this.postForm.comments = "The legal and technical materials were clear.";
        }
      },
      loadStage: async function () {
        this.formError = "";
        this.reportModalOpen = false;
        this.orientation = null;
        this.trial = null;
        this.comparison = null;
        this.checklist = null;
        if (!this.state) return;
        if (this.state.stage === "orientation") {
          this.orientationForm = { answers: {} };
          this.orientationResult = null;
          this.orientation = await this.api("/api/orientation");
        } else if (this.state.stage === "trials") {
          this.trial = await this.api("/api/trial/current");
          this.trialForm = newTrialForm();
          this.trialStartedAt = Date.now();
        } else if (this.state.stage === "ranking") {
          this.comparison = await this.api("/api/comparison");
          this.activeComparisonLabel = this.comparison.cards[0].blind_label;
          this.initializeComparison(this.comparison.cards, false);
          this.comparisonRationale = "";
          this.comparisonRerankReason = "";
        } else if (this.state.stage === "checklist") {
          this.checklist = await this.api("/api/checklist");
          this.comparison = this.checklist.comparison;
          this.activeChecklistLabel = this.checklist.comparison.cards[0].blind_label;
          this.initializeChecklistScores();
        }
      },
      resumeStudy: async function () {
        this.formError = "";
        if (this.startForm.panel_code.trim().length < 8) return;
        this.saving = true;
        try {
          if (this.isMock) {
            window.location.search = "?mock=1&screen=orientation&module=" +
              encodeURIComponent(this.startForm.module_id || this.rawConfig.design.primary_study_modules[0]);
            return;
          }
          await this.api("/api/session/resume", {
            method: "POST",
            body: JSON.stringify({ panel_code: this.startForm.panel_code })
          });
          this.state = await this.api("/api/state");
          await this.loadStage();
        } catch (error) {
          this.formError = error.message;
        } finally {
          this.saving = false;
        }
      },
      startStudy: async function () {
        this.formError = "";
        if (!this.canStart) return;
        this.saving = true;
        try {
          if (this.isMock) {
            window.location.search = "?mock=1&screen=orientation&module=" +
              encodeURIComponent(this.startForm.module_id || this.rawConfig.design.primary_study_modules[0]);
            return;
          }
          await this.api("/api/session", {
            method: "POST",
            body: JSON.stringify({
              panel_code: this.startForm.panel_code,
              experience_band: this.startForm.experience_band,
              years_legal_experience: this.startForm.years_legal_experience,
              gdpr_familiarity: this.startForm.gdpr_familiarity,
              mdr_familiarity: this.startForm.mdr_familiarity,
              consent: {
                age_confirmed: this.startForm.age_confirmed,
                participation_consent: this.startForm.participation_consent,
                data_use_consent: this.startForm.data_use_consent,
                role_acknowledged: this.startForm.role_acknowledged
              }
            })
          });
          this.state = await this.api("/api/state");
          await this.loadStage();
        } catch (error) {
          this.formError = error.message;
        } finally {
          this.saving = false;
        }
      },
      submitOrientation: async function () {
        this.formError = "";
        if (Object.keys(this.orientationForm.answers).length !== this.orientation.questions.length) return;
        this.saving = true;
        try {
          if (this.isMock) {
            var correct = this.rawConfig.orientation.questions.every(function (item) {
              return this.orientationForm.answers[item.id] === item.correct;
            }, this);
            this.orientationResult = {
              passed: correct,
              feedback: correct ? "All answers are correct." : "Review the packet and try again."
            };
            if (correct) {
              window.location.search = "?mock=1&screen=trial&module=" +
                encodeURIComponent(this.params.get("module") || this.rawConfig.design.primary_study_modules[0]);
            }
            return;
          }
          this.orientationResult = await this.api("/api/orientation", {
            method: "POST",
            body: JSON.stringify({ answers: this.orientationForm.answers })
          });
          this.state = this.orientationResult.state;
          if (this.orientationResult.passed) await this.loadStage();
        } catch (error) {
          this.formError = error.message;
        } finally {
          this.saving = false;
        }
      },
      continueStudy: async function () {
        this.formError = "";
        this.saving = true;
        try {
          if (this.isMock) {
            window.location.search = "?mock=1&screen=orientation&module=" +
              encodeURIComponent(this.rawConfig.design.primary_study_modules[1]);
            return;
          }
          this.state = await this.api("/api/intermission/continue", {
            method: "POST",
            body: "{}"
          });
          await this.loadStage();
          window.scrollTo({ top: 0, behavior: "smooth" });
        } catch (error) {
          this.formError = error.message;
        } finally {
          this.saving = false;
        }
      },
      submitTrial: async function () {
        this.formError = "";
        if (!this.trialComplete) return;
        this.saving = true;
        try {
          if (this.isMock) {
            window.location.search = "?mock=1&screen=ranking&module=" +
              encodeURIComponent(this.params.get("module") || this.rawConfig.design.primary_study_modules[0]);
            return;
          }
          var values = Object.assign({}, this.trialForm, {
            trial_index: this.trial.trial_index,
            elapsed_ms: Date.now() - this.trialStartedAt
          });
          this.state = await this.api("/api/trial", {
            method: "POST",
            body: JSON.stringify(values)
          });
          await this.loadStage();
          window.scrollTo({ top: 0, behavior: "smooth" });
        } catch (error) {
          this.formError = error.message;
        } finally {
          this.saving = false;
        }
      },
      openReportModal: function () {
        this.reportModalOpen = true;
      },
      closeReportModal: function () {
        this.reportModalOpen = false;
      },
      previousComparison: function () {
        var labels = this.comparison.cards.map(function (item) { return item.blind_label; });
        var index = labels.indexOf(this.activeComparisonLabel);
        this.activeComparisonLabel = labels[(index - 1 + labels.length) % labels.length];
      },
      nextComparison: function () {
        var labels = this.comparison.cards.map(function (item) { return item.blind_label; });
        var index = labels.indexOf(this.activeComparisonLabel);
        this.activeComparisonLabel = labels[(index + 1) % labels.length];
      },
      submitComparison: async function () {
        this.formError = "";
        if (!this.comparison) return;
        for (var ci = 0; ci < this.comparison.cards.length; ci += 1) {
          var checkCard = this.comparison.cards[ci];
          var checkLabel = checkCard.blind_label;
          var checkResponse = this.comparisonResponses[checkLabel];
          if (!checkResponse || !checkResponse.score_decision) {
            this.activeComparisonLabel = checkLabel;
            this.formError = "Explanation " + checkLabel + ": choose Keep or Revise before saving the final order.";
            return;
          }
          if (checkResponse.score_decision === "revise" && !this.comparisonScoresChanged(checkLabel)) {
            this.activeComparisonLabel = checkLabel;
            this.formError = "Explanation " + checkLabel + ": Revise is selected, but none of the scores has changed. Change at least one score or choose Keep.";
            return;
          }
          if (checkResponse.score_decision === "revise" && String(checkResponse.revision_rationale || "").trim().length < 20) {
            this.activeComparisonLabel = checkLabel;
            this.formError = "Explanation " + checkLabel + ": the reason for revised scores is required and must be at least 20 characters.";
            return;
          }
        }
        if (this.rankingOrder.length !== this.comparison.cards.length) {
          this.formError = "Complete the final order for all four explanations before saving.";
          return;
        }
        if (this.comparisonRationale.trim().length < 20) {
          this.formError = "Give a reason of at least 20 characters for the final order.";
          return;
        }
        this.saving = true;
        try {
          var responses = this.comparison.cards.map(function (card) {
            var revised = this.comparisonResponses[card.blind_label];
            return {
              blind_label: card.blind_label,
              rank_group: this.rankingOrder.indexOf(card.blind_label) + 1,
              score_decision: revised.score_decision,
              revised_answers_legal_question: revised.answers_legal_question,
              revised_enables_legal_objective: revised.enables_legal_objective,
              revised_confidence: revised.confidence,
              revision_rationale: String(revised.revision_rationale || "").trim()
            };
          }, this);
          var rationale = this.comparisonRationale.trim();
          if (this.isMock) {
            var moduleId = this.params.get("module") || this.rawConfig.design.primary_study_modules[0];
            var comparisonModules = this.rawConfig.design.primary_study_modules.filter(function (id) {
              return Boolean(this.rawConfig.modules[id].comparison_enabled);
            }, this);
            var comparisonIndex = comparisonModules.indexOf(moduleId);
            if (comparisonIndex >= 0 && comparisonIndex + 1 < comparisonModules.length) {
              window.location.search = "?mock=1&screen=ranking&module=" + encodeURIComponent(comparisonModules[comparisonIndex + 1]);
            } else {
              var checklistModule = this.rawConfig.design.primary_study_modules.find(function (id) {
                return Boolean(this.rawConfig.modules[id].show_checklist);
              }, this);
              window.location.search = "?mock=1&screen=checklist&module=" + encodeURIComponent(checklistModule || moduleId);
            }
            return;
          }
          this.state = await this.api("/api/ranking", {
            method: "POST",
            body: JSON.stringify({ responses: responses, rationale: rationale })
          });
          await this.loadStage();
          window.scrollTo({ top: 0, behavior: "smooth" });
        } catch (error) {
          this.formError = error.message;
        } finally {
          this.saving = false;
        }
      },
      initializeChecklistScores: function () {
        this.checklistScores = {};
        this.checklist.comparison.cards.forEach(function (card) {
          this.checklistScores[card.blind_label] = {};
        }, this);
      },
      checklistValue: function (label, itemId) {
        return this.checklistScores[label] ? this.checklistScores[label][itemId] || null : null;
      },
      setChecklistValue: function (label, itemId, score) {
        if (!this.checklistScores[label]) this.checklistScores[label] = {};
        this.checklistScores[label][itemId] = score;
      },
      checklistCountFor: function (label) {
        var values = this.checklistScores[label] || {};
        return Object.keys(values).filter(function (key) { return Boolean(values[key]); }).length;
      },
      previousChecklist: function () {
        var cards = this.checklist.comparison.cards;
        var index = cards.findIndex(function (item) {
          return item.blind_label === this.activeChecklistLabel;
        }, this);
        this.activeChecklistLabel = cards[(index - 1 + cards.length) % cards.length].blind_label;
      },
      nextChecklist: function () {
        var cards = this.checklist.comparison.cards;
        var index = cards.findIndex(function (item) {
          return item.blind_label === this.activeChecklistLabel;
        }, this);
        this.activeChecklistLabel = cards[Math.min(index + 1, cards.length - 1)].blind_label;
        window.scrollTo({ top: 150, behavior: "smooth" });
      },
      submitChecklist: async function () {
        this.formError = "";
        if (this.checklistCompletedCount !== this.checklistExpectedCount) return;
        this.saving = true;
        try {
          if (this.isMock) {
            window.location.search = "?mock=1&screen=poststudy&module=" +
              encodeURIComponent(this.params.get("module") || this.rawConfig.design.primary_study_modules[0]);
            return;
          }
          var responses = [];
          this.checklist.comparison.cards.forEach(function (card) {
            this.checklist.items.forEach(function (item) {
              responses.push({
                blind_label: card.blind_label,
                item_id: item.id,
                score: this.checklistValue(card.blind_label, item.id),
                comment: ""
              });
            }, this);
          }, this);
          this.state = await this.api("/api/checklist", {
            method: "POST",
            body: JSON.stringify({ responses: responses })
          });
          await this.loadStage();
          window.scrollTo({ top: 0, behavior: "smooth" });
        } catch (error) {
          this.formError = error.message;
        } finally {
          this.saving = false;
        }
      },
      submitPoststudy: async function () {
        this.formError = "";
        if (!this.postComplete) return;
        this.saving = true;
        try {
          if (this.isMock) {
            this.state.stage = "complete";
            return;
          }
          this.state = await this.api("/api/poststudy", {
            method: "POST",
            body: JSON.stringify(this.postForm)
          });
          await this.loadStage();
        } catch (error) {
          this.formError = error.message;
        } finally {
          this.saving = false;
        }
      },
      withdraw: async function () {
        if (!this.state || !this.state.withdrawal_allowed) return;
        if (!window.confirm("Erase this incomplete pseudonymous session and withdraw?")) return;
        this.withdrawing = true;
        try {
          if (!this.isMock) await this.api("/api/withdraw", { method: "POST", body: "{}" });
          this.state = null;
          this.withdrawalNotice = "The incomplete pseudonymous session was erased.";
        } catch (error) {
          this.formError = error.message;
        } finally {
          this.withdrawing = false;
        }
      }
    },
    mounted: function () {
      this._infoDismissHandler = function (event) {
        var clicked = event.target && event.target.closest ? event.target.closest("details.micro-tooltip, details.term-popover") : null;
        document.querySelectorAll("details.micro-tooltip[open], details.term-popover[open]").forEach(function (details) {
          if (!clicked || details !== clicked) details.removeAttribute("open");
        });
      };
      this._infoEscapeHandler = function (event) {
        if (event.key !== "Escape") return;
        document.querySelectorAll("details.micro-tooltip[open], details.term-popover[open]").forEach(function (details) {
          details.removeAttribute("open");
        });
      };
      document.addEventListener("click", this._infoDismissHandler);
      document.addEventListener("keydown", this._infoEscapeHandler);
      this.initialize();
    },
    beforeUnmount: function () {
      if (this._infoDismissHandler) document.removeEventListener("click", this._infoDismissHandler);
      if (this._infoEscapeHandler) document.removeEventListener("keydown", this._infoEscapeHandler);
    }
  });
  application.component("scale-question", scaleQuestion);
  application.component("xai-output-card", xaiOutputCard);
  application.mount("#app");
}());
