"""Transparent implementation of the Legal XAI property-to-compliance formula.

The study uses this module to reproduce the literature-derived prior scores for
the MDR explanation methods used in the controlled participant arm. Participant-facing routes never
expose these method names or scores before primary judgments are locked.

The formula follows the manuscript notation:

1. Compute the legal-strength-weighted mean across all positively weighted
   normalized sub-property scores.
2. Apply the question, scope, stage and feasibility gate.
3. Report the arithmetic, threshold and geometric views separately.

Property scores are ordinal comparative priors on a 1--5 scale, not empirical
measurements. The empirical benchmark is maintained separately under
``benchmark/results`` and never overwrites these priors.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping
from pathlib import Path
import json
import math

PROPERTY_CATEGORY = {
    "no_false_positives": "Faithfulness",
    "no_false_negatives": "Faithfulness",
    "completeness": "Faithfulness",
    "stability": "Robustness",
    "adversarial_robustness": "Robustness",
    "consistency": "Robustness",
    "hyperparameters_perturbation_robustness": "Robustness",
    "sparsity": "Complexity",
    "level_of_detail": "Complexity",
    "confidentiality": "Non-functional constraints",
    "traceability": "Non-functional constraints",
    "runtime_performance_and_implementation_constraints": "Efficiency",
}

MDR_REQUIREMENTS = json.loads((Path(__file__).resolve().parents[2]/'methods_scoring/inputs/paper_inputs.json').read_text())['regulations']['MDR']['required']

# Machine-readable catalogue source.
ALGORITHM_PROFILES = json.loads((Path(__file__).parent / "algorithm_profiles.json").read_text())
METHOD_PROPERTY_PRIORS = {n: p["subprops"] for n, p in ALGORITHM_PROFILES.items()}
SHAP_PROFILES = {n: ALGORITHM_PROFILES[n] for n in ("Exact local SHAP", "Approximate local SHAP", "Global SHAP summaries")}


@dataclass(frozen=True)
class ScoreBreakdown:
    overall: float
    categories: dict[str, float]
    procedural_fit: bool


def score_method(
    property_scores: Mapping[str, float],
    legal_requirements: Mapping[str, float],
    *,
    procedural_fit: bool = True,
) -> ScoreBreakdown:
    """Return the category scores and overall compliance prior in [0, 1]."""
    accum: dict[str, list[float]] = {}
    for prop, legal_weight in legal_requirements.items():
        if prop not in PROPERTY_CATEGORY:
            raise KeyError(f"Unknown property: {prop}")
        if not math.isfinite(float(legal_weight)) or not 0 <= legal_weight <= 1:
            raise ValueError(f"Legal weight for {prop} must be finite and in [0, 1]")
        if legal_weight == 0:
            continue
        if prop not in PROPERTY_CATEGORY:
            raise KeyError(f"Unknown property: {prop}")
        raw = float(property_scores.get(prop, 0))  # Eq. (1): unadvertised strength contributes zero.
        if not math.isfinite(raw) or not 0 <= raw <= 5:
            raise ValueError(f"Property score for {prop} must be in [0, 5]")
        cat = PROPERTY_CATEGORY[prop]
        if cat not in accum:
            accum[cat] = [0.0, 0.0]
        accum[cat][0] += float(legal_weight) * (raw / 5.0)
        accum[cat][1] += float(legal_weight)
    categories = {cat: num / den for cat, (num, den) in accum.items() if den > 0}
    if not categories:
        raise ValueError("The legal requirement vector has no positive weights")
    overall = sum(num for num, den in accum.values()) / sum(den for num, den in accum.values())
    if not procedural_fit:
        overall = 0.0
    return ScoreBreakdown(round(overall, 6), categories, procedural_fit)


def mdr_panel_scores() -> dict[str, float]:
    panel_methods = ("Global SHAP summaries", "PDP", "RuleSHAP", "Decision Trees")
    return {
        name: score_method(METHOD_PROPERTY_PRIORS[name], MDR_REQUIREMENTS).overall
        for name in panel_methods
    }


if __name__ == "__main__":
    for method, score in sorted(mdr_panel_scores().items(), key=lambda item: -item[1]):
        print(f"{method:16} {score:.6f}")
