# Legal XAI computation specification

The complete specification is in `../../methods_scoring/assess_xai_compliance_documentation.md`, relative to this directory. It defines scoring, sensitivity, expert statistics, data fields, instrument identity and benchmark measurements.
