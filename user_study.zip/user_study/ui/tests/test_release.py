from __future__ import annotations
import io, json, tempfile, unittest
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

from app import create_app
from analysis import analyse, kendall_tau_b, markdown_report
from study_core import ConfigError, load_config, participant_comparison_cards, participant_trial, validate_config, williams_sequences
from study_service import (
    StudyStateError, continue_after_break, ensure_database, get_checklist, get_comparison, get_current_trial,
    get_orientation, get_state, save_checklist, save_orientation, save_poststudy, save_ranking,
    save_trial, start_session,
)

class ReleaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.config=load_config(ROOT/'config/study.json')

    def test_config_roster_and_panel_target(self):
        self.assertEqual(validate_config(self.config,live=False),[])
        roster=self.config['panel']['roster']
        self.assertEqual(self.config['panel']['target_experts'],16)
        self.assertEqual(self.config['panel']['minimum_experts'],12)
        self.assertEqual(self.config['panel']['maximum_experts'],20)
        self.assertEqual(self.config['panel']['minimum_context_qualified_experts'],8)
        self.assertEqual(self.config['panel']['context_familiarity_threshold'],4)
        self.assertEqual(len(roster),20)
        for ix in range(4): self.assertEqual([r['sequence_index'] for r in roster].count(ix),5)
        self.assertEqual(len(williams_sequences(4)),4)
        clinical=self.config['modules']['clinical_empirical']
        self.assertTrue(clinical['comparison_enabled'])
        self.assertEqual(clinical['ordered_hypothesis'],[])
        self.assertEqual(len(clinical['confirmatory_contrasts']),2)
        self.assertEqual(len(clinical['matched_predictions']),2)
        self.assertEqual({c['target_question_archetype'] for c in clinical['conditions']},{'what feature','what rule'})
        for pair in clinical['matched_predictions']:
            left=next(c for c in clinical['conditions'] if c['id']==pair['better'])
            right=next(c for c in clinical['conditions'] if c['id']==pair['worse'])
            self.assertEqual(left['target_question_archetype'],right['target_question_archetype'])
        credit=self.config['modules']['credit_authority']
        self.assertEqual(credit['ordered_hypothesis'],[])
        self.assertEqual(credit['confirmatory_contrasts'],[])
        self.assertEqual({c['target_question_archetype'] for c in credit['conditions']},{'what feature','what rule','why instead of','how modify input'})
        self.assertNotEqual({c['target_question_archetype'] for c in clinical['conditions']},{c['target_question_archetype'] for c in credit['conditions']})
        self.assertNotIn('clinical-lime',{c['id'] for c in clinical['conditions']})
        self.assertIn('clinical-ruleshap',{c['id'] for c in clinical['conditions']})
        for condition in clinical['conditions']:
            output=condition['explanation']['xai_output']
            self.assertEqual(output.get('scope_label'), 'Across reference patients')
            self.assertNotEqual(output.get('kind'),'local_surrogate')
            self.assertNotIn('patient_path',output)
            self.assertTrue(output.get('question'))
            self.assertTrue(output.get('text_representation'))
        for condition in credit['conditions']:
            output=condition['explanation']['xai_output']
            self.assertTrue(output.get('question'))
            self.assertTrue(output.get('text_representation'))

    def test_participant_payloads_hold_assessment_question_constant_within_context(self):
        for module in self.config['modules'].values():
            assignments=[]
            for index, condition in enumerate(module['conditions']):
                assignment={
                    'trial_index': index,
                    'blind_label': chr(65 + index),
                    'condition_id': condition['id'],
                    'case_id': module['cases'][index % len(module['cases'])]['id'],
                }
                assignments.append(assignment)
                trial=participant_trial(module,assignment)
                self.assertEqual(trial['legal_question'],module['legal_question'])
                self.assertEqual(trial['legal_objective'],module['legal_objective'])
                self.assertNotIn('target_question_text',trial)
                self.assertNotIn('explanation_focus_text',trial)
                self.assertNotIn('target_question_archetype',trial)
            comparison=participant_comparison_cards(module,assignments)
            self.assertEqual({card['legal_question'] for card in comparison['cards']},{module['legal_question']})
            self.assertEqual({card['legal_objective'] for card in comparison['cards']},{module['legal_objective']})
            for card in comparison['cards']:
                self.assertNotIn('target_question_text',card)
                self.assertNotIn('explanation_focus_text',card)
                self.assertNotIn('target_question_archetype',card)

    def test_cross_context_expert_memo_terminology_is_consolidated(self):
        credit=self.config['modules']['credit_authority']
        clinical=self.config['modules']['clinical_empirical']
        expected_keys=[
            'no_false_positives','no_false_negatives','completeness','stability',
            'adversarial_robustness','consistency','hyperparameters_perturbation_robustness',
            'sparsity','level_of_detail','confidentiality','traceability',
            'runtime_performance_and_implementation_constraints',
        ]
        self.assertEqual(credit['assurance_schema'],expected_keys)
        self.assertEqual(clinical['assurance_schema'],expected_keys)
        for key in expected_keys:
            for module in (credit,clinical):
                guide=module['evidence_guide'][key]
                self.assertTrue(guide['category'])
                self.assertTrue(guide['property'])
                self.assertTrue(guide['heading'])
                self.assertTrue(guide['technical_term'])
                self.assertTrue(guide['definition'])
            for field in ('category','property','heading','technical_term','short_label','definition','tested'):
                self.assertEqual(credit['evidence_guide'][key][field],clinical['evidence_guide'][key][field])
        self.assertEqual(credit['evidence_scale'],clinical['evidence_scale'])
        self.assertEqual(credit['expert_memo_title'],'Independent technical expert memo')
        self.assertEqual(clinical['expert_memo_title'],'Independent technical expert memo')
        self.assertNotIn('expert_memo_kicker', credit)
        self.assertNotIn('expert_memo_role', credit)
        for module in (credit,clinical):
            for condition in module['conditions']:
                self.assertEqual(set(condition['evidence_metrics']),set(expected_keys))
                for key in expected_keys:
                    self.assertEqual(condition['evidence_metrics'][key]['score'],condition['property_scores'][key])
                    self.assertIn('/5',condition['evidence_metrics'][key]['display'])

    def test_live_mode_fails_closed_before_external_approvals(self):
        with self.assertRaises(ConfigError): validate_config(self.config,live=True)

    def test_vendored_vue3_and_same_origin_csp(self):
        app_js=(ROOT/'static/assets/app.js').read_text(); admin_js=(ROOT/'static/assets/admin.js').read_text()
        index=(ROOT/'static/index.html').read_text(); admin=(ROOT/'static/admin.html').read_text(); server=(ROOT/'app.py').read_text()
        vendor=(ROOT/'static/assets/vendor/vue.global.prod.js').read_text(errors='ignore')[:300]
        self.assertIn('Vue.createApp',app_js); self.assertIn('Vue.createApp',admin_js)
        self.assertIn('/assets/vendor/vue.global.prod.js',index); self.assertIn('/assets/vendor/vue.global.prod.js',admin)
        self.assertIn('vue v3.5.13',vendor.lower()); self.assertNotIn('cdn.jsdelivr.net',index+admin+server)
        self.assertNotIn('Vue.component(',app_js)
        workflow=(ROOT/'static/workflow.html').read_text()
        self.assertNotIn("frozen four-method order",workflow)
        self.assertIn("two",workflow.lower())

    def test_comparison_is_seeded_reranking_with_explicit_score_decisions(self):
        app_js=(ROOT/'static/assets/app.js').read_text(); index=(ROOT/'static/index.html').read_text(); service=(ROOT/'study_service.py').read_text(); styles=(ROOT/'static/assets/styles.css').read_text()
        self.assertIn('this.rankingOrder = priorOrder.length === validLabels.length ? priorOrder.slice() : validLabels.slice()',app_js)
        self.assertIn('Review and re-rank the four explanations',index)
        self.assertIn('Required score decision',index)
        self.assertIn('Keep these scores',index)
        self.assertIn('Revise one or more scores',index)
        self.assertIn('score_decision: prefill ? "keep" : null',app_js)
        self.assertIn('comparisonScoreDecisionComplete',app_js)
        self.assertIn('score_decision: revised.score_decision',app_js)
        self.assertIn('revised_answers_legal_question',app_js)
        self.assertIn('revised_enables_legal_objective',app_js)
        self.assertIn('revised_confidence',app_js)
        self.assertNotIn('How adequate is this explanation for that question?',index)
        self.assertIn('draggable="true"',index)
        self.assertIn('comparison-content-stacked',index)
        self.assertIn('.comparison-content-stacked',styles)
        self.assertIn('score_decision TEXT NOT NULL',service)
        self.assertIn('item.get("score_decision")',service)
        self.assertIn('item.get("revised_answers_legal_question"',service)
        self.assertNotIn('item.get("adequacy_rating")',service)

    def test_supported_stack_only(self):
        searchable=[]
        for path in ROOT.rglob('*'):
            if path.is_file() and path.suffix.lower() in {'.py','.js','.html','.md','.json','.txt'} and 'vendor' not in path.parts and 'tests' not in path.parts:
                searchable.append(path.read_text(errors='ignore'))
        corpus='\n'.join(searchable).lower()
        self.assertNotIn('paper_code',corpus)
        self.assertNotIn('new vue(',corpus)
        self.assertNotIn('bottle + vue',corpus)

    def test_regulatory_and_judicial_authority_anchor(self):
        module=self.config['modules']['credit_authority']; auth=module['authority_benchmark']
        self.assertIn('C-203/22',auth['judicial_authority'])
        self.assertEqual(auth['supervisory_authority_decision'],'Not used in the participant instrument or primary legal benchmark.')
        self.assertIn('GDPR text',auth['source_limit'])
        self.assertEqual(module['ordered_hypothesis'],[])
        self.assertEqual(module['confirmatory_contrasts'],[])
        self.assertEqual(module['comparison_scope'],'cross_question_exploratory')
        d=next(c for c in module['conditions'] if c['id']=='credit-authority-d')
        self.assertEqual(d['literature_method'],'DiCE')
        self.assertEqual(d['target_question_archetype'],'how modify input')
        self.assertEqual(d['explanation']['xai_output']['kind'],'counterfactuals')

    def test_wsgi_health_and_public_config(self):
        with tempfile.TemporaryDirectory() as td:
            app=create_app(ROOT/'config/study.json',Path(td)/'db.sqlite3',secret='test-secret')
            def request(path):
                captured={}
                def start(status,headers): captured.update(status=status,headers=dict(headers))
                body=b''.join(app({'REQUEST_METHOD':'GET','PATH_INFO':path,'wsgi.input':io.BytesIO(b''),'CONTENT_LENGTH':'0'},start))
                return captured,json.loads(body)
            meta,health=request('/health'); self.assertEqual(meta['status'],'200 OK'); self.assertEqual(health['status'],'ok')
            _,public=request('/api/public-config'); self.assertEqual(public['target_experts'],16); self.assertEqual(public['minimum_experts'],12); self.assertEqual(len(public['contexts']),2)
            workflow_meta,workflow_body=request('/workflow'); self.assertEqual(workflow_meta['status'],'404 Not Found'); self.assertEqual(workflow_body['error'],'Not found.')
            static_workflow_meta,_=request('/static/workflow.html'); self.assertEqual(static_workflow_meta['status'],'404 Not Found')
            internal_doc_meta,_=request('/docs/RESEARCHER_RESULTS_GUIDE.md'); self.assertEqual(internal_doc_meta['status'],'404 Not Found')

    def test_complete_state_machine_blinding_and_context_familiarity(self):
        with tempfile.TemporaryDirectory() as td:
            db=Path(td)/'study.sqlite3'; ensure_database(db,self.config)
            consent={k:True for k in ['age_confirmed','participation_consent','data_use_consent','role_acknowledged']}
            session=start_session(db,self.config,'DEMO-E01-LEGAL-XAI','legal-practitioner',8,5,4,consent); sid=session['session_id']
            hidden_names=[c['method_identity'] for m in self.config['modules'].values() for c in m['conditions']]
            def pass_orientation():
                o=get_orientation(db,self.config,sid); key={q['id']:q['correct'] for q in self.config['orientation']['questions']}
                save_orientation(db,self.config,sid,{'answers':{q['id']:key[q['id']] for q in o['questions']}})
            def complete_trials():
                for _ in range(4):
                    trial=get_current_trial(db,self.config,sid); serialized=json.dumps(trial)
                    for name in hidden_names: self.assertNotIn(name,serialized)
                    for method_token in ('SHAP','RuleSHAP','LIME','PDP','CEM','DiCE'):
                        self.assertIsNone(__import__('re').search(r'\b'+__import__('re').escape(method_token.lower())+r'\b', serialized.lower()))
                    save_trial(db,self.config,sid,{'trial_index':trial['trial_index'],'disposition':'sufficient','answers_legal_question':5,'enables_legal_objective':5,'confidence':4,'rationale':'Sufficient legal rationale for automated release testing.','additional_information':'','visual_appearance_influenced':'no','visual_format_comments':'','elapsed_ms':1000})
            pass_orientation(); complete_trials(); self.assertEqual(get_state(db,self.config,sid)['stage'],'intermission')
            continue_after_break(db,self.config,sid); pass_orientation(); complete_trials(); self.assertEqual(get_state(db,self.config,sid)['stage'],'ranking')
            comp=get_comparison(db,self.config,sid); serialized=json.dumps(comp)
            for name in hidden_names: self.assertNotIn(name,serialized)
            for method_token in ('SHAP','RuleSHAP','LIME','PDP','CEM','DiCE'):
                self.assertIsNone(__import__('re').search(r'\b'+__import__('re').escape(method_token.lower())+r'\b', serialized.lower()))
            labels=[card['blind_label'] for card in comp['cards']]
            self.assertEqual(len(labels),4)
            with self.assertRaises(StudyStateError):
                save_ranking(db,self.config,sid,{'responses':[{'blind_label':label,'rank_group':i+1} for i,label in enumerate(labels)],'rationale':'This submission intentionally omits the required score decisions.'})
            with self.assertRaises(StudyStateError):
                save_ranking(db,self.config,sid,{'responses':[{'blind_label':label,'rank_group':i+1,'score_decision':'revise'} for i,label in enumerate(labels)],'rationale':'This submission selects revision without changing any numerical score.'})
            changed_without_reason=[{'blind_label':label,'rank_group':i+1,'score_decision':'keep'} for i,label in enumerate(labels)]
            changed_without_reason[0].update({'score_decision':'revise','revised_answers_legal_question':6})
            with self.assertRaises(StudyStateError):
                save_ranking(db,self.config,sid,{'responses':changed_without_reason,'rationale':'This submission changes a score but omits the mandatory score-revision reason.'})
            save_ranking(db,self.config,sid,{'responses':[{'blind_label':label,'rank_group':i+1,'score_decision':'keep'} for i,label in enumerate(labels)],'rationale':'Complete four-profile blinded re-ranking for automated release testing.'})
            self.assertEqual(get_state(db,self.config,sid)['stage'],'ranking')
            comp2=get_comparison(db,self.config,sid); labels2=[card['blind_label'] for card in comp2['cards']]
            self.assertEqual(len(labels2),4)
            # The second comparison also requires an explicit keep-or-revise score decision for every explanation.
            second_responses=[{'blind_label':label,'rank_group':i+1,'score_decision':'keep'} for i,label in enumerate(labels2)]
            second_responses[0].update({'score_decision':'revise','revised_answers_legal_question':6,'revision_rationale':'The revised legal-question score better reflects my reading of the explanation.'})
            save_ranking(db,self.config,sid,{'responses':second_responses,'rationale':'Second within-context blinded re-ranking for automated release testing.'})
            self.assertEqual(get_state(db,self.config,sid)['stage'],'checklist')
            for _ in range(2):
                checklist=get_checklist(db,self.config,sid)
                responses=[{'blind_label':card['blind_label'],'item_id':item['id'],'score':3,'comment':''} for card in checklist['comparison']['cards'] for item in checklist['items']]
                save_checklist(db,self.config,sid,{'responses':responses})
            self.assertEqual(get_state(db,self.config,sid)['stage'],'poststudy')
            save_poststudy(db,self.config,sid,{'technical_fact_understanding':5,'checklist_new_considerations':'no','method_recognition':'','comments':''})
            self.assertEqual(get_state(db,self.config,sid)['stage'],'complete')

    def test_analysis_uses_question_matched_clinical_and_authority_metrics(self):
        modules=self.config['modules']; trials=[]; rankings=[]; checklists=[]
        for slot in ('E01','E02'):
            clinical=modules['clinical_empirical']
            # Independent fixture supports the revised feature hypothesis.
            clinical_ratings={'clinical-shap':5,'clinical-ruleshap':7,'clinical-pdp':6,'clinical-tree':4}
            for c in clinical['conditions']:
                trials.append({'panel_slot':slot,'gdpr_familiarity':5,'mdr_familiarity':5,'module_id':'clinical_empirical','condition_id':c['id'],'enables_legal_objective':clinical_ratings[c['id']]})
                for item in clinical['checklist']:
                    checklists.append({'panel_slot':slot,'module_id':'clinical_empirical','condition_id':c['id'],'item_id':item['id'],'score':3})
            for i,c in enumerate(sorted(clinical['conditions'],key=lambda c:c['framework_rank'])):
                rankings.append({'panel_slot':slot,'gdpr_familiarity':5,'mdr_familiarity':5,'module_id':'clinical_empirical','condition_id':c['id'],'rank_group':1 if i < 2 else i})
            credit=modules['credit_authority']
            ordered=sorted(credit['conditions'],key=lambda c:c['framework_rank'])
            for i,c in enumerate(ordered):
                trials.append({'panel_slot':slot,'gdpr_familiarity':5,'mdr_familiarity':5,'module_id':'credit_authority','condition_id':c['id'],'enables_legal_objective':7-i})
                rankings.append({'panel_slot':slot,'gdpr_familiarity':5,'mdr_familiarity':5,'module_id':'credit_authority','condition_id':c['id'],'rank_group':i+1})
                for item in credit['checklist']:
                    checklists.append({'panel_slot':slot,'module_id':'credit_authority','condition_id':c['id'],'item_id':item['id'],'score':3})
        result=analyse(self.config,{'trials':trials,'rankings':rankings,'checklists':checklists,'poststudy':[]})
        clinical=result['clinical_predictive_validity']; credit=result['credit_authority_concordance']
        self.assertEqual(clinical['analysis_unit'],'MDR common-standard safe-use assessment with two matched explanatory-function comparisons')
        self.assertEqual(len(clinical['directed_predictions']),2)
        self.assertIn('primary_context_qualified_median_kendall_tau_b_complete_comparison',clinical)
        self.assertEqual(clinical['n_context_qualified'],2)
        self.assertFalse(clinical['context_qualified_validation_ready'])
        for pair in clinical['directed_predictions']:
            self.assertGreater(pair['support'],0)
            self.assertEqual(pair['reversal'],0)
            self.assertIn('qualified_median_rerank_position_advantage',pair)
        self.assertIn('primary_context_qualified_median_kendall_tau_b_complete_comparison',credit)
        self.assertIn('full_panel_median_expert_kendall_tau_b_complete_comparison',credit)
        self.assertEqual(credit['n_context_qualified'],2)
        self.assertFalse(credit['context_qualified_validation_ready'])
        self.assertEqual(kendall_tau_b([4,3,2,1],[4,3,2,1]),1.0)
        report=markdown_report(result)
        self.assertIn('Exploratory primary-population Kendall tau-b',report)
        self.assertIn('Inter-expert Kendall W for the four primary ratings',report)


    def test_interface_readability_guards(self):
        css=(ROOT/'static/assets/styles.css').read_text()
        admin=(ROOT/'static/assets/admin.css').read_text()
        self.assertIn('font-size: 15px',css)
        self.assertIn('.explanation-report-grid',css)
        self.assertIn('grid-template-columns: minmax(0,1fr) minmax(0,1fr)',css)
        self.assertIn('@media (max-width: 820px)',css)
        index=(ROOT/'static/index.html').read_text()
        self.assertIn('Explanation re-ranking',index)
        self.assertIn('checklist-side-by-side',index)
        self.assertIn('.comparison-assessment-layout',css)
        self.assertIn('.checklist-side-by-side',css)
        self.assertIn('.intermission-state .completion-grid',css)
        self.assertIn('grid-template-columns: repeat(2, minmax(0, 1fr))',css)
        self.assertIn('.intermission-state > .primary-button',css)
        self.assertIn('Property ratings',index)
        self.assertNotIn('Memo at a glance',index)
        self.assertNotIn('Technical expert report summary',index)
        self.assertNotIn('Your complete-order assessment',index)
        self.assertNotIn('font-size: 7px',css)
        self.assertNotIn('font-size: 8px',css)
        self.assertNotIn('font-size: 7px',admin)
        self.assertNotIn('font-size: 8px',admin)

    def test_benchmark_results_cover_panel_methods_and_lime_conditions(self):
        benchmark=json.loads((ROOT/'benchmark/results/case_study.json').read_text())
        methods={row['method'] for row in benchmark['results']}
        self.assertTrue({'SHAP','PDP','Tree surrogate','LIME baseline','LIME tuned'}.issubset(methods))
        self.assertNotIn('comparison',benchmark)
        self.assertEqual(benchmark['literature_vs_technical_measurements']['status'],'not collapsed into a validation correlation')
        self.assertIn('Nearest prototype',benchmark['representative_family_outputs'])
        self.assertIn('Counterfactual search',benchmark['representative_family_outputs'])
        self.assertIn('global_instruction_outputs',benchmark)
        self.assertTrue({'SHAP','PDP','Tree surrogate','LIME baseline'}.issubset(benchmark['global_instruction_outputs']))
        self.assertTrue(benchmark['representative_family_outputs']['Counterfactual search']['success'])
        for row in benchmark['results']:
            self.assertNotIn('empirical_technical_alignment_index',row)
            self.assertNotIn('technical_proxy_index_secondary',row)
            self.assertNotIn('measured_category_scores',row)
        self.assertFalse((ROOT/'benchmark/results/property_concordance.csv').exists())
        pdp=next(row for row in benchmark['results'] if row['method']=='PDP')
        self.assertIsNone(pdp['local_fidelity'])
        grid=(ROOT/'benchmark/results/lime_calibration_grid.csv').read_text()
        self.assertIn('150',grid); self.assertIn('2400',grid)

if __name__=='__main__': unittest.main()
