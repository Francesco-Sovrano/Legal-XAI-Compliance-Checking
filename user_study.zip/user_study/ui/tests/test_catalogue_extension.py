import ast,json,unittest,importlib.util
from pathlib import Path
from framework_scoring import ALGORITHM_PROFILES
from study_core import load_config
from study_service import ensure_database,admin_summary
import tempfile
R=Path(__file__).resolve().parents[1]
class ExtensionTests(unittest.TestCase):
 def test_current_catalogue_is_complete(self):
  self.assertEqual(len(ALGORITHM_PROFILES),26)
  for n,p in ALGORITHM_PROFILES.items():
   self.assertEqual(len(p['subprops']),12)
   self.assertEqual(set(p['subprops']),set(p['evidence']))
   for k,v in p['subprops'].items():
    self.assertIn(v,range(1,6));self.assertEqual(p['evidence'][k]['score'],v);self.assertTrue(p['evidence'][k]['rationale']);self.assertTrue(p['evidence'][k]['sources'])
 def test_standalone_parity_without_pandas_dependency(self):
  tree=ast.parse((R/'assess_xai_compliance.py').read_text());entries={}
  for node in tree.body:
   if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['algorithms_model_agnostic','algorithms_model_specific'] for t in node.targets):entries.update(ast.literal_eval(node.value))
  self.assertEqual(set(entries),set(ALGORITHM_PROFILES))
  for n,p in entries.items():self.assertEqual(p['subprops'],ALGORITHM_PROFILES[n]['subprops'])
 def test_researcher_catalogue_reaches_api(self):
  c=load_config(R/'config/study.json')
  with tempfile.TemporaryDirectory() as td:
   path=Path(td)/'db.sqlite3';ensure_database(path,c);data=admin_summary(path,c)
  self.assertEqual(len(data['method_catalogue']),26)
  self.assertEqual(sum(p['extension'] for p in data['method_catalogue']),6)
 def test_extensions_have_distinct_explained_targets(self):
  self.assertTrue(ALGORITHM_PROFILES['Supervised CBM']['requires_model_replacement'])
  self.assertTrue(ALGORITHM_PROFILES['Post-hoc CBM (concept-only)']['requires_model_replacement'])
  self.assertTrue(ALGORITHM_PROFILES['LaBo (LLM-guided CBM)']['requires_model_replacement'])
  self.assertTrue(ALGORITHM_PROFILES['LLM neuron explanations (Bills et al.)']['component_only'])
  self.assertEqual(ALGORITHM_PROFILES['MechaRule']['required_access'],'internal_interventions')
 @unittest.skipUnless(importlib.util.find_spec('pandas'),'standalone script requires optional pandas')
 def test_recommendation_filters(self):
  import assess_xai_compliance as a
  for name in ['Supervised CBM','Post-hoc CBM (concept-only)','LaBo (LLM-guided CBM)','LLM neuron explanations (Bills et al.)']:
   self.assertTrue(a.assess_xai_algorithms({name:a.algorithms_model_specific[name]})['Best Algorithm'].isna().all())
  name='MechaRule'
  self.assertTrue(a.assess_xai_algorithms({name:a.algorithms_model_specific[name]},available_access=set())['Best Algorithm'].isna().all())
  self.assertTrue(a.assess_xai_algorithms({name:a.algorithms_model_specific[name]},available_access={'internal_interventions'})['Best Algorithm'].notna().any())

 def test_llm_stage_fits_unchanged_predictor_scope(self):
  p=ALGORITHM_PROFILES['LLM-assisted behavioral RuleSHAP (MechaRule stage 1)']
  self.assertFalse(p['requires_model_replacement']);self.assertFalse(p['component_only'])
  self.assertEqual(p['required_access'],'behavioral_records')
