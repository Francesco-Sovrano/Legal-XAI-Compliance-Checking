"""Regression protection for refreshes that previously reset release metadata."""
import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ScoreRefreshTests(unittest.TestCase):
    def test_refresh_preserves_release_and_instrument_and_is_idempotent(self):
        spec = importlib.util.spec_from_file_location('score_refresh', ROOT / 'scripts/sync_scoring_catalogue.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        config = json.loads((ROOT / 'config/study.json').read_text())
        config['version'] = 'future-release'
        config['scoring_catalogue'] = {'test_marker': 'preserved metadata'}
        config['modules']['credit_authority']['evidence_guide']['stability']['definition'] = 'New instrument wording'
        before = copy.deepcopy(config)
        with tempfile.TemporaryDirectory() as td:
            module.ROOT = Path(td)
            (module.ROOT / 'config').mkdir()
            target = module.ROOT / 'config/study.json'
            target.write_text(json.dumps(config))
            (module.ROOT / 'literature_sources.json').write_bytes((ROOT / 'literature_sources.json').read_bytes())
            module.sync()
            after = json.loads(target.read_text())
            self.assertEqual(after['version'], before['version'])
            self.assertEqual(after['scoring_catalogue'], before['scoring_catalogue'])
            for mid in before['modules']:
                self.assertEqual(after['modules'][mid]['evidence_guide'], before['modules'][mid]['evidence_guide'])
                self.assertEqual([x['literature_score'] for x in after['modules'][mid]['conditions']],
                                 [x['literature_score'] for x in before['modules'][mid]['conditions']])
            first = target.read_bytes()
            module.sync()
            self.assertEqual(target.read_bytes(), first)

    def test_current_catalogue_and_exports_agree(self):
        import csv
        p = json.loads((ROOT / 'algorithm_profiles.json').read_text())
        with (ROOT / 'output/property_scores.csv').open() as f:
            rows = list(csv.DictReader(f))
        self.assertEqual(len(rows), sum(len(x['subprops']) for x in p.values()))
        for row in rows:
            e = p[row['algorithm']]['evidence'][row['property']]
            self.assertEqual(int(row['score']), e['score'])
            self.assertEqual(e['score'], p[row['algorithm']]['subprops'][row['property']])
            self.assertTrue(e['rationale'])
        ledger=json.loads((ROOT.parents[1]/'methods_scoring/inputs/score_evidence.json').read_text())
        self.assertEqual(len(ledger),312)
        for entry in ledger:
            self.assertEqual(entry['score'],p[entry['method']]['subprops'][entry['property']])
            self.assertTrue(entry['justification'])
            self.assertTrue(entry['locator'])
