from __future__ import annotations

import io
import json
import tempfile
from pathlib import Path

from app import _signed_cookie, create_app
from study_core import load_config, participant_comparison_cards, participant_trial
from study_service import (
    StudyStateError,
    ensure_database,
    get_orientation,
    participant_results_rows,
    save_orientation,
    save_trial,
    start_session,
)

ROOT = Path(__file__).resolve().parents[1]
CONFIG = load_config(ROOT / "config/study.json")
PROPERTY_KEYS = [
    "no_false_positives", "no_false_negatives", "completeness", "stability",
    "adversarial_robustness", "consistency", "hyperparameters_perturbation_robustness",
    "sparsity", "level_of_detail", "confidentiality", "traceability",
    "runtime_performance_and_implementation_constraints",
]


def _pass_orientation(db: Path, sid: str) -> None:
    orientation = get_orientation(db, CONFIG, sid)
    correct = {q["id"]: q["correct"] for q in CONFIG["orientation"]["questions"]}
    save_orientation(db, CONFIG, sid, {"answers": {q["id"]: correct[q["id"]] for q in orientation["questions"]}})


def test_all_technical_reports_use_twelve_unaggregated_exact_properties():
    catalogue = {row["name"]: row for row in CONFIG["method_catalogue"]}
    for module in CONFIG["modules"].values():
        assert module["assurance_schema"] == PROPERTY_KEYS
        for condition in module["conditions"]:
            exact = catalogue[condition["method_identity"]]["subprops"]
            assert set(condition["evidence_metrics"]) == set(PROPERTY_KEYS)
            for key in PROPERTY_KEYS:
                assert condition["evidence_metrics"][key]["score"] == exact[key]
                assert condition["evidence_metrics"][key]["display"] == f"{exact[key]}/5"
                assert module["evidence_guide"][key]["definition"]
                assert condition["assurance"][key]


def test_explanations_are_identical_between_primary_reranking_and_checklist_sources():
    for module in CONFIG["modules"].values():
        assignments = []
        primary_by_label = {}
        case_id = module["cases"][0]["id"]
        for index, condition in enumerate(module["conditions"]):
            assignment = {
                "trial_index": index,
                "blind_label": chr(65 + index),
                "condition_id": condition["id"],
                "case_id": case_id,
            }
            assignments.append(assignment)
            primary_by_label[assignment["blind_label"]] = participant_trial(module, assignment)["explanation"]
        comparison = participant_comparison_cards(module, assignments)
        comparison_by_label = {card["blind_label"]: card["explanation"] for card in comparison["cards"]}
        # The checklist endpoint reuses participant_comparison_cards; keeping this object equal
        # protects both later stages from stage-specific explanation rewrites.
        assert primary_by_label == comparison_by_label


def test_participant_csv_is_scoped_to_authenticated_session_and_contains_no_hidden_ids():
    with tempfile.TemporaryDirectory() as td:
        db = Path(td) / "study.sqlite3"
        ensure_database(db, CONFIG)
        consent = {k: True for k in ("age_confirmed", "participation_consent", "data_use_consent", "role_acknowledged")}
        one = start_session(db, CONFIG, "DEMO-E01-LEGAL-XAI", "legal-practitioner", 8, 5, 4, consent)
        two = start_session(db, CONFIG, "DEMO-E02-LEGAL-XAI", "legal-practitioner", 9, 4, 5, consent)
        for sess, marker in ((one, "OWNER_ONE_ONLY_MARKER"), (two, "OWNER_TWO_ONLY_MARKER")):
            sid = sess["session_id"]
            _pass_orientation(db, sid)
            from study_service import get_current_trial
            trial = get_current_trial(db, CONFIG, sid)
            save_trial(db, CONFIG, sid, {
                "trial_index": trial["trial_index"],
                "disposition": "sufficient",
                "answers_legal_question": 5,
                "enables_legal_objective": 5,
                "confidence": 4,
                "rationale": marker + " rationale recorded for privacy isolation testing.",
                "additional_information": "",
                "visual_appearance_influenced": "no",
                "visual_format_comments": "",
                "elapsed_ms": 1000,
            })
        rows = participant_results_rows(db, CONFIG, one["session_id"])
        blob = json.dumps(rows)
        assert "OWNER_ONE_ONLY_MARKER" in blob
        assert "OWNER_TWO_ONLY_MARKER" not in blob
        assert one["session_id"] not in blob and two["session_id"] not in blob
        assert "condition_id" not in blob and "method_identity" not in blob

        secret = "participant-export-test-secret"
        app = create_app(ROOT / "config/study.json", db, secret=secret)
        captured = {}
        def start(status, headers):
            captured.update(status=status, headers=dict(headers))
        environ = {
            "REQUEST_METHOD": "GET",
            "PATH_INFO": "/api/my-results.csv",
            "QUERY_STRING": "session_id=" + two["session_id"],  # must be ignored
            "HTTP_COOKIE": "legal_xai_session=" + _signed_cookie(one["session_id"], secret),
            "wsgi.input": io.BytesIO(b""),
            "CONTENT_LENGTH": "0",
        }
        body = b"".join(app(environ, start)).decode("utf-8-sig")
        assert captured["status"] == "200 OK"
        assert captured["headers"]["Content-Disposition"].startswith("attachment;")
        assert captured["headers"]["Cache-Control"] == "private, no-store"
        assert "OWNER_ONE_ONLY_MARKER" in body
        assert "OWNER_TWO_ONLY_MARKER" not in body
        assert one["session_id"] not in body and two["session_id"] not in body
        assert "SHAP" not in body and "CEM" not in body and "DiCE" not in body


def test_primary_judgment_rejects_visual_appearance_influence_yes():
    import pytest
    from study_service import get_current_trial
    with tempfile.TemporaryDirectory() as td:
        db = Path(td) / "study.sqlite3"
        ensure_database(db, CONFIG)
        consent = {k: True for k in ("age_confirmed", "participation_consent", "data_use_consent", "role_acknowledged")}
        session = start_session(db, CONFIG, "DEMO-E03-LEGAL-XAI", "legal-practitioner", 7, 5, 5, consent)
        sid = session["session_id"]
        _pass_orientation(db, sid)
        trial = get_current_trial(db, CONFIG, sid)
        with pytest.raises(StudyStateError, match="visual appearance did not influence"):
            save_trial(db, CONFIG, sid, {
                "trial_index": trial["trial_index"],
                "disposition": "sufficient",
                "answers_legal_question": 5,
                "enables_legal_objective": 5,
                "confidence": 4,
                "rationale": "A sufficiently long legal rationale for gate testing.",
                "additional_information": "",
                "visual_appearance_influenced": "yes",
                "visual_format_comments": "The card layout looked more polished.",
                "elapsed_ms": 1000,
            })
