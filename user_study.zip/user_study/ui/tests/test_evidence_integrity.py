"""Protect scores from drifting between the evidence ledger and interface."""
import csv,json,unittest
from pathlib import Path
from framework_scoring import ALGORITHM_PROFILES
R=Path(__file__).resolve().parents[1]
class EvidenceIntegrityTests(unittest.TestCase):
 def test_complete_evidence_and_interface_parity(self):
  sources=json.loads((R/'literature_sources.json').read_text())
  config=json.loads((R/'config/study.json').read_text())
  interface={p['name']:p for p in config['method_catalogue']}
  with (R/'output/property_scores.csv').open() as f:
   rows={(r['algorithm'],r['property']):r for r in csv.DictReader(f)}
  self.assertEqual(len(rows),312)
  for name,p in ALGORITHM_PROFILES.items():
   self.assertEqual(p['evidence'],interface[name]['evidence'])
   for key,score in p['subprops'].items():
    e=p['evidence'][key]
    self.assertEqual(e['score'],score)
    self.assertEqual(e['rationale'],p['rationale'][key])
    self.assertEqual(int(rows[name,key]['score']),score)
    self.assertEqual(set(e['sources']),set(e['source_locators']))
    self.assertTrue(e['basis']);self.assertTrue(e['numeric_status'])
    for source in e['sources']:self.assertEqual(p['sources'][source],sources[source])
