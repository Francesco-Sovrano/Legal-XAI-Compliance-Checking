from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "config" / "study.json").read_text())
INDEX = (ROOT / "static" / "index.html").read_text()
APP = (ROOT / "static" / "assets" / "app.js").read_text()
STYLES = (ROOT / "static" / "assets" / "styles.css").read_text()


def _outputs():
    for module in CONFIG["modules"].values():
        for condition in module["conditions"]:
            yield condition["id"], condition["explanation"]["xai_output"]


def test_explanation_outputs_include_their_interpretive_text_and_no_editorial_help_panels():
    for condition_id, output in _outputs():
        assert output.get("title"), condition_id
        assert output.get("question"), condition_id
        assert output.get("text_representation"), condition_id
        assert "subtitle" not in output, condition_id
        assert "help" not in output, condition_id


def test_interface_contains_no_redundant_interpretation_or_editorial_meta_language():
    corpus = (INDEX + "\n" + APP + "\n" + json.dumps(CONFIG, ensure_ascii=False)).lower()
    forbidden = (
        "additional note about this visual",
        "read from #1",
        "raw fitting coefficient",
        "not needed to interpret",
        "final labels compare",
        "numeric score bands",
        "plain-language interpretation",
        "what the result means",
        "visual explanation",
        "how the result is shown",
        "explanation focus",
        "these are comparative ratings, not measured case-specific results",
        "worked record:",
        "question tested:",
    )
    for phrase in forbidden:
        assert phrase not in corpus


def test_participant_evidence_has_one_finding_per_property_without_duplicate_worked_records():
    for module in CONFIG["modules"].values():
        for condition in module["conditions"]:
            assert "evidence_examples" not in condition
            assert set(condition["assurance"]) == set(module["assurance_schema"])


def test_ruleshap_is_one_ranked_output_without_strength_or_coefficient_copy():
    output = next(o for cid, o in _outputs() if cid == "clinical-ruleshap")
    assert output["kind"] == "rule_importance"
    assert [item["rank"] for item in output["items"]] == [1, 2, 3, 4]
    assert {item["direction_label"] for item in output["items"]} == {"Higher scores", "Lower scores"}
    assert all("strength_label" not in item for item in output["items"])
    assert "coefficient" not in json.dumps(output).lower()


def test_tree_labels_state_results_directly():
    output = next(o for cid, o in _outputs() if cid == "clinical-tree")
    leaves = [node["label"] for level in output["levels"] for node in level if node.get("result")]
    assert leaves == [
        "Higher average diabetes risk scores",
        "Intermediate average diabetes risk scores",
        "Intermediate average diabetes risk scores",
        "Lower average diabetes risk scores",
    ]


def test_primary_form_requires_all_three_numeric_scores():
    gate = "this.trialForm.answers_legal_question &&\n          this.trialForm.enables_legal_objective &&\n          this.trialForm.confidence"
    assert gate in APP
    assert 'label="Confidence in your assessment *" :max="5"' in INDEX


def test_panel_hierarchy_keeps_distinct_evidence_objects_but_flattens_nested_visuals():
    assert 'class="panel explanation-panel' in INDEX
    assert 'class="panel assurance-panel expert-memo-panel"' in INDEX
    assert ".xai-curve-card" in STYLES and "border: 0 !important" in STYLES
    assert ".rule-importance-row" in STYLES
    assert ".xai-credit-summary" in STYLES


def test_main_takeaway_label_only_is_bold_and_legacy_scope_banner_is_not_rendered():
    assert '<strong>Main takeaway:</strong>' in APP
    assert 'explanationContextLead' in APP
    assert 'xai-output-eyebrow' not in APP
    assert 'xai-scope-pill' not in APP
    assert '{{ output.title }}' not in APP
    assert '.xai-text-intro .xai-text-takeaway {' in STYLES
    assert 'font-weight: 400;' in STYLES


def test_primary_judgment_enforces_content_not_visual_appearance():
    assert 'Important: assess the information, not the visual appearance.' in INDEX
    assert 'visual_appearance_influenced === "no"' in APP
    assert 'Did the visual appearance or presentation format influence your legal assessment?' in INDEX
    assert 'Submission remains disabled until you can answer No.' in INDEX
    assert 'visual_format_comments' in APP
    assert 'visual_format_comments' in INDEX
