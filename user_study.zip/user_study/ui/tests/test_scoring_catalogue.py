"""Regression cases for formula errors, scope leakage and interface/config drift."""
import unittest, json, math
from pathlib import Path
from framework_scoring import score_method, SHAP_PROFILES, MDR_REQUIREMENTS
from study_core import load_config, validate_config, hidden_debug_record
ROOT=Path(__file__).resolve().parents[1]

class ScoringCatalogueTests(unittest.TestCase):
    def test_unused_categories_do_not_dilute_score(self):
        self.assertEqual(score_method({'stability':5},{'stability':1,'sparsity':0}).overall,1)
        self.assertEqual(score_method({'stability':5},{'stability':1,'no_false_positives':1}).overall,.5)
        self.assertEqual(score_method({'stability':5},{'stability':1},procedural_fit=False).overall,0)

    def test_reject_nonfinite_and_negative_weights(self):
        for weight in [float('nan'),float('inf'),-1,2]:
            with self.assertRaises(ValueError): score_method({'stability':3},{'stability':weight})
        with self.assertRaises(ValueError): score_method({'stability':float('nan')},{'stability':1})

    def test_three_profiles_and_expected_mdr_arithmetic(self):
        # Hand-calculated property-weighted MDR means (denominator 55).
        expected={'Exact local SHAP': 0.581818, 'Approximate local SHAP': 0.527273, 'Global SHAP summaries': 0.527273}
        for name,value in expected.items():
            self.assertAlmostEqual(score_method(SHAP_PROFILES[name]['subprops'],MDR_REQUIREMENTS).overall,value,places=6)

    def test_config_debug_and_hypotheses_match_recalculation(self):
        c=load_config(ROOT/'config/study.json')
        self.assertEqual(validate_config(c),[])
        for m in c['modules'].values():
            for t in m['conditions']:
                d=hidden_debug_record(m,t)
                self.assertEqual(d['literature_score'],score_method(t['property_scores'],m['requirement_weights'],procedural_fit=d['procedural_fit']).overall)
            for pair in m.get('matched_predictions',[]):
                conditions={t['id']:t for t in m['conditions']}
                self.assertGreater(conditions[pair['better']]['literature_score'],conditions[pair['worse']]['literature_score'])
        self.assertEqual(c['modules']['clinical_empirical']['conditions'][0]['method_identity'],'Global SHAP summaries')
        self.assertEqual(c['modules']['credit_authority']['conditions'][1]['literature_score'],0)
        for m in c['modules'].values():
            self.assertEqual(len(m['shap_variant_comparison']),3)

if __name__=='__main__': unittest.main()
