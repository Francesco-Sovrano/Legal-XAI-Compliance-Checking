# Legal-expert analysis

`public-review.sqlite3` is the recorded response database. `legal_expert_validation.py` reads the four-expert analytic cohort and writes formula scores, concordances, exact permutation tests, comparison-stage statistics and PDF figures to `analysis/`. It uses the shared method-scoring inputs and joint draws.

From the package root:

```sh
python -m pip install -r user_study/data/requirements.txt
python methods_scoring/sensitivity_analysis.py
python user_study/data/legal_expert_validation.py
```

`data_audit.py` exports the cohort, database schema, qualitative annotations and instrument-hash comparison to `audit/`. The full pipeline runs this audit automatically. The complete specification is `methods_scoring/assess_xai_compliance_documentation.md` from the package root.
