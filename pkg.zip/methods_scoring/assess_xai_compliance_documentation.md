# Legal XAI computation and data specification

Paths in this document are relative to the package root.

## Analysis inputs

`methods_scoring/inputs/paper_inputs.json` fixes the property order, method definitions, integer ratings, procedural characteristics and legal weights. The 12 properties belong to faithfulness (no false positives, no false negatives, completeness), robustness (stability, adversarial robustness, run-to-run consistency, explainer-parameter robustness), complexity (sparsity, level of detail), non-functional constraints (confidentiality, traceability) and efficiency (computational feasibility). Efficiency is an independent family. Level of detail is the granularity needed for the explanatory task.

Each integer is a manual comparative judgment on a scale from 1 to 5. Scores 1 and 2 denote weak support, 3 a neutral or conditional assessment, and 4 and 5 increasingly strong support. A cited theoretical guarantee concerns its stated explanation target; the integer records the authors' interpretation of that guarantee or empirical finding for the defined property. The catalogue contains fourteen model-agnostic profiles and twelve model-specific profiles. Four model-specific profiles require replacement of the predictor or explain internal components and are excluded from output-explanation ranking comparisons.

## Scoring equations

For method ratings x_j and legal weights w_j, the soft score is sum(w_j x_j/5)/sum(w_j). The thresholded score is sum(w_j I[x_j >= T_j])/sum(w_j). The geometric score is exp(sum(w_j omega_j log(x_j/5))/sum(w_j omega_j)). Defaults use T_j=3 and omega_j=1. Properties with zero legal weight contribute to neither numerator nor denominator. The arithmetic mean weights properties directly; it does not average property-family means. The standalone script also reports family summaries for interpretation.

Procedural eligibility checks explanatory question, scope and the defined method profile. An individual-decision feature explanation excludes a global PDP. Model access is assumed for the comparative tables; `eligible(..., available_access=...)` permits explicit access filtering. `hard_gate` sets the result to zero when any supplied mandatory criterion is false or unestablished. Numerical fit does not replace applicability and disclosure analysis.

The default weights are 1 for a requirement, 0.5 for a qualified requirement, and 0 for a sub-property that is not scored. Operator-focused adversarial robustness and partial confidentiality use 0.5. For the fixed-decision tasks under B1 and B2, stability is 0 and explainer-parameter robustness is 1. Faithfulness evaluates the explanation of the specified decision; stability compares explanations for different inputs. Repeated executions and minor computational-parameter changes preserve the predictor, input, explained target, reference comparison and explanatory question. Parameter robustness concerns preservation of the legally material account under those changes. MDR sparsity and level of detail use 0.5, reflecting the intended user's knowledge and training under Annex I, Section 23.1(a). B5 confidentiality is a qualified requirement with legal weight 0.5. Explanations must protect third parties' personal data, including identifiable training-patient records. Articles 109–110 provide confidentiality and data-protection safeguards; trade-secret protection cannot justify withholding the information required under Article 10(11) and Annex I for safe and informed use. MDR runtime is 0 for instructions supplied before marketing. The study analysis reads this same matrix. Mandatory legal criteria are evaluated separately from these comparative weights.


| Property | B1 | B2 | B3 | B4 | B5 | B6 | B7 |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| no false positives | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| no false negatives | 1 | 1 | 0 | 1 | 1 | 1 | 1 |
| completeness | 0 | 1 | 0 | 1 | 1 | 1 | 1 |
| stability | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| adversarial robustness | 0.5 | 0.5 | 0.5 | 1 | 1 | 1 | 1 |
| consistency | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| explainer-parameter robustness | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| sparsity | 1 | 0 | 1 | 0 | 0.5 | 0 | 0 |
| level of detail | 0 | 0 | 0 | 1 | 0.5 | 1 | 1 |
| confidentiality | 0.5 | 0.5 | 1 | 0 | 0.5 | 0 | 0 |
| traceability | 1 | 1 | 0 | 1 | 1 | 1 | 1 |
| runtime performance and implementation constraints | 1 | 1 | 0 | 1 | 0 | 1 | 0 |

B1 covers GDPR Articles 13–15 and 22, AIA Article 86 and MiFID II Article 25; B2, DSA Article 17; B3, DSA Article 27 and P2B Article 5; B4, AIA Articles 13–14; B5, MDR Article 10(11) and Annex I; B6, MiFID II Article 17; B7, AIA Article 11 and Annex IV.

## Joint sensitivity analysis

Each draw perturbs every method-property integer by a discrete uniform offset from -2 through 2, then clips to [1,5]. A method's perturbed property vector is shared across legal contexts. Positive legal weights are multiplied by independent uniform factors from 0.75 to 1.25 and clipped to [0,1]; zero weights remain zero. Property priorities are log-uniform between 0.5 and 2. Thresholds are independently selected from 2, 3 and 4. The draw score is the mean of the soft, thresholded and geometric scores. Priorities enter the geometric view. Procedural characteristics remain fixed.

Top-rank probabilities count all tied winners. Winner retention is the probability that at least one default arithmetic winner remains top-ranked in a draw. Context summaries average question-specific retention probabilities. `question_scores.csv` identifies the all-method and model-agnostic comparisons separately. The manuscript's principal winner table uses the fourteen model-agnostic profiles. The sensitivity figure and retention table use all eligible profiles. A method with no competitor is always retained; candidate counts accompany the heatmap.

`joint_draw_scores.npz` contains one draws-by-method array per context. Method order and context order are in `sensitivity_summary.json`. The expert analysis uses these same draws. The seed and draw count are recorded in `replication_provenance.json`.


## Legal-task sensitivity

`methods_scoring/inputs/legal_task_variants.json` specifies seven endpoint pairs: B1 efficiency 0.5–1, B4 efficiency 0.75–1, B6 efficiency 0.5–1, MDR sparsity and level of detail 0.25–0.75, and B1 and B2 stability 0 or 1. `methods_scoring/inputs/legal_task_cases.json` contains their 128 combinations and four MDR task profiles. Method ratings, eligibility, threshold 3 and priority 1 remain fixed for these evaluations. These task alternatives are separate from the random joint draws.

The patient profile pairs sparsity 0.75 with level of detail 0.25. The professional profile pairs sparsity 0.25 with level of detail 0.75. Both use confidentiality weight 0.5 and runtime performance weight 0. Interactive profiles retain the default recipient weights and give runtime 0.75 or 1. The profiles are analytical comparisons of recipient and delivery requirements.

`analysis/legal_task_sensitivity.csv` records every case, question, score view, winner set, maximum score, exact winner-set agreement and retention of at least one default winner. `analysis/legal_task_sensitivity_summary.json` summarises the endpoint combinations. Outside MDR, the soft and geometric winner sets remain unchanged in both catalogues across the endpoint combinations. The thresholded score can change the full-catalogue feature-winner set in B1. Within MDR, patient instructions favour Integrated Gradients under the full-catalogue soft and geometric scores; professional instructions favour RuleFit and RuleSHAP. Model-agnostic feature winners remain RuleFit and RuleSHAP under the soft and geometric scores and Exact local SHAP under the thresholded score. The thresholded rule winners are RuleFit and RuleSHAP for patients and PDP for professionals. Interactive instructions select RuleFit for the feature question under all three scores. All MDR profiles use confidentiality weight 0.5.

The following command evaluates every supplied case through the shared scoring functions and verifies the exported winners and scores. Run it from the package root:

```sh
python - <<'PY'
import sys, csv, json
from pathlib import Path
import numpy as np
sys.path.insert(0, 'methods_scoring')
import scoring as sc
cases = {c['case']: c['weights'] for c in json.loads(Path('methods_scoring/inputs/legal_task_cases.json').read_text())}
names = [n for n, m in sc.INPUTS['methods'].items() if not m.get('requires_model_replacement') and not m.get('component_only')]
x = sc.ratings(names)
with Path('methods_scoring/analysis/legal_task_sensitivity.csv').open() as f:
    for entry in csv.DictReader(f):
        weights = [cases[entry['case']][entry['bundle']][p] for p in sc.PROPERTIES]
        indices = [i for i, n in enumerate(names) if sc.eligible(n, entry['bundle'], entry['question'])]
        if entry['catalogue'] == 'agnostic':
            indices = [i for i in indices if sc.INPUTS['methods'][names[i]].get('type') == 'model-agnostic' or i < 14]
        values = sc.score_views(x, weights)[entry['view']][indices]
        winners = sorted(names[indices[i]] for i in np.flatnonzero(sc.winners(values)))
        assert '; '.join(winners) == entry['variant_winners']
        assert abs(float(values.max()) - float(entry['score'])) < 1e-10
print('All legal-task scores and winners verified.')
PY
```

## Input containers

`scoring.py`, `sensitivity_analysis.py` and `legal_expert_validation.py` read `inputs/paper_inputs.json`. They supply the legal-context comparisons, sensitivity results and expert concordances reported in the paper. `assess_xai_compliance.py` evaluates its embedded catalogue and legal vectors. Its method ratings agree with the JSON catalogue; its embedded legal vectors differ from the paper's default matrix. The collection interface also has its own instrument and inputs. Running the standalone example or collection interface therefore does not reproduce the paper's numerical comparisons.

## Reported expert results

With the default matrix, paired median primary concordance is 0.27 for each of the soft and geometric scores, 0.10 at threshold 2, 0.36 at threshold 3 and 0.51 at threshold 4. The paired final-ranking medians are 0.25, 0.25, 0.12, 0.46 and 0.57 in the same order. At threshold 4, adjusted permutation-test values are 0.326 for GDPR and 0.078 for MDR and the paired statistic.

The response database and method ratings are independent of the legal weight alternatives. `input_integrity.json` records their hashes and the hashes of executable files. `replication_provenance.json` identifies the inputs, commands, seed, draw count and software versions used for the exported results.

## Legal-expert responses

The SQLite database contains six sessions. The analytic cohort comprises completed sessions E08, E11, E13 and E18, all legal academics with relevant experience. E01 is incomplete. E02 has no recorded relevant experience and is excluded. Each included expert supplied four primary judgments in each of two contexts, giving 32 primary judgments and 32 comparison entries. Primary legal-goal judgments use a 1-7 ordinal scale; confidence uses 1-5. The analysis retains locked primary judgments and treats final comparison ranks separately.

Kendall tau-b accounts for ties. Within each context, formula scores are compared with each expert's four primary ratings. The context statistic is the median of the four per-expert concordances. The paired statistic first averages each expert's concordances across contexts, then takes the median across experts. For sensitivity, each expert's median concordance across draws is computed before the median across experts. The paired sensitivity statistic averages contexts within each expert and draw before these medians.

Exploratory one-sided exact permutation tests permute method labels independently within each expert and context. Each context has four alternatives, giving 24 permutations per expert. The paired test combines independent permutations for the different context-specific method sets. Frequency-compressed exact distributions avoid enumerating every assignment explicitly. Benjamini-Hochberg adjustment includes five formula views and three context summaries, totalling 15 comparisons. `exploratory_permutation_tests.csv` reports every p and adjusted q value.

Comparison-stage concordance uses explicit final ranks rather than revised numeric judgments. `comparison_stage_concordance.csv` reports both concordance and the count of changed legal-goal ratings. The source database is opened read-only. Its content hash is checked before and after the full analysis.

`qualitative_annotations.json` contains 32 manually coded primary rationales. The binary code identifies language about faithfulness, robustness, completeness, coverage, detail, sparsity, confidentiality, traceability or efficiency. The code describes wording in the response; it does not measure causal dependence on the technical memo. One coder assigned these labels. The script exports the annotations and computes the frequency, 27 of 32. The required content-only confirmation in the interface explains the 32 recorded confirmations.

## Instrument and collection application

`user_study/ui/app.py` serves the interface and JSON endpoints. `study_service.py` stores orientation, primary judgments, final rankings, checklists, feedback and events in SQLite. `study_core.py` validates the instrument. `framework_scoring.py` computes clinical catalogue scores. Static assets include the participant, workflow and administrative interfaces. Primary judgments are locked before comparative review; comparative responses preserve primary values separately. The source-derived checklists follow comparative review.

The application configuration includes recruitment targets for prospective collection. The recorded four-person cohort is analysed under the eligibility rule stated above. `user_study/data/audit/data_audit.json` reports the database instrument hash and the packaged instrument hash. The hashes differ. The recorded database cannot be reused for collection with this instrument because the server rejects a populated database with a different hash. Use a new demo database for interface inspection. For institutional collection, use the server's live mode, Waitress, an HTTPS reverse proxy, fresh secret and administrator token, and the instrument manifest workflow described by `user_study/ui/freeze_study.py --help`.

## Technical benchmark

`user_study/ui/scripts/run_empirical_benchmark.py` fits a random forest on a fixed partition of the Wisconsin Diagnostic Breast Cancer dataset, saves the fitted model, computes predictive metrics, generates explanation outputs and evaluates technical measurements. The pinned benchmark requirements include SHAP, scikit-learn and joblib. Local SHAP, PDP, a tree surrogate and a continuous-feature LIME implementation are evaluated. LIME uses Gaussian perturbations in standardized space, a square-root exponential kernel, highest-weight feature selection and ridge regression. Its calibration grid and cross-case metrics are exported separately.

Measurements include local fidelity, reference top-four overlap, feature-rank agreement, reference mass coverage, repeatability, behaviour under near-equivalent inputs, stress inputs, parameter variation and computation time. `benchmark_summary.csv` describes the displayed case. `cross_case_test_metrics.csv` gives held-out-case measurements. `lime_calibration_grid.csv` gives the tuning comparisons. `case_study.json` contains case inputs and explanation outputs. `preliminary_technical_report.json` describes predictive and explanation results. Empirical measurements and the 312 literature-based ratings are distinct inputs.

## Outputs and reproducibility

`replicate.py` runs numerical analyses, exports the cohort and qualitative audit, and produces PDF figures. `--manuscript-dir` copies only figures into the manuscript's native `figures` directory. Source table definitions remain inline. Static diagrams are rendered from their source geometry using Matplotlib; study stimuli retain their image content. Survey-count plots are computed from `methods_scoring/inputs/survey_counts.json`. Input SHA-256 hashes, Python and package versions, seed and draw count are written to `provenance.json`.

Numerical outputs are written to `methods_scoring/analysis` and `user_study/data/analysis`. The cohort audit is written to `user_study/data/audit`, and PDF figures to `methods_scoring/figures`.

The default analysis requires NumPy, pandas, SciPy, Matplotlib, Pillow and PyMuPDF. The optional benchmark requires its separate dependency set. Tests cover aggregation, procedural filtering, shared perturbations, tie-aware concordance and study collection logic. The validation record states which commands ran and their results.

## Score-specific evidence

Each entry below gives the property, score, interpretation and primary-source location. Bibliography keys match the manuscript. URLs are resolved through `methods_scoring/inputs/literature_sources.json`.

### Decision Trees

- **no_false_positives (3/5):** Surrogate agreement requires validation; predictive overfitting does not establish explanation false positives. Source: `scoreTreeDocs`, classification, complexity and practical tips. https://scikit-learn.org/stable/modules/tree.html
- **no_false_negatives (3/5):** A compressed surrogate can omit black-box effects; no general recall ranking against RuleFit is established. Source: `scoreTreeDocs`, classification, complexity and practical tips. https://scikit-learn.org/stable/modules/tree.html
- **completeness (3/5):** Surrogate paths cover the fitted tree; agreement with the explained predictor determines rationale coverage. Source: `scoreTreeDocs`, classification, complexity and practical tips. https://scikit-learn.org/stable/modules/tree.html
- **stability (1/5):** Crossing a split abruptly changes the path, giving low input stability for path-based use of surrogate rules. Source: `scoreTreeDocs`, classification, complexity and practical tips. https://scikit-learn.org/stable/modules/tree.html
- **adversarial_robustness (2/5):** Threshold discontinuities create sensitivity; this is a structural inference, not a universal attack benchmark. Source: `scoreTreeDocs`, classification, complexity and practical tips. https://scikit-learn.org/stable/modules/tree.html
- **consistency (2/5):** Resampling outputs from a fixed predictor can change the fitted surrogate structure. Source: `scoreTreeDocs`, classification, complexity and practical tips. https://scikit-learn.org/stable/modules/tree.html
- **hyperparameters_perturbation_robustness (2/5):** Depth, pruning and leaf-size changes can materially change explanations. Source: `scoreTreeDocs`, classification, complexity and practical tips. https://scikit-learn.org/stable/modules/tree.html
- **sparsity (3/5):** A pruned tree can be compact, but path and tree size remain tunable. Source: `scoreTreeDocs`, classification, complexity and practical tips. https://scikit-learn.org/stable/modules/tree.html
- **level_of_detail (5/5):** Explicit predicates and leaf outcomes provide the catalogue's highest rule-level detail. Source: `scoreTreeDocs`, classification, complexity and practical tips. https://scikit-learn.org/stable/modules/tree.html
- **confidentiality (2/5):** Publishing splits exposes proprietary logic; this threat-model assumption is not a measured privacy loss. Source: `scoreTreeDocs`, classification, complexity and practical tips. https://scikit-learn.org/stable/modules/tree.html
- **traceability (4/5):** Stored tree, training data, seed and parameters permit reconstruction. Source: `scoreTreeDocs`, classification, complexity and practical tips. https://scikit-learn.org/stable/modules/tree.html
- **runtime_performance_and_implementation_constraints (4/5):** Ordinary tree fitting and inference are comparatively inexpensive; surrogate-data collection cost still matters. Source: `scoreTreeDocs`, classification, complexity and practical tips. https://scikit-learn.org/stable/modules/tree.html

### RuleFit

- **no_false_positives (3/5):** Surrogate training does not guarantee agreement with the target model. Source: `friedman2008predictive`, rule-ensemble construction and regularised fitting. https://arxiv.org/abs/0811.1679
- **no_false_negatives (3/5):** Sparse term selection can omit influences of the explained predictor. Source: `friedman2008predictive`, rule-ensemble construction and regularised fitting. https://arxiv.org/abs/0811.1679
- **completeness (4/5):** Rules and linear terms express interactions and linear trends; broader representational coverage than a simple tree is plausible. Source: `friedman2008predictive`, rule-ensemble construction and regularised fitting. https://arxiv.org/abs/0811.1679
- **stability (3/5):** Regularisation constrains fitting, while selected rules remain data-dependent. Source: `friedman2008predictive`, rule-ensemble construction and regularised fitting. https://arxiv.org/abs/0811.1679
- **adversarial_robustness (3/5):** Predictive performance does not establish attack resistance; no general advantage is established. Source: `friedman2008predictive`, rule-ensemble construction and regularised fitting. https://arxiv.org/abs/0811.1679
- **consistency (3/5):** Different samples can select different rules; deterministic optimization alone is insufficient. Source: `friedman2008predictive`, rule-ensemble construction and regularised fitting. https://arxiv.org/abs/0811.1679
- **hyperparameters_perturbation_robustness (3/5):** Penalty strength and rule-generation choices affect the selected ensemble. Source: `friedman2008predictive`, rule-ensemble construction and regularised fitting. https://arxiv.org/abs/0811.1679
- **sparsity (3/5):** The final L1-selected ensemble can be compact, although many terms may remain. Source: `friedman2008predictive`, rule-ensemble construction and regularised fitting. https://arxiv.org/abs/0811.1679
- **level_of_detail (4/5):** Predicates and coefficients reveal detailed surrogate structure. Source: `friedman2008predictive`, rule-ensemble construction and regularised fitting. https://arxiv.org/abs/0811.1679
- **confidentiality (2/5):** Disclosed rules expose model logic; use the same threat-model assumption as the surrogate tree. Source: `friedman2008predictive`, rule-ensemble construction and regularised fitting. https://arxiv.org/abs/0811.1679
- **traceability (4/5):** The fitted rule list and pipeline can be archived and inspected. Source: `friedman2008predictive`, rule-ensemble construction and regularised fitting. https://arxiv.org/abs/0811.1679
- **runtime_performance_and_implementation_constraints (3/5):** Rule generation plus sparse regression adds work relative to a single tree. Source: `friedman2008predictive`, rule-ensemble construction and regularised fitting. https://arxiv.org/abs/0811.1679

### RuleSHAP

- **no_false_positives (3/5):** Injected-rule recovery evaluates known-rule ranking; the validity of every returned predicate remains unresolved. Source: `scoreRuleSHAP2025`, Secs. 4--6, Table 2 and Appendix G. https://arxiv.org/html/2505.11189v1
- **no_false_negatives (4/5):** Known-rule recovery ranks improve over RuleFit in the injected-bias experiment, supporting a qualified comparative 4 versus 3. Source: `scoreRuleSHAP2025`, Secs. 4--6, Table 2 and Appendix G. https://arxiv.org/html/2505.11189v1
- **completeness (4/5):** Rule ensembles represent compound conditions and linear trends more extensively than a single surrogate tree. Source: `scoreRuleSHAP2025`, Secs. 4--6, Table 2 and Appendix G. https://arxiv.org/html/2505.11189v1
- **stability (3/5):** Matched input-stability evidence for the rule-induction pipeline is limited. Source: `scoreRuleSHAP2025`, Secs. 4--6, Table 2 and Appendix G. https://arxiv.org/html/2505.11189v1
- **adversarial_robustness (3/5):** Attack-resistance evidence for SHAP-guided rule induction is limited. Source: `scoreRuleSHAP2025`, Secs. 4--6, Table 2 and Appendix G. https://arxiv.org/html/2505.11189v1
- **consistency (3/5):** Sampling and attribution steps create multiple sources of repeated-fit variation. Source: `scoreRuleSHAP2025`, Secs. 4--6, Table 2 and Appendix G. https://arxiv.org/html/2505.11189v1
- **hyperparameters_perturbation_robustness (3/5):** Rule and attribution choices affect induction; comparative parameter-sweep evidence is limited. Source: `scoreRuleSHAP2025`, Secs. 4--6, Table 2 and Appendix G. https://arxiv.org/html/2505.11189v1
- **sparsity (3/5):** Selected rules improve compactness, but no universal minimal-rule guarantee follows. Source: `scoreRuleSHAP2025`, Secs. 4--6, Table 2 and Appendix G. https://arxiv.org/html/2505.11189v1
- **level_of_detail (4/5):** Explicit learned predicates retain rule-level detail. Source: `scoreRuleSHAP2025`, Secs. 4--6, Table 2 and Appendix G. https://arxiv.org/html/2505.11189v1
- **confidentiality (2/5):** Rule disclosure exposes logic; confidentiality depends on access and disclosure controls. Source: `scoreRuleSHAP2025`, Secs. 4--6, Table 2 and Appendix G. https://arxiv.org/html/2505.11189v1
- **traceability (3/5):** Reconstruction requires linking attribution, rule generation and weighting records across the pipeline. Source: `scoreRuleSHAP2025`, Secs. 4--6, Table 2 and Appendix G. https://arxiv.org/html/2505.11189v1
- **runtime_performance_and_implementation_constraints (2/5):** SHAP computation adds cost to the rule-fitting pipeline. Source: `scoreRuleSHAP2025`, Secs. 4--6, Table 2 and Appendix G. https://arxiv.org/html/2505.11189v1

### PDP

- **no_false_positives (3/5):** Model evaluations reflect marginal responses, but correlated-feature extrapolation can mislead interpretation. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **no_false_negatives (3/5):** Population averaging hides effects that differ among examples, supporting a neutral contributor-coverage judgment. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **completeness (3/5):** Low-dimensional response curves cover selected effects; their coverage matches ICE when features and reference examples match. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **stability (4/5):** Averaging smooths individual response variation relative to ICE over a fixed reference population. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **adversarial_robustness (3/5):** Population aggregation has limited attack-resistance evidence. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **consistency (4/5):** The fixed model is evaluated directly over a declared grid/reference cohort, with no fitted stochastic surrogate. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **hyperparameters_perturbation_robustness (4/5):** Ordinary fixed grids have few tuning choices relative to fitted local surrogates. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **sparsity (2/5):** Showing response functions for many features produces an extensive display. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **level_of_detail (4/5):** One- and two-way response surfaces expose response shape and selected interactions; the rating does not describe full decision rules. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **confidentiality (3/5):** Aggregate outputs are not inherently private; neutral is not a privacy assurance. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **traceability (4/5):** Logged grid, model and reference dataset permit straightforward recomputation. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **runtime_performance_and_implementation_constraints (4/5):** Low-dimensional grids require fewer evaluations than repeated counterfactual optimisation. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2

### ICE

- **no_false_positives (3/5):** Direct model queries give feature-response information; impossible feature combinations remain a limitation. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **no_false_negatives (4/5):** Individual curves reveal heterogeneous effects hidden by PDP averaging. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **completeness (3/5):** ICE retains the individual curves whose mean produces PDP, giving equal partial-effect coverage under matched inputs. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **stability (3/5):** Curve changes follow the model; stochastic noise is not inherent in fixed-grid ICE. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **adversarial_robustness (3/5):** Direct evaluation alone supplies no general protection against malicious perturbations. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **consistency (4/5):** The fixed model is evaluated directly over a declared grid/reference cohort, with no fitted stochastic surrogate. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **hyperparameters_perturbation_robustness (4/5):** Fixed-grid construction has few tuning choices, as in PDP. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **sparsity (2/5):** Many overlaid individual curves are dense. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **level_of_detail (4/5):** Per-record response trajectories reveal more detail than population averaging. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **confidentiality (2/5):** Individual records or response trajectories can expose sensitive information; contextual disclosure-risk inference. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **traceability (4/5):** No inherent randomness prevents tracing fixed-grid model evaluations. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2
- **runtime_performance_and_implementation_constraints (4/5):** PDP and ICE share prediction evaluations for matched grids and reference examples. Source: `goldstein2015peeking`, Secs. 2--4. https://arxiv.org/html/1309.6392v2

### LIME

- **no_false_positives (2/5):** Imperfect local fitting and correlated proxies can assign misleading feature contributions. Source: `DBLP:conf/kdd/Ribeiro0G16`, Sec. 3. https://arxiv.org/abs/1602.04938
- **no_false_negatives (2/5):** Sparse local fitting can miss nonlinear effects and omitted contributors. Source: `DBLP:conf/kdd/Ribeiro0G16`, Sec. 3. https://arxiv.org/abs/1602.04938
- **completeness (2/5):** The explanation covers a neighborhood, not the full decision function. Source: `DBLP:conf/kdd/Ribeiro0G16`, Sec. 3. https://arxiv.org/abs/1602.04938
- **stability (1/5):** Unstabilised local fitting shows severe input sensitivity in nonlinear image experiments; the low ordinal anchor follows that variant. Source: `scoreRobust2018`, Secs. 2--3, Figures 2--6. https://arxiv.org/pdf/1806.08049
- **adversarial_robustness (1/5):** Off-distribution sampling enables demonstrated manipulation of LIME explanations. Source: `DBLP:conf/aies/SlackHJSL20`, scaffolded-classifier experiments. https://arxiv.org/pdf/1911.02508
- **consistency (2/5):** Sampled fitting varies across runs; repeated-rank experiments support the same below-neutral bin as sampled SHAP. Source: `man2020best`, Secs. 2--3 and 5. https://arxiv.org/pdf/2005.12483
- **hyperparameters_perturbation_robustness (1/5):** Neighbourhood and feature-selection choices strongly affect the fitted surrogate. Source: `DBLP:conf/kdd/Ribeiro0G16`, Sec. 3. https://arxiv.org/abs/1602.04938
- **sparsity (3/5):** User-selected feature counts constrain size while allowing a range of fit-size trade-offs. Source: `DBLP:conf/kdd/Ribeiro0G16`, Sec. 3. https://arxiv.org/abs/1602.04938
- **level_of_detail (2/5):** Sparse linear coefficients give less interaction and predicate detail than explicit rules. Source: `DBLP:conf/kdd/Ribeiro0G16`, Sec. 3. https://arxiv.org/abs/1602.04938
- **confidentiality (3/5):** Local outputs can reveal sensitive behavior; neutral does not assert confidentiality. Source: `DBLP:conf/kdd/Ribeiro0G16`, Sec. 3. https://arxiv.org/abs/1602.04938
- **traceability (3/5):** Reconstruction requires the sampled neighbourhood, random state and fitted surrogate as well as the predictor and input. Source: `DBLP:conf/kdd/Ribeiro0G16`, Sec. 3. https://arxiv.org/abs/1602.04938
- **runtime_performance_and_implementation_constraints (3/5):** Repeated queries and a small regression are moderately costly; no fixed runtime ratio to KernelSHAP is asserted. Source: `DBLP:conf/kdd/Ribeiro0G16`, Sec. 3. https://arxiv.org/abs/1602.04938

### Anchors

- **no_false_positives (3/5):** Conditional rule precision concerns prediction retention; necessity of each predicate remains unresolved. Source: `DBLP:conf/aaai/Ribeiro0G18`, anchor definition and search procedure. https://homes.cs.washington.edu/~marcotcr/aaai18.pdf
- **no_false_negatives (3/5):** A sufficient rule need not enumerate all contributors; conditional precision is not feature-recall evidence. Source: `DBLP:conf/aaai/Ribeiro0G18`, anchor definition and search procedure. https://homes.cs.washington.edu/~marcotcr/aaai18.pdf
- **completeness (3/5):** The rule describes the region it covers, giving partial decision-rationale coverage. Source: `DBLP:conf/aaai/Ribeiro0G18`, anchor definition and search procedure. https://homes.cs.washington.edu/~marcotcr/aaai18.pdf
- **stability (1/5):** Local rule selection changes with the sampled neighbourhood. Source: `DBLP:conf/aaai/Ribeiro0G18`, anchor definition and search procedure. https://homes.cs.washington.edu/~marcotcr/aaai18.pdf
- **adversarial_robustness (3/5):** A probabilistic precision target is not an adversarial robustness guarantee. Source: `DBLP:conf/aaai/Ribeiro0G18`, anchor definition and search procedure. https://homes.cs.washington.edu/~marcotcr/aaai18.pdf
- **consistency (1/5):** Stochastic rule search can return different conditions across runs. Source: `DBLP:conf/aaai/Ribeiro0G18`, anchor definition and search procedure. https://homes.cs.washington.edu/~marcotcr/aaai18.pdf
- **hyperparameters_perturbation_robustness (2/5):** Precision target, discretization and sampling budget influence rule selection. Source: `DBLP:conf/aaai/Ribeiro0G18`, anchor definition and search procedure. https://homes.cs.washington.edu/~marcotcr/aaai18.pdf
- **sparsity (4/5):** Search favors concise rules; 4 replaces an unsupported universal minimality score of 5. Source: `DBLP:conf/aaai/Ribeiro0G18`, anchor definition and search procedure. https://homes.cs.washington.edu/~marcotcr/aaai18.pdf
- **level_of_detail (3/5):** A conjunction provides feature predicates, but not the model's complete branching structure. Source: `DBLP:conf/aaai/Ribeiro0G18`, anchor definition and search procedure. https://homes.cs.washington.edu/~marcotcr/aaai18.pdf
- **confidentiality (3/5):** Released local rules expose behaviour; protection depends on disclosure controls. Source: `DBLP:conf/aaai/Ribeiro0G18`, anchor definition and search procedure. https://homes.cs.washington.edu/~marcotcr/aaai18.pdf
- **traceability (3/5):** Reconstruction requires the sampled neighbourhood, random state and fitted surrogate as well as the predictor and input. Source: `DBLP:conf/aaai/Ribeiro0G18`, anchor definition and search procedure. https://homes.cs.washington.edu/~marcotcr/aaai18.pdf
- **runtime_performance_and_implementation_constraints (3/5):** Precision estimation and rule search require repeated prediction queries. Source: `DBLP:conf/aaai/Ribeiro0G18`, anchor definition and search procedure. https://homes.cs.washington.edu/~marcotcr/aaai18.pdf

### CEM

- **no_false_positives (3/5):** Prediction retention by pertinent positives concerns sufficiency; necessity of each selected factor remains unresolved. Source: `DBLP:conf/nips/DhurandharCLTTS18`, Sec. 3.3 and Appendix A. https://arxiv.org/pdf/1802.07623
- **no_false_negatives (3/5):** Omissions depend on the contrast and feature representation. Source: `DBLP:conf/nips/DhurandharCLTTS18`, Sec. 3.3 and Appendix A. https://arxiv.org/pdf/1802.07623
- **completeness (4/5):** Pertinent positives and negatives provide two complementary contrasts. Source: `DBLP:conf/nips/DhurandharCLTTS18`, Sec. 3.3 and Appendix A. https://arxiv.org/pdf/1802.07623
- **stability (2/5):** the sparse optimum can switch under nearby inputs, supporting below-neutral stability. Source: `DBLP:conf/nips/DhurandharCLTTS18`, Sec. 3.3 and Appendix A. https://arxiv.org/pdf/1802.07623
- **adversarial_robustness (3/5):** Prediction validity is distinct from attack resistance; neutral replaces an unsupported strength. Source: `DBLP:conf/nips/DhurandharCLTTS18`, Sec. 3.3 and Appendix A. https://arxiv.org/pdf/1802.07623
- **consistency (3/5):** The published solver starts at zero, reducing random variation; comparative repeated-fit evidence is limited. Source: `DBLP:conf/nips/DhurandharCLTTS18`, Sec. 3.3 and Appendix A. https://arxiv.org/pdf/1802.07623
- **hyperparameters_perturbation_robustness (1/5):** Loss weight, sparsity penalty, manifold regularization, margin, and optimization budget can change which PP/PN set is returned. Source: `DBLP:conf/nips/DhurandharCLTTS18`, Sec. 3.3 and Appendix A. https://arxiv.org/pdf/1802.07623
- **sparsity (4/5):** Regularized perturbations favor compact evidence; sparsity is optimized rather than guaranteed. Source: `DBLP:conf/nips/DhurandharCLTTS18`, Sec. 3.3 and Appendix A. https://arxiv.org/pdf/1802.07623
- **level_of_detail (3/5):** Changed or retained features give a concrete contrast rather than full model structure. Source: `DBLP:conf/nips/DhurandharCLTTS18`, Sec. 3.3 and Appendix A. https://arxiv.org/pdf/1802.07623
- **confidentiality (3/5):** Local evidence lacks inherent privacy protection. Source: `DBLP:conf/nips/DhurandharCLTTS18`, Sec. 3.3 and Appendix A. https://arxiv.org/pdf/1802.07623
- **traceability (3/5):** Reconstruction requires the sampled neighbourhood, random state and fitted surrogate as well as the predictor and input. Source: `DBLP:conf/nips/DhurandharCLTTS18`, Sec. 3.3 and Appendix A. https://arxiv.org/pdf/1802.07623
- **runtime_performance_and_implementation_constraints (2/5):** Two optimization tasks and possible manifold regularization impose substantial explanation cost. Source: `DBLP:conf/nips/DhurandharCLTTS18`, Sec. 3.3 and Appendix A. https://arxiv.org/pdf/1802.07623

### DiCE

- **no_false_positives (3/5):** Counterfactual validity establishes an output-changing edit; factor necessity depends on the selected contrast. Source: `DBLP:conf/fat/MothilalST20`, Secs. 3--5. https://arxiv.org/html/1905.07697v2
- **no_false_negatives (3/5):** Diverse valid counterfactuals explore alternative outcomes but do not identify every influence on the actual prediction. Source: `DBLP:conf/fat/MothilalST20`, Secs. 3--5. https://arxiv.org/html/1905.07697v2
- **completeness (3/5):** Diversity improves local boundary coverage but is not a complete model rationale. Source: `DBLP:conf/fat/MothilalST20`, Secs. 3--5. https://arxiv.org/html/1905.07697v2
- **stability (1/5):** Sampling or optimization choices can produce substantially different outputs. Source: `DBLP:conf/fat/MothilalST20`, Secs. 3--5. https://arxiv.org/html/1905.07697v2
- **adversarial_robustness (3/5):** A valid counterfactual can fail under model change; adversarial robustness is not established by its validity objective. Source: `DBLP:conf/fat/MothilalST20`, Secs. 3--5. https://arxiv.org/html/1905.07697v2
- **consistency (1/5):** Sampling or optimization choices can produce substantially different outputs. Source: `DBLP:conf/fat/MothilalST20`, Secs. 3--5. https://arxiv.org/html/1905.07697v2
- **hyperparameters_perturbation_robustness (1/5):** Sampling or optimization choices can produce substantially different outputs. Source: `DBLP:conf/fat/MothilalST20`, Secs. 3--5. https://arxiv.org/html/1905.07697v2
- **sparsity (4/5):** Proximity and postprocessing favor few changes; minimality is conditional, not guaranteed. Source: `DBLP:conf/fat/MothilalST20`, Secs. 3--5. https://arxiv.org/html/1905.07697v2
- **level_of_detail (3/5):** Concrete feature changes give feature-level explanatory detail. Source: `DBLP:conf/fat/MothilalST20`, Secs. 3--5. https://arxiv.org/html/1905.07697v2
- **confidentiality (3/5):** Candidate outputs can reveal sensitive behavior; no default privacy guarantee. Source: `DBLP:conf/fat/MothilalST20`, Secs. 3--5. https://arxiv.org/html/1905.07697v2
- **traceability (3/5):** Reconstruction requires the sampled neighbourhood, random state and fitted surrogate as well as the predictor and input. Source: `DBLP:conf/fat/MothilalST20`, Secs. 3--5. https://arxiv.org/html/1905.07697v2
- **runtime_performance_and_implementation_constraints (3/5):** Finite candidate generation has moderate assumed cost; algorithm and dimensionality can change this rating. Source: `DBLP:conf/fat/MothilalST20`, Secs. 3--5. https://arxiv.org/html/1905.07697v2

### ProtoDash

- **no_false_positives (3/5):** Prototype representativeness concerns feature-space similarity; asserted model influence requires behavioural evidence. Source: `DBLP:conf/icdm/GurumoorthyDCA19`, weighted prototype objective and greedy algorithm. https://arxiv.org/abs/1707.01212
- **no_false_negatives (3/5):** A finite prototype set can miss rare patterns, and distributional coverage is not recall of all model influences. Source: `DBLP:conf/icdm/GurumoorthyDCA19`, weighted prototype objective and greedy algorithm. https://arxiv.org/abs/1707.01212
- **completeness (2/5):** Distributional representation is partial, not full decision rationale. Source: `DBLP:conf/icdm/GurumoorthyDCA19`, weighted prototype objective and greedy algorithm. https://arxiv.org/abs/1707.01212
- **stability (3/5):** Approximation guarantees for selection quality do not imply input stability. Source: `DBLP:conf/icdm/GurumoorthyDCA19`, weighted prototype objective and greedy algorithm. https://arxiv.org/abs/1707.01212
- **adversarial_robustness (3/5):** No general explanation attack evaluation establishes high or low resistance. Source: `DBLP:conf/icdm/GurumoorthyDCA19`, weighted prototype objective and greedy algorithm. https://arxiv.org/abs/1707.01212
- **consistency (3/5):** Fixed inputs and tie rules enable repeatability, without guaranteeing sample-to-sample consistency. Source: `DBLP:conf/icdm/GurumoorthyDCA19`, weighted prototype objective and greedy algorithm. https://arxiv.org/abs/1707.01212
- **hyperparameters_perturbation_robustness (3/5):** Kernel, bandwidth and prototype count alter the selected representatives. Source: `DBLP:conf/icdm/GurumoorthyDCA19`, weighted prototype objective and greedy algorithm. https://arxiv.org/abs/1707.01212
- **sparsity (4/5):** A small weighted subset explicitly promotes compact representation. Source: `DBLP:conf/icdm/GurumoorthyDCA19`, weighted prototype objective and greedy algorithm. https://arxiv.org/abs/1707.01212
- **level_of_detail (3/5):** Representative records show examples, not full decision rules. Source: `DBLP:conf/icdm/GurumoorthyDCA19`, weighted prototype objective and greedy algorithm. https://arxiv.org/abs/1707.01212
- **confidentiality (2/5):** Releasing actual prototypes can disclose source records; assumes unprotected examples are shown. Source: `DBLP:conf/icdm/GurumoorthyDCA19`, weighted prototype objective and greedy algorithm. https://arxiv.org/abs/1707.01212
- **traceability (4/5):** Selection steps, weights, kernel and candidates can be archived. Source: `DBLP:conf/icdm/GurumoorthyDCA19`, weighted prototype objective and greedy algorithm. https://arxiv.org/abs/1707.01212
- **runtime_performance_and_implementation_constraints (3/5):** Greedy selection avoids exhaustive subset search; no universal quadratic-cost verdict is justified. Source: `DBLP:conf/icdm/GurumoorthyDCA19`, weighted prototype objective and greedy algorithm. https://arxiv.org/abs/1707.01212

### Exact local SHAP

- **no_false_positives (3/5):** Exact allocation concerns the coalition game; feature relevance can differ under decision-based relevance definitions. Source: `scoreRelevance2023`, Secs. 6--7. https://arxiv.org/pdf/2302.08160
- **no_false_negatives (3/5):** Exact allocation can assign zero to decision-relevant features, motivating neutral contributor coverage. Source: `scoreRelevance2023`, Secs. 6--7. https://arxiv.org/pdf/2302.08160
- **completeness (3/5):** Additive allocation covers the output difference; interactions are compressed into feature contributions. Source: `DBLP:conf/nips/LundbergL17`, Secs. 2--5. https://arxiv.org/html/1705.07874v2
- **stability (3/5):** Exact computation does not imply continuity under changes to inputs or background. Source: `DBLP:conf/nips/LundbergL17`, Secs. 2--5. https://arxiv.org/html/1705.07874v2
- **adversarial_robustness (3/5):** No general adversarial guarantee follows from Shapley axioms; neutral remains evidence-limited. Source: `DBLP:conf/nips/LundbergL17`, Secs. 2--5. https://arxiv.org/html/1705.07874v2
- **consistency (3/5):** Exact enumeration is repeatable for fixed inputs; matched cross-method repeatability evidence is limited. Source: `DBLP:conf/nips/LundbergL17`, Secs. 2--5. https://arxiv.org/html/1705.07874v2
- **hyperparameters_perturbation_robustness (3/5):** Masker and background define the allocation problem; neutral does not imply invariance to their choice. Source: `DBLP:conf/nips/LundbergL17`, Secs. 2--5. https://arxiv.org/html/1705.07874v2
- **sparsity (3/5):** Feature attributions can be dense or truncated for presentation. Source: `DBLP:conf/nips/LundbergL17`, Secs. 2--5. https://arxiv.org/html/1705.07874v2
- **level_of_detail (3/5):** Feature allocations provide intermediate detail, not explicit decision rules. Source: `DBLP:conf/nips/LundbergL17`, Secs. 2--5. https://arxiv.org/html/1705.07874v2
- **confidentiality (3/5):** Local exact attribution supplies no inherent privacy protection. Source: `DBLP:conf/nips/LundbergL17`, Secs. 2--5. https://arxiv.org/html/1705.07874v2
- **traceability (4/5):** A specified computation can be reconstructed if model, input, reference or propagation parameters and software versions are retained. Source: `DBLP:conf/nips/LundbergL17`, Secs. 2--5. https://arxiv.org/html/1705.07874v2
- **runtime_performance_and_implementation_constraints (1/5):** Generic enumeration is exponentially expensive; specialized exact tree/linear methods are excluded from this profile. Source: `scoreExactSHAPDocs`, ExactExplainer, computational complexity. https://shap.readthedocs.io/en/latest/generated/shap.ExactExplainer.html

### Approximate local SHAP

- **no_false_positives (3/5):** Approximation error and reference semantics affect assigned factors. Source: `scoreRelevance2023`, Secs. 6--7. https://arxiv.org/pdf/2302.08160
- **no_false_negatives (3/5):** Sampling can suppress contributions; exact allocation also has relevance counterexamples, leaving both variants in the neutral bin. Source: `scoreRelevance2023`, Secs. 6--7. https://arxiv.org/pdf/2302.08160
- **completeness (3/5):** Local reconstruction does not establish full explanatory coverage. Source: `scoreKernelSHAPDocs`, KernelExplainer, sampling and regression. https://shap.readthedocs.io/en/latest/generated/shap.KernelExplainer.html
- **stability (2/5):** Sampling introduces variation in addition to input and background sensitivity. Source: `scoreRobust2018`, Secs. 2--3, Figures 2--6. https://arxiv.org/pdf/1806.08049
- **adversarial_robustness (2/5):** Published perturbation-based attacks support a below-neutral rating for the sampled scenario. Source: `DBLP:conf/aies/SlackHJSL20`, scaffolded-classifier experiments. https://arxiv.org/pdf/1911.02508
- **consistency (2/5):** Finite-sample estimates can differ across runs; fixed-seed replay does not guarantee general consistency. Source: `man2020best`, Secs. 2--3 and 5. https://arxiv.org/pdf/2005.12483
- **hyperparameters_perturbation_robustness (2/5):** Budget, regularization and background can materially affect estimates. Source: `scoreKernelSHAPDocs`, KernelExplainer, sampling and regression. https://shap.readthedocs.io/en/latest/generated/shap.KernelExplainer.html
- **sparsity (3/5):** Approximate and exact outputs use feature vectors with tunable display size. Source: `scoreKernelSHAPDocs`, KernelExplainer, sampling and regression. https://shap.readthedocs.io/en/latest/generated/shap.KernelExplainer.html
- **level_of_detail (3/5):** Approximation preserves feature-level granularity. Source: `scoreKernelSHAPDocs`, KernelExplainer, sampling and regression. https://shap.readthedocs.io/en/latest/generated/shap.KernelExplainer.html
- **confidentiality (3/5):** Approximation supplies no confidentiality mechanism. Source: `scoreKernelSHAPDocs`, KernelExplainer, sampling and regression. https://shap.readthedocs.io/en/latest/generated/shap.KernelExplainer.html
- **traceability (4/5):** Stored sample masks, random state, predictor and parameters permit reconstruction. Source: `scoreKernelSHAPDocs`, KernelExplainer, sampling and regression. https://shap.readthedocs.io/en/latest/generated/shap.KernelExplainer.html
- **runtime_performance_and_implementation_constraints (2/5):** Sampling reduces generic exact enumeration cost but still requires repeated model evaluations. Source: `scoreKernelSHAPDocs`, KernelExplainer, sampling and regression. https://shap.readthedocs.io/en/latest/generated/shap.KernelExplainer.html

### Global SHAP summaries

- **no_false_positives (3/5):** Aggregation does not repair local relevance errors; neutral is conditional on representative inputs. Source: `scoreGlobalSHAPDocs`, global bar plots. https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/bar.html
- **no_false_negatives (3/5):** Population averaging may hide rare influential patterns. Source: `scoreGlobalSHAPDocs`, global bar plots. https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/bar.html
- **completeness (2/5):** Summary statistics omit individual configurations and interactions. Source: `scoreGlobalSHAPDocs`, global bar plots. https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/bar.html
- **stability (3/5):** Averaging may reduce variability, but cohort shifts remain; no universal stability guarantee. Source: `scoreGlobalSHAPDocs`, global bar plots. https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/bar.html
- **adversarial_robustness (3/5):** Attack-resistance evidence for population summaries is limited. Source: `scoreGlobalSHAPDocs`, global bar plots. https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/bar.html
- **consistency (3/5):** Changing the cohort can alter importance rankings even with reproducible local values. Source: `scoreGlobalSHAPDocs`, global bar plots. https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/bar.html
- **hyperparameters_perturbation_robustness (2/5):** Cohort, background, estimator and aggregation choices all affect results. Source: `scoreGlobalSHAPDocs`, global bar plots. https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/bar.html
- **sparsity (2/5):** Many-feature, many-observation displays are dense under this scenario. Source: `scoreGlobalSHAPDocs`, global bar plots. https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/bar.html
- **level_of_detail (3/5):** Aggregation preserves feature-level importance while compressing individual combinations. Source: `scoreGlobalSHAPDocs`, global bar plots. https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/bar.html
- **confidentiality (3/5):** Aggregation alone is not a privacy guarantee. Source: `scoreGlobalSHAPDocs`, global bar plots. https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/bar.html
- **traceability (4/5):** Stored cohort, local attributions and summary procedure permit reconstruction. Source: `scoreGlobalSHAPDocs`, global bar plots. https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/bar.html
- **runtime_performance_and_implementation_constraints (1/5):** Repeated local estimation across many records has high assumed cost; exact-input or optimized summaries require separate profiles. Source: `scoreGlobalSHAPDocs`, global bar plots. https://shap.readthedocs.io/en/latest/example_notebooks/api_examples/plots/bar.html

### LLM-assisted behavioral RuleSHAP (MechaRule stage 1)

- **no_false_positives (3/5):** Hypothesis scoring supports association, not causal necessity. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **no_false_negatives (3/5):** Proposed predicates can miss unrepresented behavioral triggers. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **completeness (3/5):** Selected rules cover task behavior, not all model logic. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **stability (2/5):** Feature proposals and fitted rules may vary. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **adversarial_robustness (3/5):** No explanation attack-resistance guarantee is established. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **consistency (2/5):** LLM proposals can change between runs. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **hyperparameters_perturbation_robustness (2/5):** Prompt, filtering and rule-selection parameters matter. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **sparsity (3/5):** Greedy selection promotes compactness without minimality guarantees. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **level_of_detail (4/5):** Executable predicates expose detailed behavioral conditions. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **confidentiality (2/5):** Prompts, outputs and extracted rules may be sensitive. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **traceability (3/5):** Stored proposals, predicate code and evaluation data link the rule to the sampled behaviour. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **runtime_performance_and_implementation_constraints (2/5):** LLM calls and rule fitting add computation. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1

### CAVs

- **no_false_positives (3/5):** A fitted direction associates concept examples with activations; semantic confounding leaves concept relevance uncertain. Source: `DBLP:conf/icml/KimWGCWVS18`, CAV construction and directional derivatives. https://arxiv.org/abs/1711.11279
- **no_false_negatives (2/5):** Only supplied concepts are tested; unspecified concepts can be missed. Source: `DBLP:conf/icml/KimWGCWVS18`, CAV construction and directional derivatives. https://arxiv.org/abs/1711.11279
- **completeness (2/5):** Concept directions do not recover the whole model rationale. Source: `DBLP:conf/icml/KimWGCWVS18`, CAV construction and directional derivatives. https://arxiv.org/abs/1711.11279
- **stability (2/5):** Concept examples and learned directions can change measured sensitivity. Source: `DBLP:conf/icml/KimWGCWVS18`, CAV construction and directional derivatives. https://arxiv.org/abs/1711.11279
- **adversarial_robustness (2/5):** Attacks on concept examples can alter directional sensitivity. Source: `brown2022corgis`, attacks on concept examples. https://arxiv.org/abs/2110.07120
- **consistency (3/5):** Repeated concept-set trials and significance checks help, but do not guarantee cross-dataset consistency. Source: `DBLP:conf/icml/KimWGCWVS18`, CAV construction and directional derivatives. https://arxiv.org/abs/1711.11279
- **hyperparameters_perturbation_robustness (1/5):** Concept-bank and layer choices strongly determine the measured direction. Source: `DBLP:conf/icml/KimWGCWVS18`, CAV construction and directional derivatives. https://arxiv.org/abs/1711.11279
- **sparsity (3/5):** Few concepts can be concise, but CAVs do not enforce a minimal concept set. Source: `DBLP:conf/icml/KimWGCWVS18`, CAV construction and directional derivatives. https://arxiv.org/abs/1711.11279
- **level_of_detail (2/5):** Concept-level abstraction is coarser than feature predicates; low detail is not a claim of low usefulness. Source: `DBLP:conf/icml/KimWGCWVS18`, CAV construction and directional derivatives. https://arxiv.org/abs/1711.11279
- **confidentiality (3/5):** Concept examples and scores require contextual disclosure controls. Source: `DBLP:conf/icml/KimWGCWVS18`, CAV construction and directional derivatives. https://arxiv.org/abs/1711.11279
- **traceability (3/5):** Reconstruction requires the sampled neighbourhood, random state and fitted surrogate as well as the predictor and input. Source: `DBLP:conf/icml/KimWGCWVS18`, CAV construction and directional derivatives. https://arxiv.org/abs/1711.11279
- **runtime_performance_and_implementation_constraints (3/5):** Fits concept classifiers on frozen activations; it does not require training the underlying neural network. Source: `DBLP:conf/icml/KimWGCWVS18`, CAV construction and directional derivatives. https://arxiv.org/abs/1711.11279

### DeepLift

- **no_false_positives (3/5):** Reference-based contributions are useful but do not establish absence of irrelevant features. Source: `DBLP:conf/icml/ShrikumarGK17`, reference differences and propagation rules. https://arxiv.org/abs/1704.02685
- **no_false_negatives (3/5):** Summation-to-delta does not prove every relevant factor is recovered. Source: `DBLP:conf/icml/ShrikumarGK17`, reference differences and propagation rules. https://arxiv.org/abs/1704.02685
- **completeness (3/5):** An additive decomposition relative to a reference is not the complete decision rationale. Source: `DBLP:conf/icml/ShrikumarGK17`, reference differences and propagation rules. https://arxiv.org/abs/1704.02685
- **stability (3/5):** Fixed references remove sampling variation; sensitivity to input and representation remains. Source: `DBLP:conf/icml/ShrikumarGK17`, reference differences and propagation rules. https://arxiv.org/abs/1704.02685
- **adversarial_robustness (2/5):** Reference and representation changes can alter contributions, supporting a below-neutral design-based robustness judgment. Source: `DBLP:series/lncs/KindermansHAASDEK19`, input-invariance counterexamples. https://arxiv.org/abs/1711.00867
- **consistency (3/5):** Fixed execution can repeat; cross-model consistency is not guaranteed by the attribution definition. Source: `DBLP:conf/icml/ShrikumarGK17`, reference differences and propagation rules. https://arxiv.org/abs/1704.02685
- **hyperparameters_perturbation_robustness (1/5):** Reference choice materially changes contribution allocation. Source: `DBLP:conf/icml/ShrikumarGK17`, reference differences and propagation rules. https://arxiv.org/abs/1704.02685
- **sparsity (3/5):** Feature attribution can be dense or truncated through display selection. Source: `DBLP:conf/icml/ShrikumarGK17`, reference differences and propagation rules. https://arxiv.org/abs/1704.02685
- **level_of_detail (3/5):** Feature contributions provide intermediate detail. Source: `DBLP:conf/icml/ShrikumarGK17`, reference differences and propagation rules. https://arxiv.org/abs/1704.02685
- **confidentiality (3/5):** Feature maps have no inherent privacy guarantee. Source: `DBLP:conf/icml/ShrikumarGK17`, reference differences and propagation rules. https://arxiv.org/abs/1704.02685
- **traceability (4/5):** Model, reference and propagation records support direct reconstruction of contributions. Source: `DBLP:conf/icml/ShrikumarGK17`, reference differences and propagation rules. https://arxiv.org/abs/1704.02685
- **runtime_performance_and_implementation_constraints (4/5):** A contribution backpropagation pass is cheaper than multi-baseline or multi-step integration approaches. Source: `DBLP:conf/icml/ShrikumarGK17`, reference differences and propagation rules. https://arxiv.org/abs/1704.02685

### DeepSHAP

- **no_false_positives (3/5):** Approximate propagation has no blanket guarantee of identifying only influential features. Source: `scoreDeepSHAPDocs`, DeepExplainer, background samples. https://shap.readthedocs.io/en/latest/generated/shap.DeepExplainer.html
- **no_false_negatives (3/5):** Approximation and reference choice can miss effects; no universal advantage over DeepLIFT is established. Source: `scoreDeepSHAPDocs`, DeepExplainer, background samples. https://shap.readthedocs.io/en/latest/generated/shap.DeepExplainer.html
- **completeness (3/5):** Expected-output reconstruction is distinct from complete explanatory coverage. Source: `scoreDeepSHAPDocs`, DeepExplainer, background samples. https://shap.readthedocs.io/en/latest/generated/shap.DeepExplainer.html
- **stability (3/5):** Fixed background execution need not be stochastic; background and input sensitivity remain. Source: `scoreDeepSHAPDocs`, DeepExplainer, background samples. https://shap.readthedocs.io/en/latest/generated/shap.DeepExplainer.html
- **adversarial_robustness (3/5):** Comparative attack-resistance evidence for the approximate propagation procedure is limited. Source: `scoreDeepSHAPDocs`, DeepExplainer, background samples. https://shap.readthedocs.io/en/latest/generated/shap.DeepExplainer.html
- **consistency (3/5):** Fixed references support repeatability; comparative repeated-computation evidence is limited. Source: `scoreDeepSHAPDocs`, DeepExplainer, background samples. https://shap.readthedocs.io/en/latest/generated/shap.DeepExplainer.html
- **hyperparameters_perturbation_robustness (2/5):** Background set and supported propagation operations affect results. Source: `scoreDeepSHAPDocs`, DeepExplainer, background samples. https://shap.readthedocs.io/en/latest/generated/shap.DeepExplainer.html
- **sparsity (3/5):** Feature attribution can be dense or truncated through display selection. Source: `scoreDeepSHAPDocs`, DeepExplainer, background samples. https://shap.readthedocs.io/en/latest/generated/shap.DeepExplainer.html
- **level_of_detail (3/5):** Per-feature contributions have comparable detail to DeepLIFT. Source: `scoreDeepSHAPDocs`, DeepExplainer, background samples. https://shap.readthedocs.io/en/latest/generated/shap.DeepExplainer.html
- **confidentiality (3/5):** No inherent privacy guarantee follows from background averaging. Source: `scoreDeepSHAPDocs`, DeepExplainer, background samples. https://shap.readthedocs.io/en/latest/generated/shap.DeepExplainer.html
- **traceability (4/5):** Stored background examples, predictor and propagation operators permit reconstruction. Source: `scoreDeepSHAPDocs`, DeepExplainer, background samples. https://shap.readthedocs.io/en/latest/generated/shap.DeepExplainer.html
- **runtime_performance_and_implementation_constraints (3/5):** Work scales with background examples; typically more than single-reference DeepLIFT. Source: `scoreDeepSHAPDocs`, DeepExplainer, background samples. https://shap.readthedocs.io/en/latest/generated/shap.DeepExplainer.html

### LRP

- **no_false_positives (3/5):** Conservation allocates a score; relevance of highlighted factors depends on the chosen propagation variant. Source: `bach2015pixel`, Methods, relevance propagation. https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0130140
- **no_false_negatives (3/5):** A conserved score can coexist with omitted influential factors; variant-specific failures leave broad-family coverage uncertain. Source: `bach2015pixel`, Methods, relevance propagation. https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0130140
- **completeness (3/5):** Redistributing an output quantity does not supply a complete rationale; conservation depends on propagation rule. Source: `bach2015pixel`, Methods, relevance propagation. https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0130140
- **stability (1/5):** Unstabilised relevance maps change sharply under input perturbations. Source: `scoreRobust2018`, Secs. 2--3, Figures 2--6. https://arxiv.org/pdf/1806.08049
- **adversarial_robustness (1/5):** Saliency manipulation motivates a low robustness judgment for unstabilised relevance propagation. Source: `bach2015pixel`, Methods, relevance propagation. https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0130140
- **consistency (3/5):** Fixed rules can repeat, but rule and model changes can alter the explanation. Source: `bach2015pixel`, Methods, relevance propagation. https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0130140
- **hyperparameters_perturbation_robustness (1/5):** Redistribution rules and stabilisers materially change relevance maps. Source: `bach2015pixel`, Methods, relevance propagation. https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0130140
- **sparsity (2/5):** Pixel or feature relevance is usually dense. Source: `bach2015pixel`, Methods, relevance propagation. https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0130140
- **level_of_detail (3/5):** Feature-resolution relevance is intermediate detail, not full logic. Source: `bach2015pixel`, Methods, relevance propagation. https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0130140
- **confidentiality (3/5):** No inherent privacy protection is supplied by relevance conservation. Source: `bach2015pixel`, Methods, relevance propagation. https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0130140
- **traceability (4/5):** Stored model, input and propagation rules permit reconstruction. Source: `bach2015pixel`, Methods, relevance propagation. https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0130140
- **runtime_performance_and_implementation_constraints (4/5):** Layerwise backpropagation is comparatively efficient. Source: `bach2015pixel`, Methods, relevance propagation. https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0130140

### Grad-CAM

- **no_false_positives (3/5):** Coarse localization can identify useful regions, without establishing pixel-level necessity. Source: `DBLP:journals/ijcv/SelvarajuCDVPB20`, gradient weighting and class localisation. https://ar5iv.labs.arxiv.org/html/1610.02391
- **no_false_negatives (2/5):** Positive-only localization omits negative evidence and finer feature contributions. Source: `DBLP:journals/ijcv/SelvarajuCDVPB20`, gradient weighting and class localisation. https://ar5iv.labs.arxiv.org/html/1610.02391
- **completeness (2/5):** A coarse region map does not conserve all evidence or explain the full decision. Source: `DBLP:journals/ijcv/SelvarajuCDVPB20`, gradient weighting and class localisation. https://ar5iv.labs.arxiv.org/html/1610.02391
- **stability (2/5):** Layer and gradient changes can alter localization. Source: `scoreRobust2018`, Secs. 2--3, Figures 2--6. https://arxiv.org/pdf/1806.08049
- **adversarial_robustness (2/5):** Model manipulation can alter Grad-CAM maps while preserving predictions. Source: `scoreGradCAMAttack2019`, model-manipulation experiments. https://arxiv.org/abs/1907.10901
- **consistency (3/5):** Fixed inference repeats, but model and sample changes can alter maps. Source: `DBLP:journals/ijcv/SelvarajuCDVPB20`, gradient weighting and class localisation. https://ar5iv.labs.arxiv.org/html/1610.02391
- **hyperparameters_perturbation_robustness (2/5):** Chosen layer and aggregation conventions materially affect localization. Source: `DBLP:journals/ijcv/SelvarajuCDVPB20`, gradient weighting and class localisation. https://ar5iv.labs.arxiv.org/html/1610.02391
- **sparsity (3/5):** Localized regions can be compact but do not enforce a minimal feature set. Source: `DBLP:journals/ijcv/SelvarajuCDVPB20`, gradient weighting and class localisation. https://ar5iv.labs.arxiv.org/html/1610.02391
- **level_of_detail (3/5):** Layer resolution provides regional rather than individual-input detail. Source: `DBLP:journals/ijcv/SelvarajuCDVPB20`, gradient weighting and class localisation. https://ar5iv.labs.arxiv.org/html/1610.02391
- **confidentiality (3/5):** Heatmaps do not inherently protect information about inputs or models. Source: `DBLP:journals/ijcv/SelvarajuCDVPB20`, gradient weighting and class localisation. https://ar5iv.labs.arxiv.org/html/1610.02391
- **traceability (4/5):** Stored model, input, gradients and selected layer permit reconstruction. Source: `DBLP:journals/ijcv/SelvarajuCDVPB20`, gradient weighting and class localisation. https://ar5iv.labs.arxiv.org/html/1610.02391
- **runtime_performance_and_implementation_constraints (5/5):** For a fixed network, one gradient pass and pooling give a top relative runtime rating; memory remains architecture-dependent. Source: `DBLP:journals/ijcv/SelvarajuCDVPB20`, gradient weighting and class localisation. https://ar5iv.labs.arxiv.org/html/1610.02391

### Integrated Gradients

- **no_false_positives (4/5):** Sensitivity(b) assigns zero contribution to functionally independent features, supporting a qualified necessity advantage. Source: `DBLP:conf/icml/SundararajanTY17`, Sec. 4.1, Sensitivity(b) and Proposition 2. https://arxiv.org/html/1703.01365v2
- **no_false_negatives (3/5):** Sensitivity(a) covers a single changed feature; general contributor coverage depends on baseline and multifeature interactions. Source: `DBLP:conf/icml/SundararajanTY17`, Secs. 2--4. https://arxiv.org/html/1703.01365v2
- **completeness (3/5):** Path completeness is a mathematical allocation identity, not complete decision rationale. Source: `DBLP:conf/icml/SundararajanTY17`, Secs. 2--4. https://arxiv.org/html/1703.01365v2
- **stability (3/5):** Integration does not guarantee input or baseline stability; neutral remains appropriate. Source: `scoreRobust2018`, Secs. 2--3, Figures 2--6. https://arxiv.org/pdf/1806.08049
- **adversarial_robustness (3/5):** Fixed-baseline gradient attribution has mixed robustness results under worst-case input perturbations. Source: `DBLP:conf/icml/SundararajanTY17`, Secs. 2--4. https://arxiv.org/html/1703.01365v2
- **consistency (3/5):** Fixed paths support repeatability; matched repeated-computation evidence is limited. Source: `DBLP:conf/icml/SundararajanTY17`, Secs. 2--4. https://arxiv.org/html/1703.01365v2
- **hyperparameters_perturbation_robustness (3/5):** Baseline and quadrature choices affect attribution, with limited common-scale comparative calibration. Source: `DBLP:conf/icml/SundararajanTY17`, Secs. 2--4. https://arxiv.org/html/1703.01365v2
- **sparsity (3/5):** Feature attribution can be dense or truncated through display selection. Source: `DBLP:conf/icml/SundararajanTY17`, Secs. 2--4. https://arxiv.org/html/1703.01365v2
- **level_of_detail (3/5):** Feature-level contributions have intermediate detail. Source: `DBLP:conf/icml/SundararajanTY17`, Secs. 2--4. https://arxiv.org/html/1703.01365v2
- **confidentiality (3/5):** No inherent confidentiality guarantee is supplied. Source: `DBLP:conf/icml/SundararajanTY17`, Secs. 2--4. https://arxiv.org/html/1703.01365v2
- **traceability (4/5):** Stored baseline, integration path and predictor permit reconstruction. Source: `DBLP:conf/icml/SundararajanTY17`, Secs. 2--4. https://arxiv.org/html/1703.01365v2
- **runtime_performance_and_implementation_constraints (2/5):** Path integration requires more gradient evaluations than single-pass attribution. Source: `DBLP:conf/icml/SundararajanTY17`, Secs. 2--4. https://arxiv.org/html/1703.01365v2

### Attention

- **no_false_positives (2/5):** Attention weights alone can disagree with output influence; contextual explanatory value remains debated. Source: `jain2019attention`, attention-correlation and counterfactual experiments. https://aclanthology.org/N19-1357/
- **no_false_negatives (2/5):** Relevant factors outside displayed attention can be missed. Source: `jain2019attention`, attention-correlation and counterfactual experiments. https://aclanthology.org/N19-1357/
- **completeness (1/5):** Attention weights omit downstream computations required to cover the decision rationale. Source: `jain2019attention`, attention-correlation and counterfactual experiments. https://aclanthology.org/N19-1357/
- **stability (3/5):** Comparative input-stability evidence for extracted attention weights is limited. Source: `jain2019attention`, attention-correlation and counterfactual experiments. https://aclanthology.org/N19-1357/
- **adversarial_robustness (3/5):** No universal attack-resistance ranking for all attention architectures is established. Source: `jain2019attention`, attention-correlation and counterfactual experiments. https://aclanthology.org/N19-1357/
- **consistency (3/5):** Repeatable weights in evaluation mode do not guarantee consistency across models or time. Source: `jain2019attention`, attention-correlation and counterfactual experiments. https://aclanthology.org/N19-1357/
- **hyperparameters_perturbation_robustness (2/5):** Layer, head and aggregation choices change the displayed explanation. Source: `jain2019attention`, attention-correlation and counterfactual experiments. https://aclanthology.org/N19-1357/
- **sparsity (3/5):** Head and layer aggregation determine whether the weight display is compact or dense. Source: `jain2019attention`, attention-correlation and counterfactual experiments. https://aclanthology.org/N19-1357/
- **level_of_detail (2/5):** Head-level associations are coarser than a complete feature or rule-level rationale. Source: `jain2019attention`, attention-correlation and counterfactual experiments. https://aclanthology.org/N19-1357/
- **confidentiality (3/5):** Attention displays are not privacy mechanisms. Source: `jain2019attention`, attention-correlation and counterfactual experiments. https://aclanthology.org/N19-1357/
- **traceability (3/5):** Reconstruction requires the sampled neighbourhood, random state and fitted surrogate as well as the predictor and input. Source: `jain2019attention`, attention-correlation and counterfactual experiments. https://aclanthology.org/N19-1357/
- **runtime_performance_and_implementation_constraints (5/5):** Extraction from an existing forward pass is inexpensive; this excludes training and additional attention-attribution algorithms. Source: `jain2019attention`, attention-correlation and counterfactual experiments. https://aclanthology.org/N19-1357/

### Supervised CBM

- **no_false_positives (3/5):** Concept labels need not match encoded information; no automatic necessity guarantee. Source: `scoreConceptLimits2021`, concept representation and semantic alignment. https://arxiv.org/abs/2105.04289
- **no_false_negatives (3/5):** Concept coordinates expose the prediction interface; imperfect semantics can leave encoded influences unnamed. Source: `scoreConceptLimits2021`, concept representation and semantic alignment. https://arxiv.org/abs/2105.04289
- **completeness (4/5):** Concept-only routing exposes all inputs to the constructed prediction head. Source: `DBLP:conf/icml/KohNTMPKL20`, concept-to-label architecture and interventions. https://proceedings.mlr.press/v119/koh20a.html
- **stability (3/5):** Concept predictions remain sensitive to model and data. Source: `DBLP:conf/icml/KohNTMPKL20`, concept-to-label architecture and interventions. https://proceedings.mlr.press/v119/koh20a.html
- **adversarial_robustness (3/5):** Concept intervention is not a general attack defense. Source: `DBLP:conf/icml/KohNTMPKL20`, concept-to-label architecture and interventions. https://proceedings.mlr.press/v119/koh20a.html
- **consistency (3/5):** Fixed concepts aid comparison; learned encoders can vary. Source: `DBLP:conf/icml/KohNTMPKL20`, concept-to-label architecture and interventions. https://proceedings.mlr.press/v119/koh20a.html
- **hyperparameters_perturbation_robustness (2/5):** Concept bank and training scheme influence representations. Source: `DBLP:conf/icml/KohNTMPKL20`, concept-to-label architecture and interventions. https://proceedings.mlr.press/v119/koh20a.html
- **sparsity (3/5):** Few concepts help, but no minimal set is enforced. Source: `DBLP:conf/icml/KohNTMPKL20`, concept-to-label architecture and interventions. https://proceedings.mlr.press/v119/koh20a.html
- **level_of_detail (3/5):** Concept values and head behavior expose intermediate computation. Source: `DBLP:conf/icml/KohNTMPKL20`, concept-to-label architecture and interventions. https://proceedings.mlr.press/v119/koh20a.html
- **confidentiality (3/5):** Concept annotations can be sensitive; no privacy mechanism. Source: `DBLP:conf/icml/KohNTMPKL20`, concept-to-label architecture and interventions. https://proceedings.mlr.press/v119/koh20a.html
- **traceability (4/5):** Stored encoder, concept labels and prediction head permit reconstruction. Source: `DBLP:conf/icml/KohNTMPKL20`, concept-to-label architecture and interventions. https://proceedings.mlr.press/v119/koh20a.html
- **runtime_performance_and_implementation_constraints (2/5):** Concept supervision and training add substantial implementation cost. Source: `DBLP:conf/icml/KohNTMPKL20`, concept-to-label architecture and interventions. https://proceedings.mlr.press/v119/koh20a.html

### Post-hoc CBM (concept-only)

- **no_false_positives (3/5):** Head contributions are explicit; concept semantics may remain imperfect. Source: `scoreConceptLimits2021`, concept representation and semantic alignment. https://arxiv.org/abs/2105.04289
- **no_false_negatives (3/5):** Concept coordinates expose the replacement predictor; imperfect semantics can leave encoded influences unnamed. Source: `scoreConceptLimits2021`, concept representation and semantic alignment. https://arxiv.org/abs/2105.04289
- **completeness (4/5):** Concept-only routing exposes all inputs to the constructed prediction head. Source: `yuksekgonul2023pcbm`, Sec. 2, concept-only prediction head. https://arxiv.org/pdf/2205.15480
- **stability (3/5):** Frozen embeddings help repeatability but do not guarantee stability. Source: `yuksekgonul2023pcbm`, Sec. 2, concept-only prediction head. https://arxiv.org/pdf/2205.15480
- **adversarial_robustness (3/5):** No general adversarial resistance follows from concept projection. Source: `yuksekgonul2023pcbm`, Sec. 2, concept-only prediction head. https://arxiv.org/pdf/2205.15480
- **consistency (3/5):** Stored concepts aid repeatability; refitted heads may differ. Source: `yuksekgonul2023pcbm`, Sec. 2, concept-only prediction head. https://arxiv.org/pdf/2205.15480
- **hyperparameters_perturbation_robustness (2/5):** Concept bank and sparsity penalty influence the predictor. Source: `yuksekgonul2023pcbm`, Sec. 2, concept-only prediction head. https://arxiv.org/pdf/2205.15480
- **sparsity (4/5):** Sparse linear head promotes compact concept contributions. Source: `yuksekgonul2023pcbm`, Sec. 2, concept-only prediction head. https://arxiv.org/pdf/2205.15480
- **level_of_detail (3/5):** Coefficients and concept scores expose head-level computation. Source: `yuksekgonul2023pcbm`, Sec. 2, concept-only prediction head. https://arxiv.org/pdf/2205.15480
- **confidentiality (3/5):** Published concepts and weights may reveal sensitive behavior. Source: `yuksekgonul2023pcbm`, Sec. 2, concept-only prediction head. https://arxiv.org/pdf/2205.15480
- **traceability (4/5):** Stored backbone, projection, concepts and head weights permit reconstruction. Source: `yuksekgonul2023pcbm`, Sec. 2, concept-only prediction head. https://arxiv.org/pdf/2205.15480
- **runtime_performance_and_implementation_constraints (3/5):** Reuse of a frozen backbone reduces training overhead. Source: `yuksekgonul2023pcbm`, Sec. 2, concept-only prediction head. https://arxiv.org/pdf/2205.15480

### LaBo (LLM-guided CBM)

- **no_false_positives (3/5):** Generated concepts and visual grounding need validation. Source: `scoreConceptLimits2021`, concept representation and semantic alignment. https://arxiv.org/abs/2105.04289
- **no_false_negatives (3/5):** Generated concepts expose the prediction interface; imperfect semantics can leave encoded influences unnamed. Source: `scoreConceptLimits2021`, concept representation and semantic alignment. https://arxiv.org/abs/2105.04289
- **completeness (4/5):** Concept-only routing exposes all inputs to the constructed prediction head. Source: `yang2023labo`, Secs. 3.2--3.3 and 4.3. https://arxiv.org/pdf/2211.11158
- **stability (3/5):** Fixed selected concepts help; input sensitivity remains. Source: `yang2023labo`, Secs. 3.2--3.3 and 4.3. https://arxiv.org/pdf/2211.11158
- **adversarial_robustness (3/5):** Language-generated concepts do not establish attack resistance. Source: `yang2023labo`, Secs. 3.2--3.3 and 4.3. https://arxiv.org/pdf/2211.11158
- **consistency (2/5):** LLM sampling and concept selection can change representations. Source: `yang2023labo`, Secs. 3.2--3.3 and 4.3. https://arxiv.org/pdf/2211.11158
- **hyperparameters_perturbation_robustness (2/5):** Prompts, bottleneck size and selection weights affect output. Source: `yang2023labo`, Secs. 3.2--3.3 and 4.3. https://arxiv.org/pdf/2211.11158
- **sparsity (3/5):** The default vocabulary uses 50 concepts per class and dense normalised weights, giving neutral compactness. Source: `yang2023labo`, Secs. 3.2--3.3 and 4.3. https://arxiv.org/pdf/2211.11158
- **level_of_detail (3/5):** Concept scores and head weights expose intermediate detail. Source: `yang2023labo`, Secs. 3.2--3.3 and 4.3. https://arxiv.org/pdf/2211.11158
- **confidentiality (3/5):** Prompts and data require contextual confidentiality controls. Source: `yang2023labo`, Secs. 3.2--3.3 and 4.3. https://arxiv.org/pdf/2211.11158
- **traceability (4/5):** Stored concept candidates, selected descriptions and model versions permit reconstruction. Source: `yang2023labo`, Secs. 3.2--3.3 and 4.3. https://arxiv.org/pdf/2211.11158
- **runtime_performance_and_implementation_constraints (3/5):** Concept generation and alignment add cost; encoders are reused. Source: `yang2023labo`, Secs. 3.2--3.3 and 4.3. https://arxiv.org/pdf/2211.11158

### LLM neuron explanations (Bills et al.)

- **no_false_positives (2/5):** Descriptions are imperfect correlations with activation patterns. Source: `scoreNeuronPaper2023`, explanation and simulation pipeline. https://openaipublic.blob.core.windows.net/neuron-explainer/paper/index.html
- **no_false_negatives (2/5):** Polysemantic behavior can escape concise descriptions. Source: `scoreNeuronPaper2023`, explanation and simulation pipeline. https://openaipublic.blob.core.windows.net/neuron-explainer/paper/index.html
- **completeness (2/5):** The declared target is neuron activation behavior. Source: `scoreNeuronPaper2023`, explanation and simulation pipeline. https://openaipublic.blob.core.windows.net/neuron-explainer/paper/index.html
- **stability (3/5):** Input-stability evidence for generated activation descriptions is limited; generation variation is assessed through consistency. Source: `scoreNeuronPaper2023`, explanation and simulation pipeline. https://openaipublic.blob.core.windows.net/neuron-explainer/paper/index.html
- **adversarial_robustness (3/5):** No general adversarial-resistance evaluation establishes a strength. Source: `scoreNeuronPaper2023`, explanation and simulation pipeline. https://openaipublic.blob.core.windows.net/neuron-explainer/paper/index.html
- **consistency (2/5):** Generated descriptions can vary across models or runs. Source: `scoreNeuronPaper2023`, explanation and simulation pipeline. https://openaipublic.blob.core.windows.net/neuron-explainer/paper/index.html
- **hyperparameters_perturbation_robustness (2/5):** Prompts, examples and simulator choices affect explanations. Source: `scoreNeuronPaper2023`, explanation and simulation pipeline. https://openaipublic.blob.core.windows.net/neuron-explainer/paper/index.html
- **sparsity (3/5):** Short descriptions compress behavior without proving minimality. Source: `scoreNeuronPaper2023`, explanation and simulation pipeline. https://openaipublic.blob.core.windows.net/neuron-explainer/paper/index.html
- **level_of_detail (3/5):** Neuron-level linguistic patterns offer intermediate descriptive detail. Source: `scoreNeuronPaper2023`, explanation and simulation pipeline. https://openaipublic.blob.core.windows.net/neuron-explainer/paper/index.html
- **confidentiality (3/5):** Activation examples may contain sensitive text. Source: `scoreNeuronPaper2023`, explanation and simulation pipeline. https://openaipublic.blob.core.windows.net/neuron-explainer/paper/index.html
- **traceability (4/5):** Stored examples, prompts, activations and descriptions permit reconstruction. Source: `scoreNeuronPaper2023`, explanation and simulation pipeline. https://openaipublic.blob.core.windows.net/neuron-explainer/paper/index.html
- **runtime_performance_and_implementation_constraints (2/5):** Repeated generation and simulation are compute-intensive. Source: `scoreNeuronPaper2023`, explanation and simulation pipeline. https://openaipublic.blob.core.windows.net/neuron-explainer/paper/index.html

### MechaRule

- **no_false_positives (4/5):** Ablation provides conditional necessity evidence, not uniquely symbolic mechanisms. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **no_false_negatives (3/5):** Candidate reduction and weak-effect search can miss neurons. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **completeness (3/5):** Coverage is restricted to task, candidates and intervention basis. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **stability (3/5):** Baseline and task regime affect localized explanations. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **adversarial_robustness (3/5):** Jailbreak suppression is not robustness of the explanation itself. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **consistency (3/5):** Cross-model and temporal consistency remain unestablished. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **hyperparameters_perturbation_robustness (2/5):** Candidate budget, thresholds and baselines affect localization. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **sparsity (4/5):** Sparse neurons and compact rules are explicit objectives. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **level_of_detail (4/5):** Rules linked to neuron coordinates add mechanistic detail. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **confidentiality (2/5):** Internal coordinates and rules can expose proprietary mechanisms. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **traceability (4/5):** Stored rules, intervention traces, candidates and baselines permit reconstruction. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
- **runtime_performance_and_implementation_constraints (2/5):** Hierarchical search saves interventions but requires costly internal access. Source: `sovrano2026mecharule`, Secs. 4 and 8. https://arxiv.org/html/2605.03058v1
