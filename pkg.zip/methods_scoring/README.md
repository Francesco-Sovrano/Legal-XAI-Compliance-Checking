# Method scoring

`assess_xai_compliance.py` contains all 26 method profiles, 312 ratings and seven legal weight vectors. It is standalone and requires Python and pandas:

```sh
python -m pip install pandas
python assess_xai_compliance.py
```

The integer ratings agree with `inputs/paper_inputs.json`. The standalone example evaluates its embedded legal vectors. The paper's default legal matrix is held in the JSON input and is used by the shared analysis modules. `scoring.py` supplies the shared scoring equations for sensitivity and expert analysis. `sensitivity_analysis.py` computes the 10,000-draw joint analysis and writes numerical results and its PDF to `analysis/`.

From this directory:

```sh
python -m pip install -r requirements.txt
python sensitivity_analysis.py
```

`inputs/score_evidence.json` contains every rating justification and primary-source location. `assess_xai_compliance_documentation.md` provides the complete specification. The package-level pipeline preserves the supplied source diagrams and regenerates analysis figures from the numerical outputs.

`inputs/legal_task_variants.json` and `inputs/legal_task_cases.json` define recipient and timing alternatives. Run `python legal_task_sensitivity.py` to export their scores to `analysis/legal_task_sensitivity.csv`. All MDR profiles use confidentiality weight 0.5. After the joint analysis, run `python question_sensitivity.py` to regenerate question-specific probabilities and their figure. Both scripts use the shared scoring functions and are included in `../replicate.py`.
