# Legal XAI replication package

The package computes legal-context comparisons, joint sensitivity and legal-expert statistics. The supplied numerical outputs also include deterministic recipient and timing comparisons defined in `methods_scoring/inputs/legal_task_cases.json`. It contains the method catalogue, primary-source evidence, recorded response database, collection interface and technical benchmark.

## Organisation

| Directory or file | Content |
| :--- | :--- |
| `methods_scoring/` | Standalone catalogue, shared scoring equations, sensitivity script, evidence and documentation |
| `methods_scoring/inputs/` | Ratings, legal weights, source locations, qualitative annotations and figure inputs |
| `methods_scoring/analysis/` | Sensitivity scores, winning probabilities, retention and shared draws |
| `methods_scoring/figures/` | Matplotlib PDF figures |
| `user_study/ui/` | Study application, static assets, collection logic and technical benchmark |
| `user_study/data/` | Recorded database and legal-expert analysis scripts |
| `user_study/data/analysis/` | Expert statistics, exact tests, comparison rankings and figures |
| `user_study/data/audit/` | Cohort, data schema, feedback coding and instrument hashes |
| `replicate.py` | Complete analysis entry point |

## Install and compute

Python 3.12 is supported. From this directory:

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r methods_scoring/requirements.txt
python replicate.py
python -m unittest discover -s methods_scoring/tests
PYTHONPATH=user_study/ui python -m unittest discover -s user_study/ui/tests
```

The default is 10,000 draws with seed 20261005. Outputs are stored beside their corresponding analysis scripts. `--outdir PATH` writes the same directory structure under another location. `--manuscript-dir PATH` copies PDF figures into a manuscript bundle. `replication_provenance.json` records input hashes and package versions.

For the paper's method comparisons, run `python methods_scoring/sensitivity_analysis.py`. For the expert statistics, then run `python user_study/data/legal_expert_validation.py`. Both read the default legal matrix in `methods_scoring/inputs/paper_inputs.json`. The standalone `assess_xai_compliance.py` contains its own legal vectors; it evaluates an embedded example.

The complete methods and data specification is `methods_scoring/assess_xai_compliance_documentation.md`. It defines all legal weights, distinguishes joint draws from deterministic task comparisons, and supplies the verification command for the latter. `replicate.py` runs the joint analysis, expert statistics, audit and static figures; the deterministic task comparisons use the separately supplied cases and shared scoring functions.

## Study interface

```sh
python user_study/ui/app.py --mode demo --db user_study/ui/data/demo.sqlite3
```

Open `http://127.0.0.1:8080`. The interface writes to a new demo database. The recorded response database is read-only during analysis. Its instrument hash differs from the provided interface instrument hash. Exact collection text requires the instrument corresponding to the recorded hash. The fixed analytic cohort comprises E08, E11, E13 and E18.

## Optional technical benchmark

```sh
python -m pip install -r user_study/ui/requirements-benchmark.txt
python user_study/ui/scripts/run_empirical_benchmark.py
```

The benchmark uses a Wisconsin Diagnostic Breast Cancer random forest. Its data, model and recorded measurements are in `user_study/ui/benchmark`. The legal-expert clinical case uses a diabetes scenario with stipulated technical findings and is a separate case. Benchmark execution requires SHAP.
